-- =====================================================================
-- TRIGGERS (automatic rules that run inside the database)
-- =====================================================================
USE online_exam;
DELIMITER $$

-- ---------------------------------------------------------------------
-- EXAM: start must be in the future; faculty must teach the subject
-- ---------------------------------------------------------------------
CREATE TRIGGER trg_exam_bi BEFORE INSERT ON exam
FOR EACH ROW
BEGIN
    IF NEW.start_time <= NOW() THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Exam start time must be in the future';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM faculty_subject
                   WHERE faculty_id = NEW.created_by AND subject_id = NEW.subject_id) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Faculty does not teach this subject';
    END IF;
END$$

-- ---------------------------------------------------------------------
-- PAPER: copy the hash, block a repeated question, same subject only,
-- no changes once the exam has started
-- ---------------------------------------------------------------------
CREATE TRIGGER trg_eq_bi BEFORE INSERT ON exam_question
FOR EACH ROW
BEGIN
    IF (SELECT start_time FROM exam WHERE exam_id = NEW.exam_id) <= NOW() THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Exam has started; the paper can no longer be changed';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM question q JOIN exam e ON e.subject_id = q.subject_id
                   WHERE q.question_id = NEW.question_id AND e.exam_id = NEW.exam_id) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Question belongs to a different subject';
    END IF;

    SET NEW.question_hash = (SELECT question_hash FROM question WHERE question_id = NEW.question_id);

    IF EXISTS (SELECT 1 FROM exam_question
               WHERE exam_id = NEW.exam_id AND question_hash = NEW.question_hash) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'This question is already in this paper';
    END IF;
END$$

-- ---------------------------------------------------------------------
-- QUESTION TYPE / CORRECT OPTION are locked once an exam using them started
-- ---------------------------------------------------------------------
CREATE TRIGGER trg_question_bu BEFORE UPDATE ON question
FOR EACH ROW
BEGIN
    IF NEW.question_type <> OLD.question_type
       AND EXISTS (SELECT 1 FROM exam_question eq JOIN exam e ON e.exam_id = eq.exam_id
                   WHERE eq.question_id = OLD.question_id AND e.start_time <= NOW()) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Question type is locked: an exam using it has started';
    END IF;
END$$

CREATE TRIGGER trg_option_bu BEFORE UPDATE ON question_option
FOR EACH ROW
BEGIN
    IF NEW.is_correct <> OLD.is_correct
       AND EXISTS (SELECT 1 FROM exam_question eq JOIN exam e ON e.exam_id = eq.exam_id
                   WHERE eq.question_id = OLD.question_id AND e.start_time <= NOW()) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Correct answer is locked: an exam using it has started';
    END IF;
END$$

-- ---------------------------------------------------------------------
-- RETAKE PERMISSION: only the exam's faculty, only in the future
-- ---------------------------------------------------------------------
CREATE TRIGGER trg_retake_bi BEFORE INSERT ON retake_permission
FOR EACH ROW
BEGIN
    IF NOT EXISTS (SELECT 1 FROM exam WHERE exam_id = NEW.exam_id AND created_by = NEW.granted_by) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Only the faculty who made the exam can allow a retake';
    END IF;
    IF NEW.valid_until <= NOW() THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Retake deadline must be in the future';
    END IF;
END$$

-- ---------------------------------------------------------------------
-- JOINING: enrolled? exam active? inside the time window? retake allowed?
-- also sets the deadline of this attempt.
--   normal first attempt : deadline = the exam's fixed end time
--   retake / late joiner : needs an unused retake_permission; deadline =
--                          earlier of (permission valid_until, now + duration)
-- "only one open attempt" is enforced by the unique key uq_one_open_attempt.
-- ---------------------------------------------------------------------
CREATE TRIGGER trg_attempt_bi BEFORE INSERT ON exam_attempt
FOR EACH ROW
BEGIN
    DECLARE v_start DATETIME;
    DECLARE v_end DATETIME;
    DECLARE v_active TINYINT;
    DECLARE v_duration INT;
    DECLARE v_valid DATETIME DEFAULT NULL;
    DECLARE v_perm INT DEFAULT NULL;

    SELECT start_time, end_time, is_active, duration_minutes
      INTO v_start, v_end, v_active, v_duration
      FROM exam WHERE exam_id = NEW.exam_id;

    IF NOT EXISTS (SELECT 1 FROM enrollment en JOIN exam e ON e.subject_id = en.subject_id
                   WHERE en.student_id = NEW.student_id AND e.exam_id = NEW.exam_id) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Student is not enrolled in this subject';
    END IF;
    IF v_active = 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Exam is deactivated';
    END IF;
    IF NEW.attempt_no = 1 AND NOW() < v_start THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Exam has not started yet';
    END IF;

    IF NEW.attempt_no = 1 AND NOW() < v_end THEN
        SET NEW.deadline = v_end;                          -- everyone shares the fixed end time
    ELSE
        SET v_perm = (SELECT permission_id FROM retake_permission
                       WHERE exam_id = NEW.exam_id AND student_id = NEW.student_id
                         AND used = 0 AND valid_until > NOW()
                       ORDER BY permission_id LIMIT 1);
        SET v_valid = (SELECT valid_until FROM retake_permission
                        WHERE exam_id = NEW.exam_id AND student_id = NEW.student_id
                          AND used = 0 AND valid_until > NOW()
                        ORDER BY permission_id LIMIT 1);
        IF v_perm IS NULL AND NEW.attempt_no = 1 THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Exam time is over';
        END IF;
        IF v_perm IS NULL THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'No retake permission for this student';
        END IF;
        SET NEW.deadline = LEAST(v_valid, TIMESTAMPADD(MINUTE, v_duration, NOW()));
    END IF;
END$$

CREATE TRIGGER trg_attempt_ai AFTER INSERT ON exam_attempt
FOR EACH ROW
BEGIN
    -- a retake, or a late/absent student let in after the exam closed, consumes one permission
    IF NEW.attempt_no > 1 OR NOW() >= (SELECT end_time FROM exam WHERE exam_id = NEW.exam_id) THEN
        UPDATE retake_permission SET used = 1
         WHERE exam_id = NEW.exam_id AND student_id = NEW.student_id
           AND used = 0 AND valid_until > NOW()
         ORDER BY permission_id LIMIT 1;
    END IF;
    -- NOTE: the JOINED event is written by join_exam(), not here. A trigger on
    -- exam_attempt that inserts into attempt_event would chain into trg_event_ai,
    -- which updates exam_attempt again (a table cannot be changed by a trigger
    -- chain started from its own statement).
    INSERT INTO activity_log (actor_type, actor_id, action, details)
    VALUES ('STUDENT', NEW.student_id, 'JOIN_EXAM',
            CONCAT('exam=', NEW.exam_id, ' attempt=', NEW.attempt_no));
END$$

-- when an attempt stops being IN_PROGRESS -> calculate its result automatically
CREATE TRIGGER trg_attempt_au AFTER UPDATE ON exam_attempt
FOR EACH ROW
BEGIN
    IF OLD.status = 'IN_PROGRESS' AND NEW.status <> 'IN_PROGRESS' THEN
        CALL generate_result(NEW.attempt_id);
        INSERT INTO activity_log (actor_type, actor_id, action, details)
        VALUES ('STUDENT', NEW.student_id, 'ATTEMPT_ENDED',
                CONCAT('attempt=', NEW.attempt_id, ' status=', NEW.status, ' flags=', NEW.flag_count));
    END IF;
END$$

-- ---------------------------------------------------------------------
-- ANSWERS: attempt must be open, question must be in the paper,
-- single-answer questions accept only one option
-- ---------------------------------------------------------------------
CREATE TRIGGER trg_answer_bi BEFORE INSERT ON answer
FOR EACH ROW
BEGIN
    IF NOT EXISTS (SELECT 1 FROM exam_attempt
                   WHERE attempt_id = NEW.attempt_id
                     AND status = 'IN_PROGRESS' AND NOW() < deadline) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'This attempt is closed';
    END IF;

    IF NOT EXISTS (SELECT 1 FROM exam_attempt a
                   JOIN exam_question eq ON eq.exam_id = a.exam_id
                   WHERE a.attempt_id = NEW.attempt_id
                     AND eq.question_id = NEW.question_id
                     AND eq.status <> 'DROPPED') THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Question is not part of this exam';
    END IF;

    IF EXISTS (SELECT 1 FROM question
               WHERE question_id = NEW.question_id AND question_type = 'SINGLE')
       AND EXISTS (SELECT 1 FROM answer
                   WHERE attempt_id = NEW.attempt_id
                     AND question_id = NEW.question_id
                     AND option_id <> NEW.option_id) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Single-answer question accepts only one option';
    END IF;
END$$

-- changing an answer (delete + insert) is also only allowed while the attempt is open
CREATE TRIGGER trg_answer_bd BEFORE DELETE ON answer
FOR EACH ROW
BEGIN
    IF NOT EXISTS (SELECT 1 FROM exam_attempt
                   WHERE attempt_id = OLD.attempt_id
                     AND status = 'IN_PROGRESS' AND NOW() < deadline) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'This attempt is closed';
    END IF;
END$$

-- ---------------------------------------------------------------------
-- FLAGS: every LEFT / TAB_SWITCH adds one flag; at the exam's limit
-- the attempt is auto-submitted (trg_attempt_au then makes the result)
-- ---------------------------------------------------------------------
CREATE TRIGGER trg_event_ai AFTER INSERT ON attempt_event
FOR EACH ROW
BEGIN
    IF NEW.event_type IN ('LEFT', 'TAB_SWITCH') THEN
        UPDATE exam_attempt SET flag_count = flag_count + 1
         WHERE attempt_id = NEW.attempt_id AND status = 'IN_PROGRESS';

        UPDATE exam_attempt
           SET status = 'AUTO_FLAGS', submit_time = NOW()
         WHERE attempt_id = NEW.attempt_id
           AND status = 'IN_PROGRESS'
           AND flag_count >= (SELECT e.flag_limit FROM exam e
                              WHERE e.exam_id = (SELECT x.exam_id FROM exam_attempt x
                                                 WHERE x.attempt_id = NEW.attempt_id));
    END IF;
END$$

DELIMITER ;

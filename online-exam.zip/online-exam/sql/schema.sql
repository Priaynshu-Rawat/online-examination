-- =====================================================================
-- ONLINE EXAMINATION SYSTEM : TABLES (MySQL 8.0.16+)
-- Run order: schema.sql -> views.sql -> procedures.sql -> triggers.sql
-- =====================================================================
DROP DATABASE IF EXISTS online_exam;
CREATE DATABASE online_exam CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE online_exam;

-- ---------------------------------------------------------------------
-- USERS AND SUBJECTS
-- ---------------------------------------------------------------------
CREATE TABLE admin (
    admin_id       INT AUTO_INCREMENT PRIMARY KEY,
    name           VARCHAR(100) NOT NULL,
    email          VARCHAR(120) NOT NULL UNIQUE,
    password_hash  VARCHAR(255) NOT NULL,
    created_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE faculty (
    faculty_id     INT AUTO_INCREMENT PRIMARY KEY,
    name           VARCHAR(100) NOT NULL,
    email          VARCHAR(120) NOT NULL UNIQUE,
    password_hash  VARCHAR(255) NOT NULL,
    created_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE student (
    student_id     INT AUTO_INCREMENT PRIMARY KEY,
    roll_no        VARCHAR(30)  NOT NULL UNIQUE,
    name           VARCHAR(100) NOT NULL,
    email          VARCHAR(120) NOT NULL UNIQUE,
    password_hash  VARCHAR(255) NOT NULL,
    created_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE subject (
    subject_id     INT AUTO_INCREMENT PRIMARY KEY,
    code           VARCHAR(20)  NOT NULL UNIQUE,
    name           VARCHAR(100) NOT NULL
);

-- which faculty teaches which subject (decides what they may see/create)
CREATE TABLE faculty_subject (
    faculty_id     INT NOT NULL,
    subject_id     INT NOT NULL,
    PRIMARY KEY (faculty_id, subject_id),
    FOREIGN KEY (faculty_id) REFERENCES faculty(faculty_id),
    FOREIGN KEY (subject_id) REFERENCES subject(subject_id)
);

-- which student studies which subject (needed to know who was ABSENT)
CREATE TABLE enrollment (
    student_id     INT NOT NULL,
    subject_id     INT NOT NULL,
    PRIMARY KEY (student_id, subject_id),
    FOREIGN KEY (student_id) REFERENCES student(student_id),
    FOREIGN KEY (subject_id) REFERENCES subject(subject_id)
);

-- ---------------------------------------------------------------------
-- QUESTION BANK
-- question_hash = SHA-256 of the text with case, spaces and punctuation
-- removed, so "What is a Deadlock?" and "what is a deadlock" are equal.
-- ---------------------------------------------------------------------
CREATE TABLE question (
    question_id    INT AUTO_INCREMENT PRIMARY KEY,
    subject_id     INT NOT NULL,
    created_by     INT NOT NULL,
    question_text  TEXT NOT NULL,
    question_type  ENUM('SINGLE','MULTIPLE') NOT NULL DEFAULT 'SINGLE',
    question_hash  CHAR(64) AS (SHA2(REGEXP_REPLACE(LOWER(question_text), '[[:space:][:punct:]]+', ''), 256)) STORED,
    created_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CHECK (CHAR_LENGTH(question_text) >= 5),
    FOREIGN KEY (subject_id) REFERENCES subject(subject_id),
    FOREIGN KEY (created_by) REFERENCES faculty(faculty_id),
    INDEX idx_question_hash (question_hash),
    INDEX idx_question_subject (subject_id)
);

-- option text is unique inside one question (blocks duplicate options)
CREATE TABLE question_option (
    option_id      INT AUTO_INCREMENT PRIMARY KEY,
    question_id    INT NOT NULL,
    label          CHAR(1) NOT NULL,
    option_text    VARCHAR(300) NOT NULL,
    is_correct     TINYINT(1) NOT NULL DEFAULT 0,
    UNIQUE KEY uq_option_label (question_id, label),
    UNIQUE KEY uq_option_text  (question_id, option_text),
    UNIQUE KEY uq_option_pair  (option_id, question_id),
    FOREIGN KEY (question_id) REFERENCES question(question_id) ON DELETE CASCADE
);

-- ---------------------------------------------------------------------
-- EXAMS
-- end_time is calculated: start_time + duration
-- ---------------------------------------------------------------------
CREATE TABLE exam (
    exam_id             INT AUTO_INCREMENT PRIMARY KEY,
    subject_id          INT NOT NULL,
    created_by          INT NOT NULL,
    title               VARCHAR(150) NOT NULL,
    instructions        TEXT,
    start_time          DATETIME NOT NULL,
    duration_minutes    INT NOT NULL,
    end_time            DATETIME AS (TIMESTAMPADD(MINUTE, duration_minutes, start_time)) STORED,
    is_active           TINYINT(1) NOT NULL DEFAULT 1,
    negative_marks      DECIMAL(4,2) NOT NULL DEFAULT 0,   -- deducted per wrong question
    pass_percentage     DECIMAL(5,2) NOT NULL DEFAULT 40,
    flag_limit          INT NOT NULL DEFAULT 5,            -- auto-submit at this many flags
    shuffle_questions   TINYINT(1) NOT NULL DEFAULT 1,
    shuffle_options     TINYINT(1) NOT NULL DEFAULT 1,
    results_published   TINYINT(1) NOT NULL DEFAULT 0,
    allow_answer_review TINYINT(1) NOT NULL DEFAULT 0,
    cloned_from         INT NULL,
    created_at          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CHECK (duration_minutes > 0),
    CHECK (flag_limit > 0),
    CHECK (negative_marks >= 0),
    CHECK (pass_percentage BETWEEN 0 AND 100),
    FOREIGN KEY (subject_id) REFERENCES subject(subject_id),
    FOREIGN KEY (created_by) REFERENCES faculty(faculty_id),
    FOREIGN KEY (cloned_from) REFERENCES exam(exam_id) ON DELETE SET NULL,
    INDEX idx_exam_subject_time (subject_id, start_time)
);

-- paper = list of questions with their marks.
-- UNIQUE(exam_id, question_hash) is the database-level block on repeated questions.
CREATE TABLE exam_question (
    exam_id        INT NOT NULL,
    question_id    INT NOT NULL,
    marks          DECIMAL(5,2) NOT NULL DEFAULT 1,
    display_order  INT NOT NULL,
    status         ENUM('ACTIVE','DROPPED','FREE_MARKS') NOT NULL DEFAULT 'ACTIVE',
    question_hash  CHAR(64) NOT NULL,                     -- copied by trigger
    PRIMARY KEY (exam_id, question_id),
    UNIQUE KEY uq_exam_question_hash (exam_id, question_hash),
    CHECK (marks > 0),
    FOREIGN KEY (exam_id)     REFERENCES exam(exam_id) ON DELETE CASCADE,
    FOREIGN KEY (question_id) REFERENCES question(question_id),
    INDEX idx_eq_hash (question_hash)
);

-- faculty lets one student retake an exam (valid until a given time)
CREATE TABLE retake_permission (
    permission_id  INT AUTO_INCREMENT PRIMARY KEY,
    exam_id        INT NOT NULL,
    student_id     INT NOT NULL,
    granted_by     INT NOT NULL,
    granted_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    valid_until    DATETIME NOT NULL,
    used           TINYINT(1) NOT NULL DEFAULT 0,
    FOREIGN KEY (exam_id)    REFERENCES exam(exam_id),
    FOREIGN KEY (student_id) REFERENCES student(student_id),
    FOREIGN KEY (granted_by) REFERENCES faculty(faculty_id)
);

-- ---------------------------------------------------------------------
-- ATTEMPTS, EVENTS, ANSWERS, RESULTS
-- ---------------------------------------------------------------------
CREATE TABLE exam_attempt (
    attempt_id      INT AUTO_INCREMENT PRIMARY KEY,
    exam_id         INT NOT NULL,
    student_id      INT NOT NULL,
    attempt_no      INT NOT NULL DEFAULT 1,
    joined_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    submit_time     DATETIME NULL,
    deadline        DATETIME NULL,                         -- set by trigger
    status          ENUM('IN_PROGRESS','SUBMITTED','AUTO_TIMEOUT','AUTO_FLAGS') NOT NULL DEFAULT 'IN_PROGRESS',
    flag_count      INT NOT NULL DEFAULT 0,
    question_order  JSON NULL,                             -- this student's shuffled order
    last_heartbeat  DATETIME NULL,
    -- open_flag is 1 while IN_PROGRESS, otherwise NULL. The unique key below then
    -- allows only ONE open attempt per student per exam (NULLs never clash).
    open_flag       TINYINT AS (IF(status = 'IN_PROGRESS', 1, NULL)) STORED,
    UNIQUE KEY uq_attempt (exam_id, student_id, attempt_no),
    UNIQUE KEY uq_one_open_attempt (exam_id, student_id, open_flag),
    FOREIGN KEY (exam_id)    REFERENCES exam(exam_id),
    FOREIGN KEY (student_id) REFERENCES student(student_id),
    INDEX idx_attempt_status (status, deadline)
);

-- every join / leave / resume / tab switch is one row here.
-- flags = number of LEFT + TAB_SWITCH rows
CREATE TABLE attempt_event (
    event_id     BIGINT AUTO_INCREMENT PRIMARY KEY,
    attempt_id   INT NOT NULL,
    event_type   ENUM('JOINED','LEFT','RESUMED','TAB_SWITCH','SUBMITTED') NOT NULL,
    event_time   DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    note         VARCHAR(200) NULL,
    FOREIGN KEY (attempt_id) REFERENCES exam_attempt(attempt_id),
    INDEX idx_event_attempt (attempt_id, event_type)
);

-- one row per selected option. (option_id, question_id) must be a real pair.
CREATE TABLE answer (
    attempt_id   INT NOT NULL,
    question_id  INT NOT NULL,
    option_id    INT NOT NULL,
    saved_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (attempt_id, question_id, option_id),
    FOREIGN KEY (attempt_id) REFERENCES exam_attempt(attempt_id),
    FOREIGN KEY (option_id, question_id) REFERENCES question_option(option_id, question_id)
);

CREATE TABLE result (
    attempt_id      INT PRIMARY KEY,
    marks_obtained  DECIMAL(7,2) NOT NULL,
    total_marks     DECIMAL(7,2) NOT NULL,
    correct_count   INT NOT NULL,
    wrong_count     INT NOT NULL,
    skipped_count   INT NOT NULL,
    percentage      DECIMAL(6,2) NOT NULL,
    generated_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (attempt_id) REFERENCES exam_attempt(attempt_id)
);

-- ---------------------------------------------------------------------
-- ACTIVITY LOG (also written to a file by the C++ server)
-- ---------------------------------------------------------------------
CREATE TABLE activity_log (
    log_id       BIGINT AUTO_INCREMENT PRIMARY KEY,
    event_time   DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    actor_type   ENUM('ADMIN','FACULTY','STUDENT','SYSTEM') NOT NULL,
    actor_id     INT NULL,
    action       VARCHAR(60) NOT NULL,
    details      VARCHAR(500) NULL,
    INDEX idx_log_time (event_time)
);

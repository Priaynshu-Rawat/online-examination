HOW TO INSTALL THE DATABASE (MySQL 8.0.16 or newer, MySQL Workbench)

Run the files in THIS ORDER (File > Run SQL Script... or open each file and press the lightning button):
  1. schema.sql       creates the database online_exam and all tables
  2. views.sql        saved reports (analysis, register, live monitor...)
  3. procedures.sql   stored procedures the C++ server calls
  4. triggers.sql     automatic rules (flags, duplicate block, time checks...)
  5. sample_data.sql  OPTIONAL: demo faculty, students, questions and one exam

WARNING: schema.sql starts with DROP DATABASE online_exam - it wipes the old copy.

If any file shows an error, copy the exact error text and send it to Claude.

-- Creates the MySQL account the C++ server uses (run once in MySQL Workbench as root,
-- AFTER schema.sql). Use the same password in backend/config.json.
--
-- mysql_native_password is used because the MariaDB connector connects to it without extra
-- setup (MySQL 8.0 still supports it). If you prefer the default plugin and see an
-- "authentication plugin" error, keep this line as it is.
CREATE USER IF NOT EXISTS 'exam_app'@'localhost' IDENTIFIED WITH mysql_native_password BY 'ChangeThisPassword1';
CREATE USER IF NOT EXISTS 'exam_app'@'127.0.0.1' IDENTIFIED WITH mysql_native_password BY 'ChangeThisPassword1';
GRANT SELECT, INSERT, UPDATE, DELETE, EXECUTE ON online_exam.* TO 'exam_app'@'localhost';
GRANT SELECT, INSERT, UPDATE, DELETE, EXECUTE ON online_exam.* TO 'exam_app'@'127.0.0.1';
FLUSH PRIVILEGES;

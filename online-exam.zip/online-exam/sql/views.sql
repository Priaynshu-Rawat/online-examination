-- =====================================================================
-- VIEWS (saved reports)
-- =====================================================================
USE online_exam;

-- exam status from the clock + the faculty's manual switch
CREATE VIEW v_exam_status AS
SELECT e.exam_id, e.subject_id, e.created_by, e.title, e.start_time, e.end_time,
       e.duration_minutes, e.is_active,
       CASE WHEN e.is_active = 0       THEN 'DEACTIVATED'
            WHEN NOW() <  e.start_time THEN 'UPCOMING'
            WHEN NOW() <  e.end_time   THEN 'OPEN'
            ELSE 'CLOSED' END AS status
FROM exam e;

-- one attempt per student per exam that counts: the LATEST finished attempt
CREATE VIEW v_counted_attempt AS
SELECT a.attempt_id, a.exam_id, a.student_id, a.attempt_no, a.status, a.flag_count
FROM exam_attempt a
WHERE a.status <> 'IN_PROGRESS'
  AND a.attempt_no = (SELECT MAX(b.attempt_no) FROM exam_attempt b
                      WHERE b.exam_id = a.exam_id AND b.student_id = a.student_id
                        AND b.status <> 'IN_PROGRESS');

CREATE VIEW v_counted_result AS
SELECT ca.exam_id, ca.student_id, ca.attempt_id, ca.attempt_no, ca.status, ca.flag_count,
       r.marks_obtained, r.total_marks, r.percentage,
       r.correct_count, r.wrong_count, r.skipped_count
FROM v_counted_attempt ca
JOIN result r ON r.attempt_id = ca.attempt_id;

-- core of the marking: for every attempt x question, was it CORRECT/WRONG/SKIPPED/FREE?
-- all-or-nothing: correct only if selected set = correct set
CREATE VIEW v_attempt_question_outcome AS
SELECT t.attempt_id, t.exam_id, t.student_id, t.question_id, t.q_status, t.marks,
       t.selected_cnt, t.correct_sel, t.total_correct, t.outcome,
       CASE t.outcome WHEN 'CORRECT' THEN t.marks
                      WHEN 'FREE'    THEN t.marks
                      WHEN 'WRONG'   THEN -t.negative_marks
                      ELSE 0 END AS marks_earned
FROM (
    SELECT a.attempt_id, a.exam_id, a.student_id, eq.question_id,
           eq.status AS q_status, eq.marks, e.negative_marks,
           COALESCE(sel.selected_cnt, 0) AS selected_cnt,
           COALESCE(sel.correct_sel, 0)  AS correct_sel,
           tc.total_correct,
           CASE WHEN eq.status = 'FREE_MARKS'              THEN 'FREE'
                WHEN COALESCE(sel.selected_cnt, 0) = 0     THEN 'SKIPPED'
                WHEN sel.selected_cnt = sel.correct_sel
                 AND sel.correct_sel  = tc.total_correct   THEN 'CORRECT'
                ELSE 'WRONG' END AS outcome
    FROM exam_attempt a
    JOIN exam e           ON e.exam_id = a.exam_id
    JOIN exam_question eq ON eq.exam_id = a.exam_id
                         AND eq.status IN ('ACTIVE','FREE_MARKS')
    JOIN (SELECT question_id, SUM(is_correct) AS total_correct
          FROM question_option GROUP BY question_id) tc
                          ON tc.question_id = eq.question_id
    LEFT JOIN (SELECT an.attempt_id, an.question_id,
                      COUNT(*) AS selected_cnt, SUM(o.is_correct) AS correct_sel
               FROM answer an
               JOIN question_option o ON o.option_id = an.option_id
               GROUP BY an.attempt_id, an.question_id) sel
                          ON sel.attempt_id = a.attempt_id
                         AND sel.question_id = eq.question_id
) t;

-- EXAM ANALYSIS: per question - how many correct / wrong / skipped
CREATE VIEW v_question_stats AS
SELECT o.exam_id, o.question_id, eq.display_order, q.question_text,
       COUNT(*)                          AS students,
       SUM(o.outcome = 'CORRECT')        AS correct_cnt,
       SUM(o.outcome = 'WRONG')          AS wrong_cnt,
       SUM(o.outcome = 'SKIPPED')        AS skipped_cnt,
       ROUND(100 * SUM(o.outcome = 'CORRECT') / COUNT(*), 1) AS pct_correct,
       ROUND(100 * SUM(o.outcome = 'WRONG')   / COUNT(*), 1) AS pct_wrong,
       ROUND(100 * SUM(o.outcome = 'SKIPPED') / COUNT(*), 1) AS pct_skipped
FROM v_attempt_question_outcome o
JOIN v_counted_attempt ca ON ca.attempt_id = o.attempt_id
JOIN exam_question eq     ON eq.exam_id = o.exam_id AND eq.question_id = o.question_id
JOIN question q           ON q.question_id = o.question_id
WHERE o.q_status = 'ACTIVE'
GROUP BY o.exam_id, o.question_id, eq.display_order, q.question_text;

-- EXAM ANALYSIS: how many students picked each option
CREATE VIEW v_option_stats AS
SELECT eq.exam_id, opt.question_id, opt.option_id, opt.label, opt.option_text,
       opt.is_correct, COUNT(ca.attempt_id) AS chosen_count
FROM exam_question eq
JOIN question_option opt ON opt.question_id = eq.question_id
LEFT JOIN answer ans     ON ans.option_id = opt.option_id
LEFT JOIN v_counted_attempt ca ON ca.attempt_id = ans.attempt_id AND ca.exam_id = eq.exam_id
GROUP BY eq.exam_id, opt.question_id, opt.option_id, opt.label, opt.option_text, opt.is_correct;

-- EXAM ANALYSIS: summary box at the top of the analysis page
CREATE VIEW v_exam_summary AS
SELECT e.exam_id, e.title, e.subject_id,
       (SELECT COUNT(*) FROM enrollment en WHERE en.subject_id = e.subject_id) AS enrolled,
       COUNT(cr.attempt_id)                       AS attempted,
       ROUND(AVG(cr.marks_obtained), 2)           AS avg_marks,
       MAX(cr.marks_obtained)                     AS max_marks,
       MIN(cr.marks_obtained)                     AS min_marks,
       ROUND(100 * SUM(cr.percentage >= e.pass_percentage) / NULLIF(COUNT(cr.attempt_id), 0), 1) AS pass_rate
FROM exam e
LEFT JOIN v_counted_result cr ON cr.exam_id = e.exam_id
GROUP BY e.exam_id, e.title, e.subject_id, e.pass_percentage;

CREATE VIEW v_leaderboard AS
SELECT cr.exam_id, cr.student_id, s.roll_no, s.name, cr.marks_obtained, cr.percentage,
       RANK() OVER (PARTITION BY cr.exam_id ORDER BY cr.marks_obtained DESC) AS rank_no
FROM v_counted_result cr
JOIN student s ON s.student_id = cr.student_id;

-- LIVE MONITORING PANEL (faculty): who is attempting right now
CREATE VIEW v_live_monitor AS
SELECT a.attempt_id, a.exam_id, s.roll_no, s.name, a.attempt_no,
       a.joined_at, a.deadline,
       GREATEST(0, TIMESTAMPDIFF(SECOND, NOW(), a.deadline)) AS seconds_left,
       a.flag_count,
       (SELECT COUNT(*) FROM attempt_event ev
         WHERE ev.attempt_id = a.attempt_id AND ev.event_type = 'RESUMED') AS resume_count,
       (SELECT COUNT(DISTINCT an.question_id) FROM answer an
         WHERE an.attempt_id = a.attempt_id) AS answered,
       a.last_heartbeat
FROM exam_attempt a
JOIN student s ON s.student_id = a.student_id
WHERE a.status = 'IN_PROGRESS';

-- REGISTER SHEET: one row per enrolled student per exam (absent students included).
-- Shows the attempt that counts (the latest finished one).
CREATE VIEW v_exam_register AS
SELECT e.exam_id, e.subject_id, e.end_time, s.roll_no, s.student_id, s.name, s.email,
       CASE WHEN a.attempt_id IS NULL      THEN 'ABSENT'
            WHEN a.status = 'SUBMITTED'    THEN 'ATTEMPTED'
            WHEN a.status = 'AUTO_TIMEOUT' THEN 'AUTO-SUBMITTED (time)'
            WHEN a.status = 'AUTO_FLAGS'   THEN 'AUTO-SUBMITTED (flags)'
            ELSE 'IN PROGRESS' END AS status,
       a.attempt_no, a.joined_at, a.submit_time,
       TIMESTAMPDIFF(MINUTE, a.joined_at, a.submit_time) AS minutes_taken,
       r.correct_count, r.wrong_count, r.skipped_count,
       r.marks_obtained, r.total_marks, r.percentage,
       a.flag_count,
       CASE WHEN a.flag_count IS NULL OR a.flag_count = 0 THEN 'none'
            WHEN a.flag_count < 3 THEN 'yellow'
            WHEN a.flag_count < 5 THEN 'orange'
            ELSE 'red' END AS flag_level,
       (SELECT COUNT(*) FROM attempt_event ev
         WHERE ev.attempt_id = a.attempt_id AND ev.event_type = 'RESUMED') AS resume_count
FROM exam e
JOIN enrollment en ON en.subject_id = e.subject_id
JOIN student s     ON s.student_id = en.student_id
LEFT JOIN exam_attempt a
       ON a.exam_id = e.exam_id AND a.student_id = s.student_id
      AND a.attempt_no = (SELECT MAX(b.attempt_no) FROM exam_attempt b
                          WHERE b.exam_id = e.exam_id AND b.student_id = s.student_id
                            AND b.status <> 'IN_PROGRESS')
LEFT JOIN result r ON r.attempt_id = a.attempt_id;

-- STUDENT PROFILE: every exam of every subject the student is enrolled in,
-- all attempts, and which attempt counts for marks
CREATE VIEW v_student_exam_history AS
SELECT en.student_id, e.subject_id, e.exam_id, e.title, e.start_time, e.end_time,
       a.attempt_id, a.attempt_no, a.status, a.flag_count,
       r.marks_obtained, r.total_marks, r.percentage,
       (a.attempt_no = (SELECT MAX(b.attempt_no) FROM exam_attempt b
                        WHERE b.exam_id = e.exam_id AND b.student_id = en.student_id
                          AND b.status <> 'IN_PROGRESS')) AS counts_for_marks
FROM enrollment en
JOIN exam e ON e.subject_id = en.subject_id
LEFT JOIN exam_attempt a ON a.exam_id = e.exam_id AND a.student_id = en.student_id
LEFT JOIN result r ON r.attempt_id = a.attempt_id;

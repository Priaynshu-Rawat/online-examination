-- =====================================================================
-- SAMPLE DATA for testing (passwords are placeholders, not real hashes)
-- =====================================================================
USE online_exam;

INSERT INTO admin (name, email, password_hash) VALUES ('Admin One', 'admin@college.edu', 'hash_placeholder');

INSERT INTO faculty (name, email, password_hash) VALUES
 ('Prof. Sharma', 'sharma@college.edu', 'hash_placeholder'),
 ('Prof. Verma',  'verma@college.edu',  'hash_placeholder');

INSERT INTO subject (code, name) VALUES ('OS101', 'Operating Systems'), ('DB101', 'Database Systems');

INSERT INTO faculty_subject VALUES (1, 1), (1, 2), (2, 1);

INSERT INTO student (roll_no, name, email, password_hash) VALUES
 ('R001', 'Asha Rao',   'asha@college.edu',   'hash_placeholder'),
 ('R002', 'Bhanu Singh','bhanu@college.edu',  'hash_placeholder'),
 ('R003', 'Chitra Nair','chitra@college.edu', 'hash_placeholder'),
 ('R004', 'Dev Patel',  'dev@college.edu',    'hash_placeholder');

INSERT INTO enrollment VALUES (1,1),(2,1),(3,1),(4,1);   -- all four study OS

-- four questions by Prof. Sharma for OS
INSERT INTO question (subject_id, created_by, question_text, question_type) VALUES
 (1, 1, 'What is a deadlock?', 'SINGLE'),
 (1, 1, 'Which of these are CPU scheduling algorithms?', 'MULTIPLE'),
 (1, 1, 'Which of these is a synchronization primitive?', 'SINGLE'),
 (1, 1, 'Which of these are valid process states?', 'MULTIPLE');

INSERT INTO question_option (question_id, label, option_text, is_correct) VALUES
 (1,'A','A type of virus',0), (1,'B','Processes waiting on each other forever',1),
 (1,'C','A fast CPU',0),      (1,'D','A memory chip',0),
 (2,'A','FCFS',1), (2,'B','Round Robin',1), (2,'C','B-Tree',0), (2,'D','Hashing',0),
 (3,'A','Compiler',0), (3,'B','Mutex',1), (3,'C','Router',0), (3,'D','Pixel',0),
 (4,'A','Ready',1), (4,'B','Running',1), (4,'C','Compiled',0), (4,'D','Printed',0);

-- Prof. Sharma's exam (starts in the future; tests move the time later)
INSERT INTO exam (subject_id, created_by, title, start_time, duration_minutes, negative_marks)
VALUES (1, 1, 'OS Unit Test 1', NOW() + INTERVAL 1 HOUR, 30, 0);

INSERT INTO exam_question (exam_id, question_id, marks, display_order) VALUES
 (1, 1, 1, 1), (1, 2, 2, 2), (1, 3, 1, 3), (1, 4, 2, 4);   -- total 6 marks

-- =====================================================================
-- STORED PROCEDURES (saved routines the C++ server calls)
-- =====================================================================
USE online_exam;
DELIMITER $$

-- ---------------------------------------------------------------------
-- MARKING: calculates (or recalculates) the result of one finished attempt
-- ---------------------------------------------------------------------
CREATE PROCEDURE generate_result(IN p_attempt INT)
BEGIN
    REPLACE INTO result (attempt_id, marks_obtained, total_marks,
                         correct_count, wrong_count, skipped_count, percentage)
    SELECT p_attempt,
           COALESCE(SUM(marks_earned), 0),
           COALESCE(SUM(marks), 0),
           COALESCE(SUM(outcome IN ('CORRECT','FREE')), 0),
           COALESCE(SUM(outcome = 'WRONG'), 0),
           COALESCE(SUM(outcome = 'SKIPPED'), 0),
           IF(SUM(marks) > 0, ROUND(100 * SUM(marks_earned) / SUM(marks), 2), 0)
    FROM v_attempt_question_outcome
    WHERE attempt_id = p_attempt;
END$$

-- recalculates every finished attempt of an exam in ONE statement (set-based, no loop)
CREATE PROCEDURE recalc_exam_results(IN p_exam INT)
BEGIN
    REPLACE INTO result (attempt_id, marks_obtained, total_marks,
                         correct_count, wrong_count, skipped_count, percentage)
    SELECT o.attempt_id,
           COALESCE(SUM(o.marks_earned), 0),
           COALESCE(SUM(o.marks), 0),
           COALESCE(SUM(o.outcome IN ('CORRECT','FREE')), 0),
           COALESCE(SUM(o.outcome = 'WRONG'), 0),
           COALESCE(SUM(o.outcome = 'SKIPPED'), 0),
           IF(SUM(o.marks) > 0, ROUND(100 * SUM(o.marks_earned) / SUM(o.marks), 2), 0)
    FROM v_attempt_question_outcome o
    WHERE o.exam_id = p_exam
      AND o.attempt_id IN (SELECT attempt_id FROM exam_attempt
                           WHERE exam_id = p_exam AND status <> 'IN_PROGRESS')
    GROUP BY o.attempt_id;
END$$

-- ---------------------------------------------------------------------
-- FIX A BAD QUESTION: p_mode = 'DROP' (remove it) or 'FREE' (marks to all)
-- ---------------------------------------------------------------------
CREATE PROCEDURE fix_question(IN p_faculty INT, IN p_exam INT, IN p_question INT, IN p_mode VARCHAR(4))
BEGIN
    -- all checks first; then the status change + recalculation + log are ONE transaction
    -- (if anything fails inside, the C++ server issues ROLLBACK and nothing is half-done)
    IF NOT EXISTS (SELECT 1 FROM exam WHERE exam_id = p_exam AND created_by = p_faculty) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Only the faculty who made the exam can change it';
    END IF;
    IF p_mode NOT IN ('DROP','FREE') THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Mode must be DROP or FREE';
    END IF;

    START TRANSACTION;
    IF p_mode = 'DROP' THEN
        UPDATE exam_question SET status = 'DROPPED'
         WHERE exam_id = p_exam AND question_id = p_question;
    ELSE
        UPDATE exam_question SET status = 'FREE_MARKS'
         WHERE exam_id = p_exam AND question_id = p_question;
    END IF;
    CALL recalc_exam_results(p_exam);
    INSERT INTO activity_log (actor_type, actor_id, action, details)
    VALUES ('FACULTY', p_faculty, 'FIX_QUESTION',
            CONCAT('exam=', p_exam, ' question=', p_question, ' mode=', p_mode));
    COMMIT;
END$$

-- ---------------------------------------------------------------------
-- DUPLICATE CHECK (other faculty): is this question used by ANOTHER faculty
-- in an exam of the same subject that has not finished yet?
-- Returns the full question + options so the pop-up can show them.
-- ---------------------------------------------------------------------
CREATE PROCEDURE check_cross_faculty_duplicate(IN p_exam INT, IN p_question INT)
BEGIN
    DECLARE v_hash CHAR(64);
    DECLARE v_subject INT;
    DECLARE v_faculty INT;

    SELECT question_hash INTO v_hash FROM question WHERE question_id = p_question;
    SELECT subject_id, created_by INTO v_subject, v_faculty FROM exam WHERE exam_id = p_exam;

    SELECT f.name  AS faculty_name,
           e.title AS exam_title,
           e.start_time,
           q.question_id,
           q.question_text,
           q.question_type,
           (SELECT GROUP_CONCAT(CONCAT(o.label, ') ', o.option_text,
                                IF(o.is_correct = 1, '  [correct]', ''))
                                ORDER BY o.label SEPARATOR '\n')
              FROM question_option o WHERE o.question_id = q.question_id) AS options_text
    FROM exam_question eq
    JOIN exam e     ON e.exam_id = eq.exam_id
    JOIN faculty f  ON f.faculty_id = e.created_by
    JOIN question q ON q.question_id = eq.question_id
    WHERE eq.question_hash = v_hash
      AND e.subject_id = v_subject
      AND e.created_by <> v_faculty
      AND e.exam_id <> p_exam
      AND e.end_time > NOW()
    ORDER BY e.start_time;
END$$

-- ---------------------------------------------------------------------
-- PAPER CHECK before the exam is activated. Empty result = paper is fine.
-- ---------------------------------------------------------------------
CREATE PROCEDURE validate_paper(IN p_exam INT)
BEGIN
    SELECT NULL AS question_id, 'Paper has no questions' AS problem
    FROM (SELECT 1) x
    WHERE NOT EXISTS (SELECT 1 FROM exam_question WHERE exam_id = p_exam)
    UNION ALL
    SELECT q.question_id, 'Fewer than 2 options'
    FROM exam_question eq JOIN question q ON q.question_id = eq.question_id
    WHERE eq.exam_id = p_exam
      AND (SELECT COUNT(*) FROM question_option o WHERE o.question_id = q.question_id) < 2
    UNION ALL
    SELECT q.question_id, 'Single-answer question must have exactly 1 correct option'
    FROM exam_question eq JOIN question q ON q.question_id = eq.question_id
    WHERE eq.exam_id = p_exam AND q.question_type = 'SINGLE'
      AND (SELECT COALESCE(SUM(o.is_correct), 0) FROM question_option o WHERE o.question_id = q.question_id) <> 1
    UNION ALL
    SELECT q.question_id, 'Multiple-answer question must have at least 2 correct options'
    FROM exam_question eq JOIN question q ON q.question_id = eq.question_id
    WHERE eq.exam_id = p_exam AND q.question_type = 'MULTIPLE'
      AND (SELECT COALESCE(SUM(o.is_correct), 0) FROM question_option o WHERE o.question_id = q.question_id) < 2
    UNION ALL
    SELECT MIN(eq.question_id), 'Repeated question in paper'
    FROM exam_question eq
    WHERE eq.exam_id = p_exam
    GROUP BY eq.question_hash
    HAVING COUNT(*) > 1;
END$$

-- ---------------------------------------------------------------------
-- STUDENT PRESSES JOIN / RESUME
-- p_mode returns JOINED, RESUMED or RETAKE
-- ---------------------------------------------------------------------
CREATE PROCEDURE join_exam(IN p_exam INT, IN p_student INT, IN p_order JSON,
                           OUT p_attempt INT, OUT p_mode VARCHAR(10))
BEGIN
    DECLARE v_deadline DATETIME;
    DECLARE v_next INT;

    SET p_attempt = NULL;
    SELECT attempt_id, deadline INTO p_attempt, v_deadline
    FROM exam_attempt
    WHERE exam_id = p_exam AND student_id = p_student AND status = 'IN_PROGRESS'
    LIMIT 1;

    IF p_attempt IS NOT NULL THEN
        -- RESUME: same attempt, same order, same saved answers
        IF NOW() >= v_deadline THEN
            UPDATE exam_attempt SET status = 'AUTO_TIMEOUT', submit_time = v_deadline
             WHERE attempt_id = p_attempt;
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Exam time is over';
        END IF;
        INSERT INTO attempt_event (attempt_id, event_type) VALUES (p_attempt, 'RESUMED');
        UPDATE exam_attempt SET last_heartbeat = NOW() WHERE attempt_id = p_attempt;
        SET p_mode = 'RESUMED';
    ELSE
        SELECT COALESCE(MAX(attempt_no), 0) + 1 INTO v_next
        FROM exam_attempt WHERE exam_id = p_exam AND student_id = p_student;

        -- the trigger checks enrollment, time window, retake permission
        INSERT INTO exam_attempt (exam_id, student_id, attempt_no, question_order, last_heartbeat)
        VALUES (p_exam, p_student, v_next, p_order, NOW());
        -- look the new row up by its key (LAST_INSERT_ID can be disturbed by trigger inserts)
        SELECT attempt_id INTO p_attempt FROM exam_attempt
         WHERE exam_id = p_exam AND student_id = p_student AND attempt_no = v_next;
        IF v_next > 1 OR NOW() >= (SELECT end_time FROM exam WHERE exam_id = p_exam) THEN
            SET p_mode = 'RETAKE';
        ELSE
            SET p_mode = 'JOINED';
        END IF;
        INSERT INTO attempt_event (attempt_id, event_type, note) VALUES (p_attempt, 'JOINED', p_mode);
    END IF;
END$$

-- ---------------------------------------------------------------------
-- SUBMIT: p_auto = 0 student pressed submit, 1 timer ran out
-- the trigger on exam_attempt then calls generate_result
-- ---------------------------------------------------------------------
CREATE PROCEDURE submit_attempt(IN p_attempt INT, IN p_auto TINYINT)
BEGIN
    IF p_auto = 1 THEN
        UPDATE exam_attempt SET status = 'AUTO_TIMEOUT', submit_time = LEAST(NOW(), deadline)
         WHERE attempt_id = p_attempt AND status = 'IN_PROGRESS';
    ELSE
        UPDATE exam_attempt SET status = 'SUBMITTED', submit_time = NOW()
         WHERE attempt_id = p_attempt AND status = 'IN_PROGRESS';
    END IF;

    IF ROW_COUNT() > 0 THEN
        IF p_auto = 1 THEN
            INSERT INTO attempt_event (attempt_id, event_type, note) VALUES (p_attempt, 'SUBMITTED', 'auto: time over');
        ELSE
            INSERT INTO attempt_event (attempt_id, event_type, note) VALUES (p_attempt, 'SUBMITTED', 'by student');
        END IF;
    END IF;
END$$

-- ---------------------------------------------------------------------
-- CRASH RECOVERY: run when the server starts.
-- 1) attempts whose time is over are submitted with their saved answers
-- 2) the remaining in-progress attempts are returned so the C++ server
--    can rebuild its session table; students simply resume.
-- ---------------------------------------------------------------------
CREATE PROCEDURE recover_sessions()
BEGIN
    DECLARE v_expired INT DEFAULT 0;
    DECLARE v_alive INT DEFAULT 0;

    UPDATE exam_attempt
       SET status = 'AUTO_TIMEOUT', submit_time = deadline
     WHERE status = 'IN_PROGRESS' AND deadline <= NOW();
    SET v_expired = ROW_COUNT();

    SELECT COUNT(*) INTO v_alive FROM exam_attempt WHERE status = 'IN_PROGRESS';

    INSERT INTO activity_log (actor_type, action, details)
    VALUES ('SYSTEM', 'RECOVERY',
            CONCAT('server started: ', v_alive, ' sessions restored, ', v_expired, ' auto-submitted'));

    SELECT attempt_id, exam_id, student_id, attempt_no, deadline, flag_count, question_order
    FROM exam_attempt
    WHERE status = 'IN_PROGRESS';
END$$

-- ---------------------------------------------------------------------
-- RESULTS AND STUDENT RECORDS (faculty)
-- ---------------------------------------------------------------------
-- the register sheet of one exam: every enrolled student, absent or not
CREATE PROCEDURE get_exam_register(IN p_faculty INT, IN p_exam INT)
BEGIN
    DECLARE v_subject INT;
    DECLARE v_end DATETIME;

    SELECT subject_id, end_time INTO v_subject, v_end FROM exam WHERE exam_id = p_exam;
    IF v_subject IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Exam not found';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM faculty_subject WHERE faculty_id = p_faculty AND subject_id = v_subject) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'You do not teach this subject';
    END IF;
    IF NOW() < v_end THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Exam is still running; use the live monitor';
    END IF;

    SELECT roll_no, student_id, name, email, status, attempt_no, joined_at, submit_time,
           minutes_taken, correct_count, wrong_count, skipped_count,
           marks_obtained, total_marks, percentage, flag_count, flag_level, resume_count
    FROM v_exam_register
    WHERE exam_id = p_exam
    ORDER BY roll_no;
END$$

-- one student's whole history in one subject (every exam, every attempt)
CREATE PROCEDURE get_student_subject_history(IN p_faculty INT, IN p_student INT, IN p_subject INT)
BEGIN
    IF NOT EXISTS (SELECT 1 FROM faculty_subject WHERE faculty_id = p_faculty AND subject_id = p_subject) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'You do not teach this subject';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM enrollment WHERE student_id = p_student AND subject_id = p_subject) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Student is not enrolled in this subject';
    END IF;

    SELECT exam_id, title, start_time, attempt_id, attempt_no, status, flag_count,
           marks_obtained, total_marks, percentage, counts_for_marks
    FROM v_student_exam_history
    WHERE student_id = p_student AND subject_id = p_subject AND end_time <= NOW()
    ORDER BY start_time, attempt_no;
END$$

-- answer review of one attempt, in the ORIGINAL paper order
CREATE PROCEDURE get_attempt_review(IN p_attempt INT)
BEGIN
    SELECT eq.display_order, q.question_text, q.question_type, o.outcome, o.marks_earned,
           (SELECT GROUP_CONCAT(op.label ORDER BY op.label)
              FROM answer an JOIN question_option op ON op.option_id = an.option_id
             WHERE an.attempt_id = p_attempt AND an.question_id = o.question_id) AS selected,
           (SELECT GROUP_CONCAT(op.label ORDER BY op.label)
              FROM question_option op
             WHERE op.question_id = o.question_id AND op.is_correct = 1) AS correct
    FROM v_attempt_question_outcome o
    JOIN exam_question eq ON eq.exam_id = o.exam_id AND eq.question_id = o.question_id
    JOIN question q       ON q.question_id = o.question_id
    WHERE o.attempt_id = p_attempt
    ORDER BY eq.display_order;
END$$

-- timeline of leaves/returns of one attempt, with time away
CREATE PROCEDURE get_attempt_timeline(IN p_attempt INT)
BEGIN
    SELECT event_type, event_time, note,
           CASE WHEN event_type = 'LEFT'
                THEN TIMESTAMPDIFF(SECOND, event_time, next_time) END AS seconds_away
    FROM (SELECT event_id, event_type, event_time, note,
                 LEAD(event_time) OVER (ORDER BY event_time, event_id) AS next_time
          FROM attempt_event WHERE attempt_id = p_attempt) t
    ORDER BY event_time, event_id;
END$$

DELIMITER ;

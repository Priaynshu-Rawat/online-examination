# Online Examination System - setup on Windows (VS Code + MySQL Workbench)

You need: MySQL 8 + Workbench (you already have it), VS Code, and the C++ tools below.
Do the steps in order. If any step shows an error, copy the exact error text and send it to Claude.

## Step 1 - Database (MySQL Workbench)
Open each file with File > Open SQL Script and run it (lightning button) IN THIS ORDER:
1. `sql/schema.sql`   2. `sql/views.sql`   3. `sql/procedures.sql`   4. `sql/triggers.sql`
5. `sql/sample_data.sql` (optional demo data)   6. `sql/create_user.sql` (creates the account the server uses)

Expected after steps 1-4 (check with Workbench): 16 tables, 11 views, 12 procedures, 11 triggers.
Change the password inside `create_user.sql` if you like - then use the same one in `config.json`.

## Step 2 - C++ tools (MSYS2, one time)
1. Install MSYS2 from https://www.msys2.org (default folder C:\msys64).
2. Open the **"MSYS2 UCRT64"** program from the Start menu (NOT the other MSYS2 icons) and run:
```
pacman -Syu
pacman -S --needed mingw-w64-ucrt-x86_64-gcc mingw-w64-ucrt-x86_64-cmake mingw-w64-ucrt-x86_64-ninja mingw-w64-ucrt-x86_64-libsodium mingw-w64-ucrt-x86_64-libmariadbclient
```
(If the window closes after `pacman -Syu`, open it again and run the second command.)

## Step 3 - Build (in the same UCRT64 window)
Replace the path with where you put the project:
```
cd /c/Users/YOURNAME/online-exam/backend
cmake -S . -B build -G Ninja
cmake --build build
```
You get `backend/build/exam_server.exe`.

## Step 4 - Configure
Copy `backend/config.example.json` to `backend/config.json` and put your MySQL password in it
(user `exam_app`, database `online_exam`).

## Step 5 - Demo passwords, then run (run from the `backend` folder)
```
./build/exam_server.exe --set-demo-passwords      # all sample accounts get the password  password123
./build/exam_server.exe                           # starts the server, keep this window open
```
Open **http://localhost:8080** in Chrome/Edge.

Sample logins (password `password123`): admin@college.edu (Admin), sharma@college.edu and verma@college.edu (Faculty),
asha@college.edu, bhanu@college.edu, chitra@college.edu, dev@college.edu (Students).
Your own admin: `./build/exam_server.exe --create-admin "Your Name" you@mail.com YourPassword`

The sample exam is already in the past (it was made for the demo). Log in as faculty and create a new exam
that starts a few minutes from now to see the live features.

## Using VS Code
Open the `online-exam` folder in VS Code. Install the "C/C++" and "CMake Tools" extensions if you want editor help.
Building and running is easiest in the MSYS2 UCRT64 window as shown above.

## Common problems
- *Could not start: Cannot connect to MySQL* - MySQL service not running, or wrong password/user in `config.json`.
- *Authentication plugin error* - run `create_user.sql` exactly as given (it uses mysql_native_password).
- *Could not listen on port 8080* - another program uses it; change `port` in `config.json`.
- *cmake: MariaDB Connector/C not found* - you opened the wrong MSYS2 window; use "MSYS2 UCRT64".
- *Page says "web folder not found"* - start the server from the `backend` folder.
- To let other computers (students on the same Wi-Fi) join: allow port 8080 in Windows Firewall and open
  `http://YOUR-PC-IP:8080` on their devices.

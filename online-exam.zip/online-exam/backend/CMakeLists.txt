cmake_minimum_required(VERSION 3.16)
project(online_exam CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
if(NOT CMAKE_BUILD_TYPE)
  set(CMAKE_BUILD_TYPE Release)
endif()

# --- libraries that must be installed on your computer -------------------------------------
#   MariaDB Connector/C (talks to MySQL)    and    libsodium (password hashing, random tokens)
find_path(MARIADB_INCLUDE_DIR mysql.h PATH_SUFFIXES mariadb mysql)
find_library(MARIADB_LIB NAMES mariadb libmariadb mariadbclient)
find_path(SODIUM_INCLUDE_DIR sodium.h)
find_library(SODIUM_LIB NAMES sodium libsodium)
if(NOT MARIADB_INCLUDE_DIR OR NOT MARIADB_LIB)
  message(FATAL_ERROR "MariaDB Connector/C not found (see SETUP_WINDOWS.md, step 2)")
endif()
if(NOT SODIUM_INCLUDE_DIR OR NOT SODIUM_LIB)
  message(FATAL_ERROR "libsodium not found (see SETUP_WINDOWS.md, step 2)")
endif()
find_package(Threads REQUIRED)

add_executable(exam_server
  src/main.cpp
  src/auth_routes.cpp
  src/student_routes.cpp
  src/faculty_question_routes.cpp
  src/faculty_exam_routes.cpp
  src/faculty_report_routes.cpp
  src/admin_routes.cpp)

# third_party holds httplib.h and json.hpp (header-only libraries, nothing to install)
target_include_directories(exam_server PRIVATE third_party src ${MARIADB_INCLUDE_DIR} ${SODIUM_INCLUDE_DIR})
target_link_libraries(exam_server PRIVATE ${MARIADB_LIB} ${SODIUM_LIB} Threads::Threads)

if(SODIUM_LIB MATCHES "\\.a$")
  target_compile_definitions(exam_server PRIVATE SODIUM_STATIC=1)
endif()
if(WIN32)
  target_link_libraries(exam_server PRIVATE ws2_32)
  target_compile_definitions(exam_server PRIVATE _WIN32_WINNT=0x0A00)
endif()
if(MSVC)
  target_compile_options(exam_server PRIVATE /W3 /utf-8)
else()
  target_compile_options(exam_server PRIVATE -Wall -Wextra -Wno-unused-parameter)
endif()

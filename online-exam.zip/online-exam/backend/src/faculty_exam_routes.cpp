// faculty_exam_routes.cpp : the faculty's EXAMS
//   create / edit / activate, build the paper (with both duplicate checks), clone,
//   random pick, fix a bad question, allow a retake, live monitoring
#include <map>
#include <mutex>
#include <regex>

#include "http_common.hpp"

namespace {

bool truthy(const json& v) {
    if (v.is_null()) return false;
    if (v.is_boolean()) return v.get<bool>();
    if (v.is_number()) return v.get<double>() != 0;
    return false;
}

// "2026-11-10 14:30:00" ?
bool valid_datetime(const std::string& s) {
    static const std::regex re(R"(^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$)");
    return std::regex_match(s, re);
}

// OS concept: a lock per subject. The "is it already used?" check and the insert into the paper
// must happen together (a CRITICAL SECTION). Without it, two faculty adding the same question at
// the same moment could both pass the check and both insert it.
std::mutex& subject_lock(int subject_id) {
    static std::mutex table_guard;
    static std::map<int, std::mutex> locks;
    std::lock_guard<std::mutex> g(table_guard);
    return locks[subject_id];  // std::map never moves its elements, so the reference stays valid
}

enum class AddResult { ADDED, SAME_PAPER, OTHER_FACULTY };

// puts one question into a paper. Runs both duplicate checks.
AddResult add_to_paper(App& app, int faculty_id, const json& exam, int question_id, double marks, bool force,
                       json& conflicts) {
    int exam_id = exam["exam_id"].get<int>();
    int subject_id = exam["subject_id"].get<int>();
    if (marks <= 0 || marks > 100) throw HttpError(400, "Marks must be between 0 and 100");

    json q = app.db.query("SELECT subject_id, created_by FROM question WHERE question_id = ?", {question_id});
    if (q.empty()) throw HttpError(404, "Question not found");
    if (q[0]["created_by"].get<int>() != faculty_id) throw HttpError(403, "You can use only your own questions");
    if (q[0]["subject_id"].get<int>() != subject_id) throw HttpError(400, "This question belongs to a different subject");

    std::lock_guard<std::mutex> critical_section(subject_lock(subject_id));

    // check 1: the same question twice in this paper is NEVER allowed
    json same = app.db.query(
        "SELECT 1 FROM exam_question WHERE exam_id = ? AND question_hash = "
        "(SELECT question_hash FROM question WHERE question_id = ?)",
        {exam_id, question_id});
    if (!same.empty()) return AddResult::SAME_PAPER;

    // check 2: another faculty uses it in an unfinished exam of the same subject: warn
    auto sets = app.db.call("CALL check_cross_faculty_duplicate(?, ?)", {exam_id, question_id});
    conflicts = sets.empty() ? json::array() : sets[0];
    if (!conflicts.empty()) {
        if (!force) {
            app.audit("FACULTY", faculty_id, "DUPLICATE_WARNING",
                      "exam=" + std::to_string(exam_id) + " question=" + std::to_string(question_id) + " also used by " +
                          conflicts[0]["faculty_name"].get<std::string>());
            return AddResult::OTHER_FACULTY;
        }
        app.audit("FACULTY", faculty_id, "DUPLICATE_OVERRIDE",
                  "exam=" + std::to_string(exam_id) + " question=" + std::to_string(question_id) + " kept anyway");
    }

    try {
        app.db.exec(
            "INSERT INTO exam_question (exam_id, question_id, marks, display_order) "
            "SELECT ?, ?, ?, COALESCE(MAX(display_order), 0) + 1 FROM exam_question WHERE exam_id = ?",
            {exam_id, question_id, marks, exam_id});
    } catch (const DbError& e) {
        // the trigger or the unique key (the safety net) caught a repeat
        if (e.code == 1062 || (e.code == 1644 && std::string(e.what()).find("already in this paper") != std::string::npos))
            return AddResult::SAME_PAPER;
        throw;
    }
    return AddResult::ADDED;
}

json paper_questions(App& app, int exam_id) {
    json qs = app.db.query(
        "SELECT eq.question_id, eq.display_order, eq.marks, eq.status, q.question_text AS text, q.question_type AS type "
        "FROM exam_question eq JOIN question q ON q.question_id = eq.question_id "
        "WHERE eq.exam_id = ? ORDER BY eq.display_order",
        {exam_id});
    json opts = app.db.query(
        "SELECT eq.question_id, o.option_id, o.label, o.option_text AS text, o.is_correct "
        "FROM exam_question eq JOIN question_option o ON o.question_id = eq.question_id "
        "WHERE eq.exam_id = ? ORDER BY eq.question_id, o.label",
        {exam_id});
    for (auto& q : qs) q["options"] = json::array();
    for (auto& o : opts)
        for (auto& q : qs)
            if (q["question_id"] == o["question_id"]) {
                json oo = o;
                oo.erase("question_id");
                q["options"].push_back(oo);
                break;
            }
    return qs;
}

json problems_of(App& app, int exam_id) {
    auto sets = app.db.call("CALL validate_paper(?)", {exam_id});
    return sets.empty() ? json::array() : sets[0];
}

}  // namespace

void register_faculty_exam_routes(httplib::Server& svr, App& app) {
    // ---------------------------------------------------------------- list my exams
    svr.Get("/api/faculty/exams", secured(app, "faculty", [&app](const httplib::Request&, httplib::Response& res, const User& u) {
        json rows = app.db.query(
            "SELECT e.exam_id, e.title, e.subject_id, s.code AS subject_code, e.start_time, e.end_time, "
            "       e.duration_minutes, vs.status, e.is_active, "
            "       (SELECT COUNT(*) FROM exam_question eq WHERE eq.exam_id = e.exam_id AND eq.status <> 'DROPPED') AS question_count, "
            "       (SELECT COALESCE(SUM(eq.marks), 0) FROM exam_question eq WHERE eq.exam_id = e.exam_id AND eq.status <> 'DROPPED') AS total_marks, "
            "       e.results_published "
            "FROM exam e JOIN subject s ON s.subject_id = e.subject_id JOIN v_exam_status vs ON vs.exam_id = e.exam_id "
            "WHERE e.created_by = ? ORDER BY e.start_time DESC",
            {u.id});
        send_json(res, 200, {{"server_time", app.db.query("SELECT NOW() AS t")[0]["t"]}, {"exams", rows}});
    }));

    // ---------------------------------------------------------------- create (as a draft)
    svr.Post("/api/faculty/exams", secured(app, "faculty", [&app](const httplib::Request& req, httplib::Response& res, const User& u) {
        json b = read_body(req);
        int subject_id = (int)need_int(b, "subject_id");
        if (app.db.query("SELECT 1 FROM faculty_subject WHERE faculty_id = ? AND subject_id = ?", {u.id, subject_id}).empty())
            throw HttpError(403, "You do not teach this subject");
        std::string title = need_str(b, "title", 150);
        std::string start = need_str(b, "start_time", 19);
        if (!valid_datetime(start)) throw HttpError(400, "Start time must look like 2026-11-10 14:30:00");
        long long duration = need_int(b, "duration_minutes");
        if (duration < 1 || duration > 600) throw HttpError(400, "Duration must be 1 to 600 minutes");
        double neg = b.value("negative_marks", 0.0);
        double pass = b.value("pass_percentage", 40.0);
        long long flags = opt_int(b, "flag_limit", 5);
        if (neg < 0 || neg > 10) throw HttpError(400, "Negative marks must be between 0 and 10");
        if (pass < 0 || pass > 100) throw HttpError(400, "Pass percentage must be 0 to 100");
        if (flags < 1 || flags > 50) throw HttpError(400, "Flag limit must be 1 to 50");

        Lease lease = app.db.lease();
        lease.exec(
            "INSERT INTO exam (subject_id, created_by, title, instructions, start_time, duration_minutes, is_active, "
            "negative_marks, pass_percentage, flag_limit, shuffle_questions, shuffle_options) "
            "VALUES (?, ?, ?, ?, ?, ?, 0, ?, ?, ?, ?, ?)",
            {subject_id, u.id, title, opt_str(b, "instructions"), start, duration, neg, pass, flags,
             opt_bool(b, "shuffle_questions", true), opt_bool(b, "shuffle_options", true)});
        long long id = lease.insert_id();
        app.audit("FACULTY", u.id, "EXAM_CREATED", "exam=" + std::to_string(id) + " " + title);
        send_json(res, 200, {{"exam_id", id}});
    }));

    // ---------------------------------------------------------------- one exam with its paper
    svr.Get(R"(/api/faculty/exams/(\d+))", secured(app, "faculty", [&app](const httplib::Request& req, httplib::Response& res, const User& u) {
        int id = path_id(req);
        need_exam_owner(app, u.id, id);
        json exam = app.db.query(
            "SELECT e.*, vs.status FROM exam e JOIN v_exam_status vs ON vs.exam_id = e.exam_id WHERE e.exam_id = ?", {id})[0];
        json qs = paper_questions(app, id);
        double total = 0;
        for (auto& q : qs)
            if (q["status"] != "DROPPED") total += q["marks"].get<double>();
        send_json(res, 200, {{"exam", exam}, {"questions", qs}, {"total_marks", total}});
    }));

    // ---------------------------------------------------------------- change settings / activate
    svr.Put(R"(/api/faculty/exams/(\d+))", secured(app, "faculty", [&app](const httplib::Request& req, httplib::Response& res, const User& u) {
        int id = path_id(req);
        json exam = need_exam_owner(app, u.id, id);
        bool started = truthy(exam["started"]), ended = truthy(exam["ended"]);
        json b = read_body(req);

        std::string sets;
        json params = json::array();
        auto add = [&](const std::string& column, const json& value) {
            sets += (sets.empty() ? "" : ", ") + column + " = ?";
            params.push_back(value);
        };

        // these can only change before the exam starts
        const char* before_start_only[] = {"start_time", "duration_minutes", "negative_marks", "pass_percentage",
                                           "flag_limit", "shuffle_questions", "shuffle_options"};
        for (const char* k : before_start_only)
            if (b.contains(k) && started) throw HttpError(409, "The exam has already started; this setting is locked");

        if (b.contains("title")) add("title", need_str(b, "title", 150));
        if (b.contains("instructions")) add("instructions", opt_str(b, "instructions"));
        if (b.contains("start_time")) {
            std::string s = need_str(b, "start_time", 19);
            if (!valid_datetime(s)) throw HttpError(400, "Start time must look like 2026-11-10 14:30:00");
            if (app.db.query("SELECT (? > NOW()) AS ok", {s})[0]["ok"].get<int>() == 0)
                throw HttpError(400, "Start time must be in the future");
            add("start_time", s);
        }
        if (b.contains("duration_minutes")) {
            long long d = need_int(b, "duration_minutes");
            if (d < 1 || d > 600) throw HttpError(400, "Duration must be 1 to 600 minutes");
            add("duration_minutes", d);
        }
        if (b.contains("negative_marks")) {
            double n = b["negative_marks"].get<double>();
            if (n < 0 || n > 10) throw HttpError(400, "Negative marks must be between 0 and 10");
            add("negative_marks", n);
        }
        if (b.contains("pass_percentage")) {
            double p = b["pass_percentage"].get<double>();
            if (p < 0 || p > 100) throw HttpError(400, "Pass percentage must be 0 to 100");
            add("pass_percentage", p);
        }
        if (b.contains("flag_limit")) {
            long long f = need_int(b, "flag_limit");
            if (f < 1 || f > 50) throw HttpError(400, "Flag limit must be 1 to 50");
            add("flag_limit", f);
        }
        if (b.contains("shuffle_questions")) add("shuffle_questions", opt_bool(b, "shuffle_questions", true) ? 1 : 0);
        if (b.contains("shuffle_options")) add("shuffle_options", opt_bool(b, "shuffle_options", true) ? 1 : 0);
        if (b.contains("allow_answer_review")) add("allow_answer_review", opt_bool(b, "allow_answer_review", false) ? 1 : 0);
        if (b.contains("results_published")) {
            bool p = opt_bool(b, "results_published", false);
            if (p && !ended) throw HttpError(409, "You can publish results only after the exam has ended");
            add("results_published", p ? 1 : 0);
        }
        if (b.contains("is_active")) {
            bool a = opt_bool(b, "is_active", false);
            if (a) {  // the paper must pass every check before students can see the exam
                json problems = problems_of(app, id);
                if (!problems.empty()) throw HttpError(400, "The paper has problems", {{"problems", problems}});
            }
            add("is_active", a ? 1 : 0);
        }
        if (sets.empty()) throw HttpError(400, "Nothing to change");
        params.push_back(id);
        app.db.exec("UPDATE exam SET " + sets + " WHERE exam_id = ?", params);
        app.audit("FACULTY", u.id, "EXAM_UPDATED", "exam=" + std::to_string(id) + " " + b.dump().substr(0, 200));
        send_json(res, 200, {{"ok", true}});
    }));

    // ---------------------------------------------------------------- paper: add a question
    svr.Post(R"(/api/faculty/exams/(\d+)/questions)", secured(app, "faculty", [&app](const httplib::Request& req, httplib::Response& res, const User& u) {
        int id = path_id(req);
        json exam = need_exam_owner(app, u.id, id);
        if (truthy(exam["started"])) throw HttpError(409, "The exam has started; the paper can no longer be changed");
        json b = read_body(req);
        json conflicts = json::array();
        AddResult r = add_to_paper(app, u.id, exam, (int)need_int(b, "question_id"), b.value("marks", 1.0),
                                   opt_bool(b, "force", false), conflicts);
        if (r == AddResult::SAME_PAPER)
            throw HttpError(409, "This question is already in this paper", {{"kind", "SAME_PAPER"}});
        if (r == AddResult::OTHER_FACULTY)
            throw HttpError(409, "Another faculty is using this question", {{"kind", "OTHER_FACULTY"}, {"conflicts", conflicts}});
        send_json(res, 200, {{"ok", true}});
    }));

    svr.Delete(R"(/api/faculty/exams/(\d+)/questions/(\d+))", secured(app, "faculty", [&app](const httplib::Request& req, httplib::Response& res, const User& u) {
        int id = path_id(req, 1), qid = path_id(req, 2);
        json exam = need_exam_owner(app, u.id, id);
        if (truthy(exam["started"])) throw HttpError(409, "The exam has started; the paper can no longer be changed");
        app.db.exec("DELETE FROM exam_question WHERE exam_id = ? AND question_id = ?", {id, qid});
        send_json(res, 200, {{"ok", true}});
    }));

    // ---------------------------------------------------------------- paper: random pick from my bank
    svr.Post(R"(/api/faculty/exams/(\d+)/random)", secured(app, "faculty", [&app](const httplib::Request& req, httplib::Response& res, const User& u) {
        int id = path_id(req);
        json exam = need_exam_owner(app, u.id, id);
        if (truthy(exam["started"])) throw HttpError(409, "The exam has started; the paper can no longer be changed");
        json b = read_body(req);
        long long count = need_int(b, "count");
        if (count < 1 || count > 200) throw HttpError(400, "Count must be 1 to 200");
        double marks = b.value("marks", 1.0);

        json candidates = app.db.query(
            "SELECT q.question_id FROM question q WHERE q.created_by = ? AND q.subject_id = ? "
            "AND NOT EXISTS (SELECT 1 FROM exam_question eq WHERE eq.exam_id = ? AND eq.question_hash = q.question_hash) "
            "ORDER BY RAND() LIMIT ?",
            {u.id, exam["subject_id"], id, count});
        int added = 0;
        json skipped = json::array();
        for (auto& c : candidates) {
            json conflicts = json::array();
            AddResult r = add_to_paper(app, u.id, exam, c["question_id"].get<int>(), marks, false, conflicts);
            if (r == AddResult::ADDED) added++;
            else if (r == AddResult::OTHER_FACULTY)
                skipped.push_back({{"question_id", c["question_id"]},
                                   {"reason", "Used by " + conflicts[0]["faculty_name"].get<std::string>() + " in " +
                                                  conflicts[0]["exam_title"].get<std::string>()}});
        }
        if ((long long)candidates.size() < count)
            skipped.push_back({{"question_id", nullptr}, {"reason", "Only " + std::to_string(candidates.size()) + " unused questions in your bank"}});
        send_json(res, 200, {{"added", added}, {"skipped", skipped}});
    }));

    // ---------------------------------------------------------------- paper check
    svr.Post(R"(/api/faculty/exams/(\d+)/validate)", secured(app, "faculty", [&app](const httplib::Request& req, httplib::Response& res, const User& u) {
        int id = path_id(req);
        need_exam_owner(app, u.id, id);
        json problems = problems_of(app, id);
        send_json(res, 200, {{"ok", problems.empty()}, {"problems", problems}});
    }));

    // ---------------------------------------------------------------- clone
    svr.Post(R"(/api/faculty/exams/(\d+)/clone)", secured(app, "faculty", [&app](const httplib::Request& req, httplib::Response& res, const User& u) {
        int id = path_id(req);
        need_exam_owner(app, u.id, id);
        json b = read_body(req);
        std::string title = need_str(b, "title", 150), start = need_str(b, "start_time", 19);
        if (!valid_datetime(start)) throw HttpError(400, "Start time must look like 2026-11-10 14:30:00");

        Lease lease = app.db.lease();
        lease.begin();
        try {
            lease.exec(
                "INSERT INTO exam (subject_id, created_by, title, instructions, start_time, duration_minutes, is_active, "
                "negative_marks, pass_percentage, flag_limit, shuffle_questions, shuffle_options, allow_answer_review, cloned_from) "
                "SELECT subject_id, created_by, ?, instructions, ?, duration_minutes, 0, negative_marks, pass_percentage, "
                "flag_limit, shuffle_questions, shuffle_options, allow_answer_review, exam_id FROM exam WHERE exam_id = ?",
                {title, start, id});
            long long new_id = lease.insert_id();
            lease.exec(
                "INSERT INTO exam_question (exam_id, question_id, marks, display_order) "
                "SELECT ?, question_id, marks, display_order FROM exam_question WHERE exam_id = ? AND status = 'ACTIVE'",
                {new_id, id});
            lease.commit();
            app.audit("FACULTY", u.id, "EXAM_CLONED", "exam=" + std::to_string(id) + " -> " + std::to_string(new_id));
            send_json(res, 200, {{"exam_id", new_id}});
        } catch (...) {
            lease.rollback();
            throw;
        }
    }));

    // ---------------------------------------------------------------- fix a bad question
    svr.Post(R"(/api/faculty/exams/(\d+)/fix-question)", secured(app, "faculty", [&app](const httplib::Request& req, httplib::Response& res, const User& u) {
        int id = path_id(req);
        json exam = need_exam_owner(app, u.id, id);
        if (!truthy(exam["ended"])) throw HttpError(409, "Wait until the exam has ended");
        json b = read_body(req);
        std::string mode = need_str(b, "mode", 4);
        if (mode != "DROP" && mode != "FREE") throw HttpError(400, "Mode must be DROP or FREE");
        app.db.call("CALL fix_question(?, ?, ?, ?)", {u.id, id, need_int(b, "question_id"), mode});
        send_json(res, 200, {{"ok", true}});
    }));

    // ---------------------------------------------------------------- allow one retake
    svr.Post(R"(/api/faculty/exams/(\d+)/retake)", secured(app, "faculty", [&app](const httplib::Request& req, httplib::Response& res, const User& u) {
        int id = path_id(req);
        json exam = need_exam_owner(app, u.id, id);
        if (!truthy(exam["ended"])) throw HttpError(409, "A retake can be allowed after the exam has ended");
        json b = read_body(req);
        long long student_id = need_int(b, "student_id"), hours = need_int(b, "hours");
        if (hours < 1 || hours > 168) throw HttpError(400, "Hours must be 1 to 168");
        if (app.db.query("SELECT 1 FROM enrollment WHERE student_id = ? AND subject_id = ?", {student_id, exam["subject_id"]}).empty())
            throw HttpError(400, "This student is not enrolled in the subject");
        app.db.exec(
            "INSERT INTO retake_permission (exam_id, student_id, granted_by, valid_until) "
            "VALUES (?, ?, ?, DATE_ADD(NOW(), INTERVAL ? HOUR))",
            {id, student_id, u.id, hours});
        app.audit("FACULTY", u.id, "RETAKE_ALLOWED", "exam=" + std::to_string(id) + " student=" + std::to_string(student_id));
        send_json(res, 200, {{"ok", true}});
    }));

    // ---------------------------------------------------------------- live monitoring
    svr.Get(R"(/api/faculty/exams/(\d+)/live)", secured(app, "faculty", [&app](const httplib::Request& req, httplib::Response& res, const User& u) {
        int id = path_id(req);
        need_subject_access(app, u.id, id);
        json rows = app.db.query(
            "SELECT attempt_id, roll_no, name, attempt_no, seconds_left, flag_count, resume_count, answered "
            "FROM v_live_monitor WHERE exam_id = ? ORDER BY roll_no",
            {id});
        for (auto& r : rows) {
            r["flag_level"] = flag_level(r["flag_count"].get<int>());
            r["connected"] = app.sessions.is_connected(r["attempt_id"].get<int>());
        }
        json total = app.db.query("SELECT COUNT(*) AS n FROM exam_question WHERE exam_id = ? AND status <> 'DROPPED'", {id});
        send_json(res, 200, {{"server_time", app.db.query("SELECT NOW() AS t")[0]["t"]},
                             {"attempts", rows},
                             {"total_questions", total[0]["n"]}});
    }));
}

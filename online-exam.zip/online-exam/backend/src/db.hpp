// db.hpp : talking to MySQL
//
//  * Db       = a POOL of ready connections. A thread asks for one (lease), uses it and gives it back.
//               OS concept: the pool is protected by a mutex and a condition variable, so when all
//               connections are busy the next thread WAITS until one is returned.
//  * Lease    = one borrowed connection (given back automatically when it goes out of scope).
//  * Values you pass (the ? marks) are escaped with mysql_real_escape_string, never pasted raw,
//    so a student cannot inject SQL by typing quotes into a form.
#pragma once
#include <mysql.h>

#include <condition_variable>
#include <mutex>
#include <stdexcept>
#include <string>
#include <vector>

#include "util.hpp"

struct DbConfig {
    std::string host = "127.0.0.1";
    std::string user = "root";
    std::string password;
    std::string database = "online_exam";
    unsigned port = 3306;
    int pool_size = 8;
};

// an error reported by MySQL. code 1644 = a message raised by OUR triggers/procedures (SIGNAL).
struct DbError : std::runtime_error {
    unsigned code;
    DbError(unsigned c, const std::string& m) : std::runtime_error(m), code(c) {}
};

class Db;

class Lease {
public:
    Lease(Db& db, MYSQL* m) : db_(&db), m_(m) {}
    Lease(const Lease&) = delete;
    Lease& operator=(const Lease&) = delete;
    Lease(Lease&& o) noexcept : db_(o.db_), m_(o.m_), affected_(o.affected_) { o.m_ = nullptr; }
    ~Lease();

    // SELECT: rows of the first result set as a JSON array of objects
    json query(const std::string& sql, const json& params = json::array()) {
        auto sets = run(sql, params);
        return sets.empty() ? json::array() : sets[0];
    }
    // CALL procedure: every result set it returned
    std::vector<json> call(const std::string& sql, const json& params = json::array()) {
        return run(sql, params);
    }
    // INSERT/UPDATE/DELETE: number of rows changed
    long long exec(const std::string& sql, const json& params = json::array()) {
        run(sql, params);
        return affected_;
    }
    long long insert_id() const { return (long long)mysql_insert_id(m_); }

    void begin() { exec("START TRANSACTION"); }
    void commit() { exec("COMMIT"); }
    void rollback() {
        try {
            exec("ROLLBACK");
        } catch (...) {
        }
    }

private:
    std::vector<json> run(const std::string& sql, const json& params);
    std::string bind(const std::string& sql, const json& params);
    static json rows_to_json(MYSQL_RES* res);

    Db* db_;
    MYSQL* m_;
    long long affected_ = 0;
};

class Db {
public:
    explicit Db(DbConfig cfg) : cfg_(std::move(cfg)) {
        for (int i = 0; i < cfg_.pool_size; i++) free_.push_back(connect());
    }
    ~Db() {
        for (MYSQL* m : free_) mysql_close(m);
    }

    // borrow a connection; waits (blocks) while all of them are in use
    Lease lease() {
        std::unique_lock<std::mutex> lock(m_);
        cv_.wait(lock, [this] { return !free_.empty(); });
        MYSQL* m = free_.back();
        free_.pop_back();
        return Lease(*this, m);
    }

    // shortcuts that borrow and return a connection for one statement
    json query(const std::string& sql, const json& params = json::array()) {
        Lease l = lease();
        return l.query(sql, params);
    }
    std::vector<json> call(const std::string& sql, const json& params = json::array()) {
        Lease l = lease();
        return l.call(sql, params);
    }
    long long exec(const std::string& sql, const json& params = json::array()) {
        Lease l = lease();
        return l.exec(sql, params);
    }

    size_t idle_connections() {
        std::lock_guard<std::mutex> lock(m_);
        return free_.size();
    }

private:
    friend class Lease;

    MYSQL* connect() {
        MYSQL* m = mysql_init(nullptr);
        if (!m) throw DbError(0, "mysql_init failed");
        mysql_options(m, MYSQL_SET_CHARSET_NAME, "utf8mb4");
        bool reconnect = true;
        mysql_options(m, MYSQL_OPT_RECONNECT, &reconnect);
        // use TLS when the server offers it, but do not refuse a plain local connection
        // (newer MariaDB connectors demand TLS by default; MySQL on this same computer is fine without)
        // (the database is normally on this same computer, so certificate checking adds nothing)
        bool no_verify = false;
        mysql_options(m, MYSQL_OPT_SSL_VERIFY_SERVER_CERT, &no_verify);
        if (!mysql_real_connect(m, cfg_.host.c_str(), cfg_.user.c_str(), cfg_.password.c_str(),
                                cfg_.database.c_str(), cfg_.port, nullptr, CLIENT_MULTI_RESULTS)) {
            std::string msg = mysql_error(m);
            unsigned code = mysql_errno(m);
            mysql_close(m);
            throw DbError(code, "Cannot connect to MySQL: " + msg);
        }
        return m;
    }

    void give_back(MYSQL* m) {
        {
            std::lock_guard<std::mutex> lock(m_);
            free_.push_back(m);
        }
        cv_.notify_one();  // wake one waiting thread
    }

    DbConfig cfg_;
    std::mutex m_;
    std::condition_variable cv_;
    std::vector<MYSQL*> free_;
};

inline Lease::~Lease() {
    if (m_) db_->give_back(m_);
}

// replaces each ? in the SQL text with the next value, escaped
inline std::string Lease::bind(const std::string& sql, const json& params) {
    std::string out;
    size_t next = 0;
    for (char c : sql) {
        if (c != '?') {
            out += c;
            continue;
        }
        if (next >= params.size()) throw std::logic_error("SQL has more ? than values: " + sql);
        const json& v = params[next++];
        if (v.is_null()) {
            out += "NULL";
        } else if (v.is_boolean()) {
            out += v.get<bool>() ? "1" : "0";
        } else if (v.is_number_integer()) {
            out += std::to_string(v.get<long long>());
        } else if (v.is_number()) {
            out += std::to_string(v.get<double>());
        } else {
            std::string s = v.is_string() ? v.get<std::string>() : v.dump();
            std::string buf(s.size() * 2 + 1, '\0');
            unsigned long n = mysql_real_escape_string(m_, &buf[0], s.c_str(), (unsigned long)s.size());
            buf.resize(n);
            out += "'" + buf + "'";
        }
    }
    if (next != params.size()) throw std::logic_error("SQL has fewer ? than values: " + sql);
    return out;
}

// turns one result set into [ {column: value, ...}, ... ] with numbers as numbers
inline json Lease::rows_to_json(MYSQL_RES* res) {
    json rows = json::array();
    unsigned ncols = mysql_num_fields(res);
    MYSQL_FIELD* fields = mysql_fetch_fields(res);
    while (MYSQL_ROW row = mysql_fetch_row(res)) {
        unsigned long* len = mysql_fetch_lengths(res);
        json obj = json::object();
        for (unsigned i = 0; i < ncols; i++) {
            const MYSQL_FIELD& f = fields[i];
            if (!row[i]) {
                obj[f.name] = nullptr;
                continue;
            }
            std::string text(row[i], len[i]);
            switch (f.type) {
                case MYSQL_TYPE_TINY:
                    if (f.length == 1)
                        obj[f.name] = (text != "0");  // TINYINT(1) = yes/no flag
                    else
                        obj[f.name] = std::stoll(text);
                    break;
                case MYSQL_TYPE_SHORT:
                case MYSQL_TYPE_LONG:
                case MYSQL_TYPE_INT24:
                case MYSQL_TYPE_LONGLONG:
                case MYSQL_TYPE_YEAR:
                    obj[f.name] = std::stoll(text);
                    break;
                case MYSQL_TYPE_DECIMAL:
                case MYSQL_TYPE_NEWDECIMAL:
                case MYSQL_TYPE_FLOAT:
                case MYSQL_TYPE_DOUBLE:
                    obj[f.name] = std::stod(text);
                    break;
                default:
                    obj[f.name] = text;
            }
        }
        rows.push_back(std::move(obj));
    }
    return rows;
}

// sends the SQL, collects every result set (a CALL can return several)
inline std::vector<json> Lease::run(const std::string& sql, const json& params) {
    std::string text = bind(sql, params);
    std::vector<json> sets;

    int rc = mysql_real_query(m_, text.c_str(), (unsigned long)text.size());
    if (rc != 0 && (mysql_errno(m_) == 2006 || mysql_errno(m_) == 2013)) {
        // the connection was dropped by the server: reconnect once and retry
        if (mysql_ping(m_) == 0) rc = mysql_real_query(m_, text.c_str(), (unsigned long)text.size());
    }
    if (rc != 0) throw DbError(mysql_errno(m_), mysql_error(m_));

    affected_ = (long long)mysql_affected_rows(m_);
    int more;
    do {
        MYSQL_RES* res = mysql_store_result(m_);
        if (res) {
            sets.push_back(rows_to_json(res));
            mysql_free_result(res);
        } else if (mysql_field_count(m_) != 0) {
            throw DbError(mysql_errno(m_), mysql_error(m_));
        }
        more = mysql_next_result(m_);
    } while (more == 0);
    if (more > 0) throw DbError(mysql_errno(m_), mysql_error(m_));
    return sets;
}

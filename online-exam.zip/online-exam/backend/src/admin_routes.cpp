// admin_routes.cpp : the administrator manages accounts, subjects and enrollment
#include <algorithm>

#include "http_common.hpp"

namespace {

void check_email(const std::string& email) {
    if (email.find('@') == std::string::npos || email.size() < 5) throw HttpError(400, "Enter a valid email");
}
void check_password(const std::string& pw) {
    if (pw.size() < 6) throw HttpError(400, "Password must be at least 6 characters");
}

}  // namespace

void register_admin_routes(httplib::Server& svr, App& app) {
    svr.Get("/api/admin/overview", secured(app, "admin", [&app](const httplib::Request&, httplib::Response& res, const User&) {
        json r = app.db.query(
            "SELECT (SELECT COUNT(*) FROM faculty) AS faculty, (SELECT COUNT(*) FROM student) AS students, "
            "       (SELECT COUNT(*) FROM subject) AS subjects, (SELECT COUNT(*) FROM exam) AS exams");
        send_json(res, 200, r[0]);
    }));

    // ---------------------------------------------------------------- faculty
    svr.Get("/api/admin/faculty", secured(app, "admin", [&app](const httplib::Request&, httplib::Response& res, const User&) {
        json rows = app.db.query(
            "SELECT f.faculty_id, f.name, f.email, "
            "  (SELECT GROUP_CONCAT(s.code ORDER BY s.code SEPARATOR ', ') FROM faculty_subject fs "
            "   JOIN subject s ON s.subject_id = fs.subject_id WHERE fs.faculty_id = f.faculty_id) AS subjects "
            "FROM faculty f ORDER BY f.name");
        send_json(res, 200, {{"faculty", rows}});
    }));
    svr.Post("/api/admin/faculty", secured(app, "admin", [&app](const httplib::Request& req, httplib::Response& res, const User& u) {
        json b = read_body(req);
        std::string name = need_str(b, "name", 100), email = to_lower(need_str(b, "email", 120)), pw = need_str(b, "password", 200);
        check_email(email);
        check_password(pw);
        try {
            app.db.exec("INSERT INTO faculty (name, email, password_hash) VALUES (?, ?, ?)", {name, email, hash_password(pw)});
        } catch (const DbError& e) {
            if (e.code == 1062) throw HttpError(409, "This email is already registered");
            throw;
        }
        app.audit("ADMIN", u.id, "FACULTY_CREATED", email);
        send_json(res, 200, {{"ok", true}});
    }));

    // ---------------------------------------------------------------- students
    svr.Get("/api/admin/students", secured(app, "admin", [&app](const httplib::Request&, httplib::Response& res, const User&) {
        json rows = app.db.query(
            "SELECT st.student_id, st.roll_no, st.name, st.email, "
            "  (SELECT GROUP_CONCAT(s.code ORDER BY s.code SEPARATOR ', ') FROM enrollment en "
            "   JOIN subject s ON s.subject_id = en.subject_id WHERE en.student_id = st.student_id) AS subjects "
            "FROM student st ORDER BY st.roll_no");
        send_json(res, 200, {{"students", rows}});
    }));
    svr.Post("/api/admin/students", secured(app, "admin", [&app](const httplib::Request& req, httplib::Response& res, const User& u) {
        json b = read_body(req);
        std::string roll = need_str(b, "roll_no", 30), name = need_str(b, "name", 100);
        std::string email = to_lower(need_str(b, "email", 120)), pw = need_str(b, "password", 200);
        check_email(email);
        check_password(pw);
        try {
            app.db.exec("INSERT INTO student (roll_no, name, email, password_hash) VALUES (?, ?, ?, ?)",
                        {roll, name, email, hash_password(pw)});
        } catch (const DbError& e) {
            if (e.code == 1062) throw HttpError(409, "This roll number or email is already registered");
            throw;
        }
        app.audit("ADMIN", u.id, "STUDENT_CREATED", roll);
        send_json(res, 200, {{"ok", true}});
    }));

    // ---------------------------------------------------------------- subjects
    svr.Get("/api/admin/subjects", secured(app, "admin", [&app](const httplib::Request&, httplib::Response& res, const User&) {
        send_json(res, 200, {{"subjects", app.db.query("SELECT subject_id, code, name FROM subject ORDER BY code")}});
    }));
    svr.Post("/api/admin/subjects", secured(app, "admin", [&app](const httplib::Request& req, httplib::Response& res, const User& u) {
        json b = read_body(req);
        std::string code = to_upper(need_str(b, "code", 20)), name = need_str(b, "name", 100);
        try {
            app.db.exec("INSERT INTO subject (code, name) VALUES (?, ?)", {code, name});
        } catch (const DbError& e) {
            if (e.code == 1062) throw HttpError(409, "This subject code already exists");
            throw;
        }
        app.audit("ADMIN", u.id, "SUBJECT_CREATED", code);
        send_json(res, 200, {{"ok", true}});
    }));

    // ---------------------------------------------------------------- links
    svr.Post("/api/admin/assign", secured(app, "admin", [&app](const httplib::Request& req, httplib::Response& res, const User& u) {
        json b = read_body(req);
        try {
            app.db.exec("INSERT INTO faculty_subject (faculty_id, subject_id) VALUES (?, ?)",
                        {need_int(b, "faculty_id"), need_int(b, "subject_id")});
        } catch (const DbError& e) {
            if (e.code == 1062) throw HttpError(409, "Already assigned");
            throw;
        }
        app.audit("ADMIN", u.id, "FACULTY_ASSIGNED", b.dump());
        send_json(res, 200, {{"ok", true}});
    }));
    svr.Post("/api/admin/enroll", secured(app, "admin", [&app](const httplib::Request& req, httplib::Response& res, const User& u) {
        json b = read_body(req);
        try {
            app.db.exec("INSERT INTO enrollment (student_id, subject_id) VALUES (?, ?)",
                        {need_int(b, "student_id"), need_int(b, "subject_id")});
        } catch (const DbError& e) {
            if (e.code == 1062) throw HttpError(409, "Already enrolled");
            throw;
        }
        app.audit("ADMIN", u.id, "STUDENT_ENROLLED", b.dump());
        send_json(res, 200, {{"ok", true}});
    }));

    // ---------------------------------------------------------------- CSV imports
    // header: roll_no,name,email,password
    svr.Post("/api/admin/students/import", secured(app, "admin", [&app](const httplib::Request& req, httplib::Response& res, const User& u) {
        json b = read_body(req);
        auto rows = parse_csv(need_str(b, "csv", 4000000));
        if (rows.size() < 2) throw HttpError(400, "The file has no data rows");
        if (rows.size() > 2001) throw HttpError(400, "At most 2000 students per file");
        std::vector<std::string> head;
        for (auto& h : rows[0]) head.push_back(to_lower(h));
        auto col = [&](const char* name) {
            auto it = std::find(head.begin(), head.end(), name);
            if (it == head.end()) throw HttpError(400, std::string("Header must contain: roll_no, name, email, password (missing ") + name + ")");
            return (int)(it - head.begin());
        };
        int c_roll = col("roll_no"), c_name = col("name"), c_email = col("email"), c_pw = col("password");
        int added = 0;
        json skipped = json::array();
        for (size_t r = 1; r < rows.size(); r++) {
            auto cell = [&](int c) { return c < (int)rows[r].size() ? rows[r][c] : std::string(); };
            try {
                std::string email = to_lower(cell(c_email));
                if (cell(c_roll).empty() || cell(c_name).empty()) throw HttpError(400, "Roll number or name is empty");
                check_email(email);
                check_password(cell(c_pw));
                try {
                    app.db.exec("INSERT INTO student (roll_no, name, email, password_hash) VALUES (?, ?, ?, ?)",
                                {cell(c_roll), cell(c_name), email, hash_password(cell(c_pw))});
                } catch (const DbError& e) {
                    if (e.code == 1062) throw HttpError(409, "Roll number or email already exists");
                    throw;
                }
                added++;
            } catch (const HttpError& e) {
                skipped.push_back({{"row", r + 1}, {"reason", e.what()}});
            }
        }
        app.audit("ADMIN", u.id, "STUDENTS_IMPORTED", std::to_string(added) + " added");
        send_json(res, 200, {{"added", added}, {"skipped", skipped}});
    }));

    // header: roll_no,subject_code
    svr.Post("/api/admin/enroll/import", secured(app, "admin", [&app](const httplib::Request& req, httplib::Response& res, const User& u) {
        json b = read_body(req);
        auto rows = parse_csv(need_str(b, "csv", 4000000));
        if (rows.size() < 2) throw HttpError(400, "The file has no data rows");
        std::vector<std::string> head;
        for (auto& h : rows[0]) head.push_back(to_lower(h));
        auto it1 = std::find(head.begin(), head.end(), "roll_no"), it2 = std::find(head.begin(), head.end(), "subject_code");
        if (it1 == head.end() || it2 == head.end()) throw HttpError(400, "Header must contain: roll_no, subject_code");
        int c_roll = (int)(it1 - head.begin()), c_sub = (int)(it2 - head.begin());
        int added = 0;
        json skipped = json::array();
        for (size_t r = 1; r < rows.size(); r++) {
            std::string roll = c_roll < (int)rows[r].size() ? rows[r][c_roll] : "";
            std::string code = to_upper(c_sub < (int)rows[r].size() ? rows[r][c_sub] : "");
            json st = app.db.query("SELECT student_id FROM student WHERE roll_no = ?", {roll});
            json su = app.db.query("SELECT subject_id FROM subject WHERE code = ?", {code});
            if (st.empty()) { skipped.push_back({{"row", r + 1}, {"reason", "Unknown roll number " + roll}}); continue; }
            if (su.empty()) { skipped.push_back({{"row", r + 1}, {"reason", "Unknown subject code " + code}}); continue; }
            long long changed = app.db.exec("INSERT IGNORE INTO enrollment (student_id, subject_id) VALUES (?, ?)",
                                            {st[0]["student_id"], su[0]["subject_id"]});
            if (changed == 0) skipped.push_back({{"row", r + 1}, {"reason", "Already enrolled"}});
            else added++;
        }
        app.audit("ADMIN", u.id, "ENROLLMENTS_IMPORTED", std::to_string(added) + " added");
        send_json(res, 200, {{"added", added}, {"skipped", skipped}});
    }));

    // ---------------------------------------------------------------- activity log
    svr.Get("/api/admin/log", secured(app, "admin", [&app](const httplib::Request& req, httplib::Response& res, const User&) {
        int limit = std::max(1, std::min(1000, query_int(req, "limit", 200)));
        json rows = app.db.query(
            "SELECT event_time, actor_type, actor_id, action, details FROM activity_log ORDER BY log_id DESC LIMIT ?", {limit});
        send_json(res, 200, {{"rows", rows}});
    }));

    // ---------------------------------------------------------------- system status (backend only, no web page)
    svr.Get("/api/admin/system", secured(app, "admin", [&app](const httplib::Request&, httplib::Response& res, const User&) {
        CacheStats c = app.cache.stats();
        auto up = std::chrono::duration_cast<std::chrono::seconds>(std::chrono::steady_clock::now() - app.started).count();
        send_json(res, 200, {{"policy", policy_name(app.scheduler.policy())},
                             {"workers", app.scheduler.workers()},
                             {"busy_workers", app.scheduler.busy()},
                             {"queue_length", app.scheduler.queue_length()},
                             {"active_sessions", app.sessions.size()},
                             {"http_workers", app.pool.workers.load()},
                             {"http_busy", app.pool.busy.load()},
                             {"cache", {{"size", c.size}, {"capacity", c.capacity}, {"hits", c.hits}, {"misses", c.misses}}},
                             {"uptime_seconds", up}});
    }));
    svr.Post("/api/admin/system/policy", secured(app, "admin", [&app](const httplib::Request& req, httplib::Response& res, const User& u) {
        std::string p = need_str(read_body(req), "policy", 20);
        if (p != "FIFO" && p != "ROUND_ROBIN") throw HttpError(400, "Policy must be FIFO or ROUND_ROBIN");
        app.scheduler.set_policy(p == "FIFO" ? Policy::FIFO : Policy::ROUND_ROBIN);
        app.audit("ADMIN", u.id, "POLICY_CHANGED", p);
        send_json(res, 200, {{"ok", true}});
    }));
}

// logger.hpp : thread-safe activity log written to a file (and the console)
// OS concept: many threads write at the same time, so a mutex lets only ONE thread
// write at once. Without it the lines of different threads would get mixed up.
#pragma once
#include <ctime>
#include <fstream>
#include <iostream>
#include <mutex>
#include <string>

class Logger {
public:
    explicit Logger(const std::string& path) : file_(path, std::ios::app) {}

    void info(const std::string& msg) { write("INFO ", msg); }
    void warn(const std::string& msg) { write("WARN ", msg); }
    void error(const std::string& msg) { write("ERROR", msg); }

private:
    void write(const char* level, const std::string& msg) {
        std::lock_guard<std::mutex> lock(m_);  // critical section starts
        std::time_t t = std::time(nullptr);
        char stamp[32];
        std::strftime(stamp, sizeof stamp, "%Y-%m-%d %H:%M:%S", std::localtime(&t));
        std::string line = std::string(stamp) + " [" + level + "] " + msg;
        std::cout << line << std::endl;
        if (file_.is_open()) file_ << line << std::endl;
    }                          // critical section ends (lock released here)
    std::mutex m_;
    std::ofstream file_;
};

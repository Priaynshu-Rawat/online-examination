// student_routes.cpp : everything a student does
//   exam list, join / resume, save answer, heartbeat, flag events, submit, results
#include <algorithm>
#include <map>
#include <random>

#include "http_common.hpp"

namespace {

bool truthy(const json& v) {
    if (v.is_null()) return false;
    if (v.is_boolean()) return v.get<bool>();
    if (v.is_number()) return v.get<double>() != 0;
    return false;
}

// one question with its options, from the cache or from the database
json load_question(App& app, int question_id) {
    if (auto cached = app.cache.get(question_id)) return *cached;
    json q = app.db.query("SELECT question_text, question_type FROM question WHERE question_id = ?", {question_id});
    if (q.empty()) throw HttpError(404, "Question not found");
    json options = app.db.query(
        "SELECT option_id, label, option_text AS text, is_correct FROM question_option "
        "WHERE question_id = ? ORDER BY label",
        {question_id});
    json out = {{"text", q[0]["question_text"]}, {"type", q[0]["question_type"]}, {"options", options}};
    app.cache.put(question_id, out);
    return out;
}

// the student's own attempt (404 if it does not exist, 403 if it is somebody else's)
json own_attempt(App& app, int student_id, int attempt_id) {
    json r = app.db.query(
        "SELECT a.attempt_id, a.exam_id, a.student_id, a.status, a.flag_count, a.deadline, "
        "       TIMESTAMPDIFF(SECOND, NOW(), a.deadline) AS seconds_left, e.flag_limit "
        "FROM exam_attempt a JOIN exam e ON e.exam_id = a.exam_id WHERE a.attempt_id = ?",
        {attempt_id});
    if (r.empty()) throw HttpError(404, "Attempt not found");
    if (r[0]["student_id"].get<int>() != student_id) throw HttpError(403, "This is not your attempt");
    return r[0];
}

// makes sure the in-memory session exists (it is missing after a server restart)
void ensure_session(App& app, const json& a) {
    Session probe;
    int attempt_id = a["attempt_id"].get<int>();
    if (app.sessions.get(attempt_id, probe)) return;
    if (a["status"] != "IN_PROGRESS") return;
    Session s;
    s.attempt_id = attempt_id;
    s.student_id = a["student_id"].get<int>();
    s.exam_id = a["exam_id"].get<int>();
    s.deadline_epoch = now_epoch() + a["seconds_left"].get<long long>();
    s.last_heartbeat = now_epoch();
    app.sessions.upsert(s);
}

// if the time is up but the attempt is still open, finish it now (and wait for the result)
json finish_if_expired(App& app, int student_id, int attempt_id) {
    json a = own_attempt(app, student_id, attempt_id);
    if (a["status"] == "IN_PROGRESS" && a["seconds_left"].get<long long>() <= 0) {
        auto fut = app.scheduler.submit(attempt_id, a["exam_id"].get<int>(), true);
        fut.wait_for(std::chrono::seconds(15));
        a = own_attempt(app, student_id, attempt_id);
    }
    return a;
}

json state_of(const json& a) {
    long long secs = a["seconds_left"].is_null() ? 0 : a["seconds_left"].get<long long>();
    return {{"status", a["status"]},
            {"seconds_left", std::max(0LL, secs)},
            {"flag_count", a["flag_count"]},
            {"flag_limit", a["flag_limit"]}};
}

json server_time(App& app) { return app.db.query("SELECT NOW() AS t")[0]["t"]; }

}  // namespace

void register_student_routes(httplib::Server& svr, App& app) {
    // ---------------------------------------------------------------- exam list
    svr.Get("/api/student/exams", secured(app, "student", [&app](const httplib::Request&, httplib::Response& res, const User& u) {
        json rows = app.db.query(
            "SELECT e.exam_id, e.title, s.code AS subject_code, s.name AS subject_name, f.name AS faculty_name, "
            "       e.start_time, e.end_time, e.duration_minutes, vs.status, "
            "       a.attempt_id, a.status AS attempt_status, (a.deadline > NOW()) AS not_expired, "
            "       EXISTS (SELECT 1 FROM retake_permission rp WHERE rp.exam_id = e.exam_id "
            "               AND rp.student_id = en.student_id AND rp.used = 0 AND rp.valid_until > NOW()) AS has_retake "
            "FROM enrollment en "
            "JOIN exam e ON e.subject_id = en.subject_id "
            "JOIN subject s ON s.subject_id = e.subject_id "
            "JOIN faculty f ON f.faculty_id = e.created_by "
            "JOIN v_exam_status vs ON vs.exam_id = e.exam_id "
            "LEFT JOIN exam_attempt a ON a.exam_id = e.exam_id AND a.student_id = en.student_id "
            "     AND a.attempt_no = (SELECT MAX(b.attempt_no) FROM exam_attempt b "
            "                         WHERE b.exam_id = e.exam_id AND b.student_id = en.student_id) "
            "WHERE en.student_id = ? AND (vs.status <> 'DEACTIVATED' OR a.attempt_id IS NOT NULL) "
            "ORDER BY e.start_time DESC",
            {u.id});

        json exams = json::array();
        for (auto& r : rows) {
            std::string status = r["status"].get<std::string>();
            bool has_attempt = !r["attempt_status"].is_null();
            std::string attempt_status = has_attempt ? r["attempt_status"].get<std::string>() : "";
            bool in_progress = attempt_status == "IN_PROGRESS";

            std::string my_status;
            if (!has_attempt) my_status = (status == "CLOSED") ? "ABSENT" : "NOT_ATTEMPTED";
            else my_status = attempt_status;

            bool can_resume = in_progress && truthy(r["not_expired"]);
            bool can_join = !in_progress && ((!has_attempt && status == "OPEN") || truthy(r["has_retake"]));

            exams.push_back({{"exam_id", r["exam_id"]},
                             {"title", r["title"]},
                             {"subject_code", r["subject_code"]},
                             {"subject_name", r["subject_name"]},
                             {"faculty_name", r["faculty_name"]},
                             {"start_time", r["start_time"]},
                             {"end_time", r["end_time"]},
                             {"duration_minutes", r["duration_minutes"]},
                             {"status", status},
                             {"my_status", my_status},
                             {"can_join", can_join},
                             {"can_resume", can_resume},
                             {"attempt_id", r["attempt_id"]}});
        }
        send_json(res, 200, {{"server_time", server_time(app)}, {"exams", exams}});
    }));

    // ---------------------------------------------------------------- join / resume
    svr.Post(R"(/api/student/exams/(\d+)/join)", secured(app, "student", [&app](const httplib::Request& req, httplib::Response& res, const User& u) {
        int exam_id = path_id(req);
        json exam = app.db.query(
            "SELECT title, instructions, shuffle_questions, shuffle_options FROM exam WHERE exam_id = ?", {exam_id});
        if (exam.empty()) throw HttpError(404, "Exam not found");

        // the question order for a NEW attempt: the paper order, shuffled when the faculty asked for it
        json paper = app.db.query(
            "SELECT question_id, marks, status FROM exam_question WHERE exam_id = ? ORDER BY display_order",
            {exam_id});
        std::vector<int> order;
        for (auto& p : paper)
            if (p["status"] != "DROPPED") order.push_back(p["question_id"].get<int>());
        if (order.empty()) throw HttpError(400, "This exam has no questions");
        if (truthy(exam[0]["shuffle_questions"])) {
            std::random_device rd;
            std::mt19937 gen(rd());
            std::shuffle(order.begin(), order.end(), gen);
        }

        // ONE connection for both statements because the answer comes back in session variables
        std::string mode;
        int attempt_id = 0;
        {
            Lease lease = app.db.lease();
            lease.call("CALL join_exam(?, ?, ?, @a, @m)", {exam_id, u.id, json(order).dump()});
            json out = lease.query("SELECT @a AS attempt_id, @m AS mode");
            attempt_id = out[0]["attempt_id"].get<int>();
            mode = out[0]["mode"].get<std::string>();
        }

        json a = app.db.query(
            "SELECT a.attempt_id, a.exam_id, a.student_id, a.status, a.flag_count, a.question_order, "
            "       TIMESTAMPDIFF(SECOND, NOW(), a.deadline) AS seconds_left, e.flag_limit "
            "FROM exam_attempt a JOIN exam e ON e.exam_id = a.exam_id WHERE a.attempt_id = ?",
            {attempt_id})[0];
        ensure_session(app, a);
        bool was_gone = false;
        app.sessions.touch(attempt_id, was_gone);

        // this student's saved order (a resumed attempt keeps its original order)
        std::vector<int> my_order = order;
        if (a["question_order"].is_string()) {
            json parsed = json::parse(a["question_order"].get<std::string>(), nullptr, false);
            if (parsed.is_array()) {
                my_order.clear();
                for (auto& v : parsed) my_order.push_back(v.get<int>());
            }
        }
        std::map<int, json> paper_info;
        for (auto& p : paper) paper_info[p["question_id"].get<int>()] = p;

        bool shuffle_options = truthy(exam[0]["shuffle_options"]);
        json questions = json::array();
        for (int qid : my_order) {
            auto info = paper_info.find(qid);
            if (info == paper_info.end() || info->second["status"] == "DROPPED") continue;
            json q = load_question(app, qid);
            json options = json::array();
            for (auto& o : q["options"])  // NEVER send is_correct to the student
                options.push_back({{"option_id", o["option_id"]}, {"label", o["label"]}, {"text", o["text"]}});
            if (shuffle_options) {
                // seeded by attempt + question so a resumed attempt shows the same order
                std::mt19937 gen((unsigned)(attempt_id * 7919 + qid));
                std::vector<json> v(options.begin(), options.end());
                std::shuffle(v.begin(), v.end(), gen);
                options = json(v);
            }
            questions.push_back({{"question_id", qid},
                                 {"text", q["text"]},
                                 {"type", q["type"]},
                                 {"marks", info->second["marks"]},
                                 {"options", options}});
        }

        json saved = app.db.query("SELECT question_id, option_id FROM answer WHERE attempt_id = ?", {attempt_id});
        json answers = json::object();
        for (auto& s : saved) answers[std::to_string(s["question_id"].get<int>())].push_back(s["option_id"]);

        long long secs = std::max(0LL, a["seconds_left"].get<long long>());
        send_json(res, 200, {{"attempt_id", attempt_id},
                             {"mode", mode},
                             {"title", exam[0]["title"]},
                             {"instructions", exam[0]["instructions"]},
                             {"seconds_left", secs},
                             {"server_time", server_time(app)},
                             {"flag_count", a["flag_count"]},
                             {"flag_limit", a["flag_limit"]},
                             {"questions", questions},
                             {"answers", answers}});
    }));

    // ---------------------------------------------------------------- save one answer
    svr.Post(R"(/api/student/attempts/(\d+)/answer)", secured(app, "student", [&app](const httplib::Request& req, httplib::Response& res, const User& u) {
        int attempt_id = path_id(req);
        json b = read_body(req);
        int question_id = (int)need_int(b, "question_id");
        if (!b.contains("option_ids") || !b["option_ids"].is_array()) throw HttpError(400, "option_ids must be a list");
        std::vector<int> ids;
        for (auto& v : b["option_ids"]) {
            if (!v.is_number_integer()) throw HttpError(400, "option_ids must be numbers");
            int id = v.get<int>();
            if (std::find(ids.begin(), ids.end(), id) == ids.end()) ids.push_back(id);
        }
        if (ids.size() > 12) throw HttpError(400, "Too many options");

        json a = own_attempt(app, u.id, attempt_id);
        if (a["status"] != "IN_PROGRESS") throw HttpError(403, "This attempt is closed");

        // replace the old answer of this question by the new one, all or nothing (a transaction)
        Lease lease = app.db.lease();
        lease.begin();
        try {
            lease.exec("DELETE FROM answer WHERE attempt_id = ? AND question_id = ?", {attempt_id, question_id});
            for (int oid : ids)
                lease.exec("INSERT INTO answer (attempt_id, question_id, option_id) VALUES (?, ?, ?)",
                           {attempt_id, question_id, oid});
            lease.commit();
        } catch (...) {
            lease.rollback();
            throw;
        }
        bool was_gone = false;
        app.sessions.touch(attempt_id, was_gone);
        send_json(res, 200, {{"ok", true}, {"seconds_left", std::max(0LL, a["seconds_left"].get<long long>())}});
    }));

    // ---------------------------------------------------------------- heartbeat (every 5 seconds)
    svr.Post(R"(/api/student/attempts/(\d+)/heartbeat)", secured(app, "student", [&app](const httplib::Request& req, httplib::Response& res, const User& u) {
        int attempt_id = path_id(req);
        json a = finish_if_expired(app, u.id, attempt_id);
        if (a["status"] == "IN_PROGRESS") {
            ensure_session(app, a);
            bool was_gone = false;
            app.sessions.touch(attempt_id, was_gone);
            if (was_gone) {  // the page came back after the monitor had marked it as gone
                app.db.exec("INSERT INTO attempt_event (attempt_id, event_type, note) VALUES (?, 'RESUMED', 'connection back')",
                            {attempt_id});
                a = own_attempt(app, u.id, attempt_id);
            }
        } else {
            app.sessions.remove(attempt_id);
        }
        json st = state_of(a);
        st["server_time"] = server_time(app);
        send_json(res, 200, st);
    }));

    // ---------------------------------------------------------------- flag events (tab switch / leaving)
    svr.Post(R"(/api/student/attempts/(\d+)/event)", secured(app, "student", [&app](const httplib::Request& req, httplib::Response& res, const User& u) {
        int attempt_id = path_id(req);
        json b = read_body(req);
        std::string type = need_str(b, "type", 20);
        if (type != "TAB_SWITCH" && type != "LEFT") throw HttpError(400, "Unknown event type");

        json a = own_attempt(app, u.id, attempt_id);
        if (a["status"] == "IN_PROGRESS" && app.sessions.allow_event(attempt_id, 1)) {
            if (type == "LEFT") app.sessions.set_connected(attempt_id, false);  // the monitor must not flag it twice
            app.db.exec("INSERT INTO attempt_event (attempt_id, event_type, note) VALUES (?, ?, ?)",
                        {attempt_id, type, type == "LEFT" ? "page closed" : "switched tab"});
            a = own_attempt(app, u.id, attempt_id);
            if (a["status"] != "IN_PROGRESS") app.sessions.remove(attempt_id);  // reached the flag limit
        }
        json st = state_of(a);
        send_json(res, 200, {{"status", st["status"]}, {"flag_count", st["flag_count"]}, {"flag_limit", st["flag_limit"]}});
    }));

    // ---------------------------------------------------------------- submit
    svr.Post(R"(/api/student/attempts/(\d+)/submit)", secured(app, "student", [&app](const httplib::Request& req, httplib::Response& res, const User& u) {
        int attempt_id = path_id(req);
        json a = own_attempt(app, u.id, attempt_id);
        std::string status = a["status"].get<std::string>();
        if (status == "IN_PROGRESS") {
            // the job goes into the scheduler queue; we wait for an evaluator thread to finish it
            auto fut = app.scheduler.submit(attempt_id, a["exam_id"].get<int>(), false);
            if (fut.wait_for(std::chrono::seconds(20)) != std::future_status::ready)
                throw HttpError(503, "The server is busy. Please press Submit again.");
            status = fut.get();
        }
        send_json(res, 200, {{"status", status}, {"message", "Your answers have been submitted"}});
    }));

    // ---------------------------------------------------------------- my results
    svr.Get("/api/student/results", secured(app, "student", [&app](const httplib::Request&, httplib::Response& res, const User& u) {
        json rows = app.db.query(
            "SELECT a.attempt_id, e.exam_id, e.title, s.code AS subject_code, a.attempt_no, a.status, a.submit_time, "
            "       e.results_published AS published, r.marks_obtained, r.total_marks, r.percentage "
            "FROM v_counted_attempt ca "
            "JOIN exam_attempt a ON a.attempt_id = ca.attempt_id "
            "JOIN exam e ON e.exam_id = a.exam_id "
            "JOIN subject s ON s.subject_id = e.subject_id "
            "JOIN result r ON r.attempt_id = a.attempt_id "
            "WHERE ca.student_id = ? ORDER BY a.submit_time DESC",
            {u.id});
        for (auto& r : rows) {
            if (!truthy(r["published"])) {  // marks stay hidden until the faculty publishes
                r["marks_obtained"] = nullptr;
                r["total_marks"] = nullptr;
                r["percentage"] = nullptr;
            }
        }
        send_json(res, 200, {{"results", rows}});
    }));

    svr.Get(R"(/api/student/results/(\d+))", secured(app, "student", [&app](const httplib::Request& req, httplib::Response& res, const User& u) {
        int attempt_id = path_id(req);
        json r = app.db.query(
            "SELECT a.attempt_id, a.exam_id, a.student_id, e.title, e.results_published AS published, "
            "       e.allow_answer_review AS review_allowed, r.marks_obtained, r.total_marks, r.percentage, "
            "       r.correct_count, r.wrong_count, r.skipped_count "
            "FROM exam_attempt a JOIN exam e ON e.exam_id = a.exam_id "
            "JOIN result r ON r.attempt_id = a.attempt_id WHERE a.attempt_id = ?",
            {attempt_id});
        if (r.empty()) throw HttpError(404, "Result not found");
        if (r[0]["student_id"].get<int>() != u.id) throw HttpError(403, "This is not your result");
        if (!truthy(r[0]["published"])) throw HttpError(403, "Result is not published yet");

        int exam_id = r[0]["exam_id"].get<int>();
        json rank = app.db.query("SELECT rank_no FROM v_leaderboard WHERE exam_id = ? AND student_id = ?", {exam_id, u.id});
        json avg = app.db.query("SELECT avg_marks FROM v_exam_summary WHERE exam_id = ?", {exam_id});

        json out = r[0];
        out.erase("student_id");
        out["rank"] = rank.empty() ? json(nullptr) : rank[0]["rank_no"];
        out["class_average"] = avg.empty() ? json(nullptr) : avg[0]["avg_marks"];
        out["review"] = nullptr;
        if (truthy(out["review_allowed"])) {
            auto sets = app.db.call("CALL get_attempt_review(?)", {attempt_id});
            out["review"] = sets.empty() ? json::array() : sets[0];
        }
        send_json(res, 200, out);
    }));
}

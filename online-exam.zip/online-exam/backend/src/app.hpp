// app.hpp : everything the server needs, gathered in one object that the route files receive
#pragma once
#include <atomic>
#include <chrono>
#include <fstream>
#include <sstream>
#include <string>

#include "db.hpp"
#include "logger.hpp"
#include "os_scheduler.hpp"
#include "os_sessions.hpp"

struct Config {
    DbConfig db;
    std::string host = "0.0.0.0";
    int port = 8080;
    std::string web_root = "../web";
    int http_workers = 8;        // threads that handle web requests (the thread pool)
    int eval_workers = 3;        // threads that finish submitted attempts
    Policy policy = Policy::FIFO;
    int heartbeat_timeout = 20;  // seconds without a heartbeat = student left
    int cache_capacity = 200;
    std::string log_file = "../logs/server.log";

    // reads config.json; every key is optional. EXAM_DB_PASSWORD overrides the password.
    static Config load(const std::string& path) {
        Config c;
        std::ifstream f(path);
        if (f) {
            json j = json::parse(f, nullptr, true, true);
            auto d = j.value("db", json::object());
            c.db.host = d.value("host", c.db.host);
            c.db.port = d.value("port", (int)c.db.port);
            c.db.user = d.value("user", c.db.user);
            c.db.password = d.value("password", c.db.password);
            c.db.database = d.value("database", c.db.database);
            c.db.pool_size = d.value("pool_size", c.db.pool_size);
            auto s = j.value("server", json::object());
            c.host = s.value("host", c.host);
            c.port = s.value("port", c.port);
            c.web_root = s.value("web_root", c.web_root);
            c.http_workers = s.value("http_workers", c.http_workers);
            c.eval_workers = s.value("eval_workers", c.eval_workers);
            c.heartbeat_timeout = s.value("heartbeat_timeout_seconds", c.heartbeat_timeout);
            c.cache_capacity = s.value("cache_capacity", c.cache_capacity);
            c.log_file = s.value("log_file", c.log_file);
            std::string p = s.value("policy", std::string("FIFO"));
            c.policy = (p == "ROUND_ROBIN") ? Policy::ROUND_ROBIN : Policy::FIFO;
        }
        if (const char* env = std::getenv("EXAM_DB_PASSWORD")) c.db.password = env;
        return c;
    }
};

// counters for the busy/idle workers of the web thread pool
struct PoolStats {
    std::atomic<int> workers{0};
    std::atomic<int> busy{0};
    std::atomic<size_t> queued{0};
};

struct App {
    Config cfg;
    Logger log;
    Db db;
    TokenTable tokens;
    SessionTable sessions;
    QuestionCache cache;
    PoolStats pool;
    EvalScheduler scheduler;
    std::chrono::steady_clock::time_point started = std::chrono::steady_clock::now();

    explicit App(Config c)
        : cfg(c),
          log(c.log_file),
          db(c.db),
          cache((size_t)c.cache_capacity),
          scheduler(db, sessions, log, c.eval_workers, c.policy) {}

    // writes a line in the activity_log table (shown in the log viewer)
    void audit(const std::string& actor_type, int actor_id, const std::string& action,
               const std::string& details) {
        try {
            db.exec("INSERT INTO activity_log (actor_type, actor_id, action, details) VALUES (?, ?, ?, ?)",
                    {actor_type, actor_id == 0 ? json(nullptr) : json(actor_id), action, details.substr(0, 480)});
        } catch (const std::exception& e) {
            log.error(std::string("audit failed: ") + e.what());
        }
    }
};

// http_common.hpp : helpers shared by all the route files
//   * reading JSON input safely
//   * checking the login token and the role (student / faculty / admin)
//   * turning every kind of error into a clean JSON answer {"error": "..."}
#pragma once
#include <sodium.h>

#include <functional>
#include <mutex>
#include <optional>

#include "app.hpp"
#include "httplib.h"

// thrown anywhere in a handler to stop and answer with this status and message
struct HttpError : std::runtime_error {
    int status;
    json extra;
    HttpError(int s, const std::string& m, json e = json::object())
        : std::runtime_error(m), status(s), extra(std::move(e)) {}
};

inline void send_json(httplib::Response& res, int status, const json& body) {
    res.status = status;
    res.set_content(body.dump(), "application/json; charset=utf-8");
}

inline json read_body(const httplib::Request& req) {
    if (req.body.empty()) return json::object();
    json j = json::parse(req.body, nullptr, false);
    if (j.is_discarded() || !j.is_object()) throw HttpError(400, "The request body must be JSON");
    return j;
}

// required text field
inline std::string need_str(const json& j, const char* key, size_t max_len = 2000) {
    if (!j.contains(key) || !j[key].is_string()) throw HttpError(400, std::string("Missing field: ") + key);
    std::string s = trim(j[key].get<std::string>());
    if (s.empty()) throw HttpError(400, std::string("Field is empty: ") + key);
    if (s.size() > max_len) throw HttpError(400, std::string("Field is too long: ") + key);
    return s;
}
inline std::string opt_str(const json& j, const char* key, const std::string& def = "") {
    if (!j.contains(key) || !j[key].is_string()) return def;
    return trim(j[key].get<std::string>());
}
// required whole number field
inline long long need_int(const json& j, const char* key) {
    if (!j.contains(key) || !j[key].is_number_integer()) throw HttpError(400, std::string("Missing number: ") + key);
    return j[key].get<long long>();
}
inline long long opt_int(const json& j, const char* key, long long def) {
    if (!j.contains(key) || !j[key].is_number_integer()) return def;
    return j[key].get<long long>();
}
inline bool opt_bool(const json& j, const char* key, bool def) {
    if (!j.contains(key)) return def;
    if (j[key].is_boolean()) return j[key].get<bool>();
    if (j[key].is_number()) return j[key].get<int>() != 0;
    return def;
}

// number from the URL, for example the 5 in /api/student/exams/5/join
inline int path_id(const httplib::Request& req, size_t index = 1) {
    return std::stoi(req.matches[index].str());
}

// query string number such as ?subject_id=3
inline int query_int(const httplib::Request& req, const char* key, int def = 0) {
    if (!req.has_param(key)) return def;
    try {
        return std::stoi(req.get_param_value(key));
    } catch (...) {
        return def;
    }
}

// ---- passwords (libsodium, Argon2id). One hash at a time so many logins cannot eat all memory.
inline std::string hash_password(const std::string& password) {
    static std::mutex m;
    std::lock_guard<std::mutex> lock(m);
    char out[crypto_pwhash_STRBYTES];
    if (crypto_pwhash_str(out, password.c_str(), password.size(), crypto_pwhash_OPSLIMIT_INTERACTIVE,
                          16 * 1024 * 1024) != 0)
        throw HttpError(500, "Could not hash the password");
    return out;
}
inline bool verify_password(const std::string& hash, const std::string& password) {
    static std::mutex m;
    std::lock_guard<std::mutex> lock(m);
    return crypto_pwhash_str_verify(hash.c_str(), password.c_str(), password.size()) == 0;
}

// ---- who is calling?  The token comes in the Authorization header (or ?token= for sendBeacon)
inline std::string token_of(const httplib::Request& req) {
    std::string h = req.get_header_value("Authorization");
    if (h.rfind("Bearer ", 0) == 0) return h.substr(7);
    return req.get_param_value("token");
}

// ---- translate a database error into an HTTP answer
inline void db_error_to_http(const DbError& e, int& status, std::string& message) {
    message = e.what();
    if (e.code == 1644) {  // a message raised by our own trigger / procedure: show it as it is
        std::string m = to_lower(message);
        auto has = [&](const char* w) { return m.find(w) != std::string::npos; };
        if (has("already") || has("locked") || has("no longer") || has("duplicate")) status = 409;
        else if (has("enrolled") || has("started") || has("over") || has("deactivated") || has("closed") ||
                 has("permission") || has("teach") || has("only the faculty") || has("still running"))
            status = 403;
        else status = 400;
    } else if (e.code == 1062) {
        status = 409;
        message = "That already exists";
    } else if (e.code == 1451) {
        status = 409;
        message = "Cannot do that: other records depend on it";
    } else if (e.code == 1452) {
        status = 400;
        message = "Related record does not exist";
    } else if (e.code == 3819 || e.code == 4025) {
        status = 400;
        message = "A value is not allowed (check the numbers you entered)";
    } else {
        status = 500;
        message = "Database error";
    }
}

using AuthHandler = std::function<void(const httplib::Request&, httplib::Response&, const User&)>;
using PlainHandler = std::function<void(const httplib::Request&, httplib::Response&)>;

// runs a handler and converts every exception into JSON
inline void run_safely(App& app, const httplib::Request& req, httplib::Response& res,
                       const std::function<void()>& body) {
    try {
        body();
    } catch (const HttpError& e) {
        json out = e.extra;
        out["error"] = e.what();
        send_json(res, e.status, out);
    } catch (const DbError& e) {
        int status;
        std::string message;
        db_error_to_http(e, status, message);
        if (status == 500) app.log.error("database error " + std::to_string(e.code) + ": " + e.what() + "  [" + req.path + "]");
        send_json(res, status, {{"error", message}});
    } catch (const json::exception& e) {
        app.log.warn(std::string("bad json data: ") + e.what() + "  [" + req.path + "]");
        send_json(res, 400, {{"error", "Bad request data"}});
    } catch (const std::exception& e) {
        app.log.error(std::string("server error: ") + e.what() + "  [" + req.path + "]");
        send_json(res, 500, {{"error", "Server error"}});
    }
}

// a route that needs a login with the given role
inline httplib::Server::Handler secured(App& app, const std::string& role, AuthHandler h) {
    return [&app, role, h](const httplib::Request& req, httplib::Response& res) {
        run_safely(app, req, res, [&] {
            auto user = app.tokens.find(token_of(req));
            if (!user) throw HttpError(401, "Please log in");
            if (user->role != role) throw HttpError(403, "This page is not for your role");
            h(req, res, *user);
        });
    };
}

// a route that needs any login
inline httplib::Server::Handler any_user(App& app, AuthHandler h) {
    return [&app, h](const httplib::Request& req, httplib::Response& res) {
        run_safely(app, req, res, [&] {
            auto user = app.tokens.find(token_of(req));
            if (!user) throw HttpError(401, "Please log in");
            h(req, res, *user);
        });
    };
}

// a route anyone may call (login, register)
inline httplib::Server::Handler open_route(App& app, PlainHandler h) {
    return [&app, h](const httplib::Request& req, httplib::Response& res) {
        run_safely(app, req, res, [&] { h(req, res); });
    };
}

// ---- route registration functions (one per file)
void register_auth_routes(httplib::Server& svr, App& app);
void register_student_routes(httplib::Server& svr, App& app);
void register_faculty_question_routes(httplib::Server& svr, App& app);
void register_faculty_exam_routes(httplib::Server& svr, App& app);
void register_faculty_report_routes(httplib::Server& svr, App& app);
void register_admin_routes(httplib::Server& svr, App& app);

// does this faculty teach the subject of this exam? (used for reading results)
inline void need_subject_access(App& app, int faculty_id, int exam_id) {
    json r = app.db.query(
        "SELECT 1 FROM exam e JOIN faculty_subject fs ON fs.subject_id = e.subject_id "
        "WHERE e.exam_id = ? AND fs.faculty_id = ?",
        {exam_id, faculty_id});
    if (r.empty()) throw HttpError(403, "You do not teach the subject of this exam");
}

// did this faculty create this exam? returns the exam row
inline json need_exam_owner(App& app, int faculty_id, int exam_id) {
    json r = app.db.query(
        "SELECT e.*, (e.start_time <= NOW()) AS started, (e.end_time <= NOW()) AS ended "
        "FROM exam e WHERE e.exam_id = ?",
        {exam_id});
    if (r.empty()) throw HttpError(404, "Exam not found");
    if (r[0]["created_by"].get<int>() != faculty_id) throw HttpError(403, "You can change only your own exams");
    return r[0];
}

// os_scheduler.hpp : the SUBMISSION QUEUE with a choice of scheduling policy
//
// When a student presses Submit (or the timer ends) the request becomes a JOB in a queue.
// A small team of evaluator threads takes jobs from the queue and finishes the attempt
// (the database then calculates the marks).
//
//   FIFO         = first come, first served: the oldest job always goes first.
//   ROUND_ROBIN  = the exams take turns: one job from exam 1, one from exam 2, one from exam 3...
//                  so a huge exam that ends at the same moment cannot make every other exam wait.
//
// OS concepts: producer/consumer queue, mutex + condition variable, CPU-scheduling policies.
#pragma once
#include <atomic>
#include <condition_variable>
#include <deque>
#include <future>
#include <map>
#include <memory>
#include <mutex>
#include <thread>
#include <vector>

#include "db.hpp"
#include "logger.hpp"
#include "os_sessions.hpp"

enum class Policy { FIFO, ROUND_ROBIN };

inline const char* policy_name(Policy p) { return p == Policy::FIFO ? "FIFO" : "ROUND_ROBIN"; }

struct EvalJob {
    int attempt_id = 0;
    int exam_id = 0;
    bool auto_submit = false;  // true = the timer ended it, false = the student pressed Submit
    unsigned long long seq = 0;  // arrival number (used by FIFO)
    std::shared_ptr<std::promise<std::string>> done;
};

class EvalScheduler {
public:
    EvalScheduler(Db& db, SessionTable& sessions, Logger& log, int workers, Policy policy)
        : db_(db), sessions_(sessions), log_(log), policy_(policy) {
        for (int i = 0; i < workers; i++) threads_.emplace_back([this] { worker(); });
    }

    ~EvalScheduler() {
        {
            std::lock_guard<std::mutex> lock(m_);
            stop_ = true;
        }
        cv_.notify_all();
        for (auto& t : threads_)
            if (t.joinable()) t.join();
    }

    // producer: put a job in the queue. The returned future gives the final attempt status.
    std::future<std::string> submit(int attempt_id, int exam_id, bool auto_submit) {
        EvalJob job;
        job.attempt_id = attempt_id;
        job.exam_id = exam_id;
        job.auto_submit = auto_submit;
        job.done = std::make_shared<std::promise<std::string>>();
        auto fut = job.done->get_future();
        {
            std::lock_guard<std::mutex> lock(m_);
            job.seq = ++counter_;
            per_exam_[exam_id].push_back(std::move(job));
            total_++;
        }
        cv_.notify_one();  // wake one sleeping evaluator
        return fut;
    }

    void set_policy(Policy p) { policy_ = p; }
    Policy policy() const { return policy_; }
    int workers() const { return (int)threads_.size(); }
    int busy() const { return busy_; }
    size_t queue_length() {
        std::lock_guard<std::mutex> lock(m_);
        return total_;
    }

private:
    // consumer: wait for work, pick a job by policy, run it
    void worker() {
        for (;;) {
            EvalJob job;
            {
                std::unique_lock<std::mutex> lock(m_);
                cv_.wait(lock, [this] { return stop_ || total_ > 0; });
                if (stop_ && total_ == 0) return;
                pick(job);
                busy_++;
            }
            run(job);
            busy_--;
        }
    }

    // called with the lock held. Chooses the next job according to the policy.
    void pick(EvalJob& out) {
        auto chosen = per_exam_.end();
        if (policy_ == Policy::FIFO) {
            // the job with the smallest arrival number among the front of every exam queue
            for (auto it = per_exam_.begin(); it != per_exam_.end(); ++it)
                if (chosen == per_exam_.end() || it->second.front().seq < chosen->second.front().seq)
                    chosen = it;
        } else {
            // the next exam after the one served last time (wrapping around)
            chosen = per_exam_.upper_bound(last_rr_exam_);
            if (chosen == per_exam_.end()) chosen = per_exam_.begin();
            last_rr_exam_ = chosen->first;
        }
        out = std::move(chosen->second.front());
        chosen->second.pop_front();
        if (chosen->second.empty()) per_exam_.erase(chosen);
        total_--;
    }

    void run(EvalJob& job) {
        try {
            // the procedure ends the attempt; a trigger then calculates the result
            db_.call("CALL submit_attempt(?, ?)", {job.attempt_id, job.auto_submit ? 1 : 0});
            json row = db_.query("SELECT status FROM exam_attempt WHERE attempt_id = ?", {job.attempt_id});
            std::string status = row.empty() ? "UNKNOWN" : row[0]["status"].get<std::string>();
            sessions_.remove(job.attempt_id);
            log_.info("evaluated attempt " + std::to_string(job.attempt_id) + " -> " + status);
            job.done->set_value(status);
        } catch (...) {
            log_.error("evaluation failed for attempt " + std::to_string(job.attempt_id));
            job.done->set_exception(std::current_exception());
        }
    }

    Db& db_;
    SessionTable& sessions_;
    Logger& log_;
    std::atomic<Policy> policy_;
    std::mutex m_;
    std::condition_variable cv_;
    std::map<int, std::deque<EvalJob>> per_exam_;  // exam id -> its waiting jobs
    size_t total_ = 0;
    unsigned long long counter_ = 0;
    int last_rr_exam_ = -1;
    bool stop_ = false;
    std::atomic<int> busy_{0};
    std::vector<std::thread> threads_;
};

// monitor.hpp : the BACKGROUND MONITOR THREAD
//
// Every few seconds it walks through the session table and:
//   1. if a student's timer has run out          -> sends an automatic submit job to the scheduler
//   2. if a student's heartbeats stopped         -> records "LEFT" (one flag). A trigger in the
//                                                   database counts the flags and auto-submits at the limit.
//
// OS concepts: a daemon thread sleeping on a condition variable, shared data guarded by mutexes.
#pragma once
#include <condition_variable>
#include <mutex>
#include <thread>

#include "app.hpp"

class Monitor {
public:
    explicit Monitor(App& app) : app_(app), thread_([this] { loop(); }) {}

    ~Monitor() {
        {
            std::lock_guard<std::mutex> lock(m_);
            stop_ = true;
        }
        cv_.notify_all();
        if (thread_.joinable()) thread_.join();
    }

private:
    void loop() {
        std::unique_lock<std::mutex> lock(m_);
        while (!stop_) {
            cv_.wait_for(lock, std::chrono::seconds(3), [this] { return stop_; });
            if (stop_) break;
            lock.unlock();  // never hold our lock while talking to the database
            try {
                sweep();
            } catch (const std::exception& e) {
                app_.log.error(std::string("monitor: ") + e.what());
            }
            lock.lock();
        }
    }

    void sweep() {
        long long now = now_epoch();
        for (const Session& s : app_.sessions.snapshot()) {
            if (now >= s.deadline_epoch + 1) {
                // time is over: finish the attempt (the scheduler decides when it gets its turn)
                app_.log.info("timer ended attempt " + std::to_string(s.attempt_id));
                app_.scheduler.submit(s.attempt_id, s.exam_id, true);
                app_.sessions.remove(s.attempt_id);  // do not queue the same attempt again
            } else if (s.connected && now - s.last_heartbeat > app_.cfg.heartbeat_timeout) {
                // the page stopped answering: the student left the exam
                app_.sessions.set_connected(s.attempt_id, false);
                app_.log.warn("student left attempt " + std::to_string(s.attempt_id) + " (no heartbeat)");
                app_.db.exec(
                    "INSERT INTO attempt_event (attempt_id, event_type, note) VALUES (?, 'LEFT', 'connection lost')",
                    {s.attempt_id});
                // the trigger may have auto-submitted at the flag limit: stop tracking if so
                json st = app_.db.query("SELECT status FROM exam_attempt WHERE attempt_id = ?", {s.attempt_id});
                if (!st.empty() && st[0]["status"] != "IN_PROGRESS") app_.sessions.remove(s.attempt_id);
            }
        }
    }

    App& app_;
    std::mutex m_;
    std::condition_variable cv_;
    bool stop_ = false;
    std::thread thread_;
};

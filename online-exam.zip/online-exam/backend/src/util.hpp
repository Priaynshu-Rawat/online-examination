// util.hpp : small helper functions used everywhere (time, random tokens, CSV, flag colours)
#pragma once
#include <sodium.h>

#include <algorithm>
#include <chrono>
#include <string>
#include <vector>

#include "json.hpp"

using json = nlohmann::json;

// seconds since 1970 (server clock). Used for countdown maths in memory.
inline long long now_epoch() {
    return std::chrono::duration_cast<std::chrono::seconds>(
               std::chrono::system_clock::now().time_since_epoch())
        .count();
}

// random text such as a login token. libsodium gives cryptographically strong random bytes.
inline std::string random_hex(size_t bytes) {
    std::vector<unsigned char> buf(bytes);
    randombytes_buf(buf.data(), buf.size());
    static const char* digits = "0123456789abcdef";
    std::string out;
    for (unsigned char b : buf) {
        out += digits[b >> 4];
        out += digits[b & 15];
    }
    return out;
}

inline std::string trim(const std::string& s) {
    size_t a = s.find_first_not_of(" \t\r\n");
    if (a == std::string::npos) return "";
    size_t b = s.find_last_not_of(" \t\r\n");
    return s.substr(a, b - a + 1);
}

inline std::string to_upper(std::string s) {
    std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c) { return (char)toupper(c); });
    return s;
}

inline std::string to_lower(std::string s) {
    std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c) { return (char)tolower(c); });
    return s;
}

// colour level shown next to a student's flag count
inline std::string flag_level(int flags) {
    if (flags <= 0) return "none";
    if (flags < 3) return "yellow";
    if (flags < 5) return "orange";
    return "red";
}

// Reads CSV text into rows of fields. Handles "quoted, fields", doubled quotes and \r\n.
inline std::vector<std::vector<std::string>> parse_csv(std::string text) {
    if (text.size() >= 3 && (unsigned char)text[0] == 0xEF && (unsigned char)text[1] == 0xBB &&
        (unsigned char)text[2] == 0xBF)
        text = text.substr(3);  // remove the byte-order mark Excel adds

    std::vector<std::vector<std::string>> rows;
    std::vector<std::string> row;
    std::string field;
    bool in_quotes = false;
    bool any = false;  // did this row contain anything

    auto end_field = [&]() {
        row.push_back(trim(field));
        field.clear();
    };
    auto end_row = [&]() {
        end_field();
        bool empty = true;
        for (auto& f : row)
            if (!f.empty()) empty = false;
        if (!empty) rows.push_back(row);
        row.clear();
        any = false;
    };

    for (size_t i = 0; i < text.size(); i++) {
        char c = text[i];
        any = true;
        if (in_quotes) {
            if (c == '"') {
                if (i + 1 < text.size() && text[i + 1] == '"') {
                    field += '"';
                    i++;
                } else {
                    in_quotes = false;
                }
            } else {
                field += c;
            }
        } else if (c == '"') {
            in_quotes = true;
        } else if (c == ',') {
            end_field();
        } else if (c == '\n') {
            end_row();
        } else if (c != '\r') {
            field += c;
        }
    }
    if (any || !field.empty() || !row.empty()) end_row();
    return rows;
}

// one CSV cell, quoted when needed
inline std::string csv_escape(const std::string& s) {
    if (s.find_first_of(",\"\n\r") == std::string::npos) return s;
    std::string out = "\"";
    for (char c : s) {
        if (c == '"') out += '"';
        out += c;
    }
    return out + "\"";
}

// JSON value as plain text (for CSV export)
inline std::string cell_text(const json& v) {
    if (v.is_null()) return "";
    if (v.is_string()) return v.get<std::string>();
    if (v.is_boolean()) return v.get<bool>() ? "1" : "0";
    return v.dump();
}

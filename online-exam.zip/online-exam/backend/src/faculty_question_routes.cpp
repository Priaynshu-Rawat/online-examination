// faculty_question_routes.cpp : the faculty's subjects and QUESTION BANK
//   list / create / edit / delete a question, and bulk upload from a CSV file
#include <set>

#include "http_common.hpp"

namespace {

struct OptionIn {
    std::string text;
    bool correct;
};

void need_teaches(App& app, int faculty_id, int subject_id) {
    json r = app.db.query("SELECT 1 FROM faculty_subject WHERE faculty_id = ? AND subject_id = ?", {faculty_id, subject_id});
    if (r.empty()) throw HttpError(403, "You do not teach this subject");
}

// the rules every question must follow. Throws a 400 with the reason.
void validate_question(const std::string& text, const std::string& type, const std::vector<OptionIn>& opts) {
    if (text.size() < 5) throw HttpError(400, "The question text is too short");
    if (type != "SINGLE" && type != "MULTIPLE") throw HttpError(400, "Type must be SINGLE or MULTIPLE");
    if (opts.size() < 2) throw HttpError(400, "A question needs at least 2 options");
    if (opts.size() > 8) throw HttpError(400, "A question can have at most 8 options");
    int correct = 0;
    std::set<std::string> seen;
    for (auto& o : opts) {
        if (o.text.empty()) throw HttpError(400, "An option is empty");
        if (o.text.size() > 300) throw HttpError(400, "An option is too long");
        if (!seen.insert(to_lower(o.text)).second) throw HttpError(400, "Two options have the same text");
        if (o.correct) correct++;
    }
    if (type == "SINGLE" && correct != 1) throw HttpError(400, "A single-answer question needs exactly 1 correct option");
    if (type == "MULTIPLE" && correct < 2) throw HttpError(400, "A multiple-answer question needs at least 2 correct options");
}

std::vector<OptionIn> options_from_json(const json& b) {
    if (!b.contains("options") || !b["options"].is_array()) throw HttpError(400, "Missing options");
    std::vector<OptionIn> opts;
    for (auto& o : b["options"]) {
        if (!o.is_object()) throw HttpError(400, "Bad option");
        opts.push_back({trim(o.value("text", std::string(""))), opt_bool(o, "is_correct", false)});
    }
    return opts;
}

// does this faculty already have this question (same text, ignoring case/spaces/punctuation) in the bank?
bool in_bank(App& app, int faculty_id, int subject_id, const std::string& text, int except_id = 0) {
    json r = app.db.query(
        "SELECT question_id FROM question WHERE created_by = ? AND subject_id = ? AND question_id <> ? "
        "AND question_hash = SHA2(REGEXP_REPLACE(LOWER(?), '[[:space:][:punct:]]+', ''), 256)",
        {faculty_id, subject_id, except_id, text});
    return !r.empty();
}

void insert_options(Lease& lease, long long question_id, const std::vector<OptionIn>& opts) {
    char label = 'A';
    for (auto& o : opts) {
        lease.exec("INSERT INTO question_option (question_id, label, option_text, is_correct) VALUES (?, ?, ?, ?)",
                   {question_id, std::string(1, label++), o.text, o.correct ? 1 : 0});
    }
}

// creates the question and its options in one transaction, returns the new id
long long create_question(App& app, int faculty_id, int subject_id, const std::string& text, const std::string& type,
                          const std::vector<OptionIn>& opts) {
    validate_question(text, type, opts);
    if (in_bank(app, faculty_id, subject_id, text)) throw HttpError(409, "This question is already in your question bank");
    Lease lease = app.db.lease();
    lease.begin();
    try {
        lease.exec("INSERT INTO question (subject_id, created_by, question_text, question_type) VALUES (?, ?, ?, ?)",
                   {subject_id, faculty_id, text, type});
        long long id = lease.insert_id();
        insert_options(lease, id, opts);
        lease.commit();
        return id;
    } catch (...) {
        lease.rollback();
        throw;
    }
}

json load_questions(App& app, const std::string& where_sql, const json& params) {
    json qs = app.db.query(
        "SELECT q.question_id, q.question_text AS text, q.question_type AS type, "
        "       (SELECT COUNT(*) FROM exam_question eq WHERE eq.question_id = q.question_id) AS used_in_exams, "
        "       q.created_by "
        "FROM question q WHERE " + where_sql + " ORDER BY q.question_id DESC",
        params);
    if (qs.empty()) return qs;
    std::string ids;
    for (auto& q : qs) ids += (ids.empty() ? "" : ",") + std::to_string(q["question_id"].get<int>());
    // the ids are numbers produced by our own code, so building this text is safe
    json opts = app.db.query("SELECT question_id, option_id, label, option_text AS text, is_correct FROM question_option "
                             "WHERE question_id IN (" + ids + ") ORDER BY question_id, label");
    for (auto& q : qs) q["options"] = json::array();
    for (auto& o : opts)
        for (auto& q : qs)
            if (q["question_id"] == o["question_id"]) {
                json oo = o;
                oo.erase("question_id");
                q["options"].push_back(oo);
                break;
            }
    return qs;
}

}  // namespace

void register_faculty_question_routes(httplib::Server& svr, App& app) {
    // subjects this faculty teaches
    svr.Get("/api/faculty/subjects", secured(app, "faculty", [&app](const httplib::Request&, httplib::Response& res, const User& u) {
        json rows = app.db.query(
            "SELECT s.subject_id, s.code, s.name, "
            "       (SELECT COUNT(*) FROM enrollment en WHERE en.subject_id = s.subject_id) AS students "
            "FROM faculty_subject fs JOIN subject s ON s.subject_id = fs.subject_id "
            "WHERE fs.faculty_id = ? ORDER BY s.code",
            {u.id});
        send_json(res, 200, {{"subjects", rows}});
    }));

    // the faculty's own questions of one subject
    svr.Get("/api/faculty/questions", secured(app, "faculty", [&app](const httplib::Request& req, httplib::Response& res, const User& u) {
        int subject_id = query_int(req, "subject_id");
        if (subject_id <= 0) throw HttpError(400, "subject_id is needed");
        need_teaches(app, u.id, subject_id);
        json qs = load_questions(app, "q.subject_id = ? AND q.created_by = ?", {subject_id, u.id});
        for (auto& q : qs) {
            q["created_by_me"] = true;
            q.erase("created_by");
        }
        send_json(res, 200, {{"questions", qs}});
    }));

    svr.Post("/api/faculty/questions", secured(app, "faculty", [&app](const httplib::Request& req, httplib::Response& res, const User& u) {
        json b = read_body(req);
        int subject_id = (int)need_int(b, "subject_id");
        need_teaches(app, u.id, subject_id);
        long long id = create_question(app, u.id, subject_id, need_str(b, "text", 4000), need_str(b, "type", 10),
                                       options_from_json(b));
        app.audit("FACULTY", u.id, "QUESTION_CREATED", "question=" + std::to_string(id));
        send_json(res, 200, {{"question_id", id}});
    }));

    // edit: only while the question is not used in any exam (its paper hash would go out of date)
    svr.Put(R"(/api/faculty/questions/(\d+))", secured(app, "faculty", [&app](const httplib::Request& req, httplib::Response& res, const User& u) {
        int id = path_id(req);
        json q = app.db.query(
            "SELECT subject_id, created_by, (SELECT COUNT(*) FROM exam_question eq WHERE eq.question_id = ?) AS used "
            "FROM question WHERE question_id = ?",
            {id, id});
        if (q.empty()) throw HttpError(404, "Question not found");
        if (q[0]["created_by"].get<int>() != u.id) throw HttpError(403, "You can change only your own questions");
        if (q[0]["used"].get<int>() > 0)
            throw HttpError(409, "This question is used in an exam. Remove it from the paper before editing.");

        json b = read_body(req);
        std::string text = need_str(b, "text", 4000), type = need_str(b, "type", 10);
        auto opts = options_from_json(b);
        validate_question(text, type, opts);
        if (in_bank(app, u.id, q[0]["subject_id"].get<int>(), text, id))
            throw HttpError(409, "Another question in your bank has this text");

        Lease lease = app.db.lease();
        lease.begin();
        try {
            lease.exec("UPDATE question SET question_text = ?, question_type = ? WHERE question_id = ?", {text, type, id});
            lease.exec("DELETE FROM question_option WHERE question_id = ?", {id});
            insert_options(lease, id, opts);
            lease.commit();
        } catch (...) {
            lease.rollback();
            throw;
        }
        app.cache.invalidate(id);
        app.audit("FACULTY", u.id, "QUESTION_EDITED", "question=" + std::to_string(id));
        send_json(res, 200, {{"ok", true}});
    }));

    svr.Delete(R"(/api/faculty/questions/(\d+))", secured(app, "faculty", [&app](const httplib::Request& req, httplib::Response& res, const User& u) {
        int id = path_id(req);
        json q = app.db.query(
            "SELECT created_by, (SELECT COUNT(*) FROM exam_question eq WHERE eq.question_id = ?) AS used "
            "FROM question WHERE question_id = ?",
            {id, id});
        if (q.empty()) throw HttpError(404, "Question not found");
        if (q[0]["created_by"].get<int>() != u.id) throw HttpError(403, "You can delete only your own questions");
        if (q[0]["used"].get<int>() > 0) throw HttpError(409, "This question is used in an exam and cannot be deleted");
        app.db.exec("DELETE FROM question WHERE question_id = ?", {id});
        app.cache.invalidate(id);
        app.audit("FACULTY", u.id, "QUESTION_DELETED", "question=" + std::to_string(id));
        send_json(res, 200, {{"ok", true}});
    }));

    // bulk upload.  CSV header: question,type,option_a,option_b,option_c,option_d,correct
    svr.Post("/api/faculty/questions/upload", secured(app, "faculty", [&app](const httplib::Request& req, httplib::Response& res, const User& u) {
        json b = read_body(req);
        int subject_id = (int)need_int(b, "subject_id");
        need_teaches(app, u.id, subject_id);
        auto rows = parse_csv(need_str(b, "csv", 2000000));
        if (rows.size() < 2) throw HttpError(400, "The file has no data rows");
        if (rows.size() > 2001) throw HttpError(400, "At most 2000 questions per file");

        // find the columns by their header names
        int col_q = -1, col_type = -1, col_correct = -1;
        std::vector<int> col_opts;
        for (size_t i = 0; i < rows[0].size(); i++) {
            std::string h = to_lower(rows[0][i]);
            if (h == "question") col_q = (int)i;
            else if (h == "type") col_type = (int)i;
            else if (h == "correct") col_correct = (int)i;
            else if (h.rfind("option", 0) == 0) col_opts.push_back((int)i);
        }
        if (col_q < 0 || col_correct < 0 || col_opts.size() < 2)
            throw HttpError(400, "Header must contain: question, option_a, option_b, ..., correct (type is optional)");

        int added = 0;
        json skipped = json::array();
        for (size_t r = 1; r < rows.size(); r++) {
            auto cell = [&](int c) { return c >= 0 && c < (int)rows[r].size() ? rows[r][c] : std::string(); };
            try {
                // each option column has a letter by its position: first option column = A
                std::vector<OptionIn> opts;
                std::vector<int> letter_to_index(col_opts.size(), -1);
                for (size_t k = 0; k < col_opts.size(); k++) {
                    std::string t = cell(col_opts[k]);
                    if (t.empty()) continue;
                    letter_to_index[k] = (int)opts.size();
                    opts.push_back({t, false});
                }
                std::string correct = cell(col_correct);
                std::string token;
                std::vector<std::string> tokens;
                for (char c : correct + ";") {
                    if (c == ';' || c == ',' || c == ' ') {
                        if (!token.empty()) tokens.push_back(to_upper(token));
                        token.clear();
                    } else token += c;
                }
                if (tokens.empty()) throw HttpError(400, "No correct answer given");
                for (auto& t : tokens) {
                    int k = (t.size() == 1) ? t[0] - 'A' : -1;
                    if (k < 0 || k >= (int)col_opts.size() || letter_to_index[k] < 0)
                        throw HttpError(400, "Correct answer '" + t + "' does not match an option");
                    opts[letter_to_index[k]].correct = true;
                }
                int ncorrect = 0;
                for (auto& o : opts) ncorrect += o.correct;
                std::string type = to_upper(cell(col_type));
                if (type.empty()) type = ncorrect >= 2 ? "MULTIPLE" : "SINGLE";
                create_question(app, u.id, subject_id, cell(col_q), type, opts);
                added++;
            } catch (const HttpError& e) {
                skipped.push_back({{"row", r + 1}, {"reason", e.what()}});
            }
        }
        app.audit("FACULTY", u.id, "QUESTIONS_UPLOADED", std::to_string(added) + " added, " + std::to_string(skipped.size()) + " skipped");
        send_json(res, 200, {{"added", added}, {"skipped", skipped}});
    }));
}

// auth_routes.cpp : login, logout, register, "who am I"
#include "http_common.hpp"

void register_auth_routes(httplib::Server& svr, App& app) {
    // POST /api/login   { role, email, password }
    svr.Post("/api/login", open_route(app, [&app](const httplib::Request& req, httplib::Response& res) {
                 json b = read_body(req);
                 std::string role = need_str(b, "role", 20);
                 std::string email = to_lower(need_str(b, "email", 120));
                 std::string password = need_str(b, "password", 200);

                 // the table names below are fixed text from this code, never from the user
                 std::string table, id_col;
                 if (role == "student") table = "student", id_col = "student_id";
                 else if (role == "faculty") table = "faculty", id_col = "faculty_id";
                 else if (role == "admin") table = "admin", id_col = "admin_id";
                 else throw HttpError(400, "Unknown role");

                 json rows = app.db.query("SELECT " + id_col + " AS id, name, password_hash FROM " + table +
                                              " WHERE email = ?",
                                          {email});
                 bool ok = !rows.empty() && verify_password(rows[0]["password_hash"].get<std::string>(), password);
                 if (!ok) {
                     app.audit("SYSTEM", 0, "LOGIN_FAILED", role + " " + email);
                     app.log.warn("failed login: " + role + " " + email);
                     throw HttpError(401, "Wrong email or password");
                 }
                 User u{role, rows[0]["id"].get<int>(), rows[0]["name"].get<std::string>()};
                 std::string token = app.tokens.create(u);
                 std::string actor = to_upper(role);
                 app.audit(actor, u.id, "LOGIN", email);
                 app.log.info("login: " + role + " " + email);
                 send_json(res, 200, {{"token", token}, {"role", role}, {"id", u.id}, {"name", u.name}});
             }));

    // POST /api/register   (students sign themselves up)
    svr.Post("/api/register", open_route(app, [&app](const httplib::Request& req, httplib::Response& res) {
                 json b = read_body(req);
                 std::string roll = need_str(b, "roll_no", 30);
                 std::string name = need_str(b, "name", 100);
                 std::string email = to_lower(need_str(b, "email", 120));
                 std::string password = need_str(b, "password", 200);
                 if (email.find('@') == std::string::npos) throw HttpError(400, "Enter a valid email");
                 if (password.size() < 6) throw HttpError(400, "Password must be at least 6 characters");
                 try {
                     app.db.exec("INSERT INTO student (roll_no, name, email, password_hash) VALUES (?, ?, ?, ?)",
                                 {roll, name, email, hash_password(password)});
                 } catch (const DbError& e) {
                     if (e.code == 1062) throw HttpError(409, "This roll number or email is already registered");
                     throw;
                 }
                 app.audit("SYSTEM", 0, "REGISTER", roll);
                 send_json(res, 200, {{"ok", true}});
             }));

    // POST /api/logout
    svr.Post("/api/logout", any_user(app, [&app](const httplib::Request& req, httplib::Response& res, const User& u) {
                 app.tokens.remove(token_of(req));
                 app.audit(to_upper(u.role), u.id, "LOGOUT", "");
                 send_json(res, 200, {{"ok", true}});
             }));

    // GET /api/me
    svr.Get("/api/me", any_user(app, [](const httplib::Request&, httplib::Response& res, const User& u) {
                send_json(res, 200, {{"role", u.role}, {"id", u.id}, {"name", u.name}});
            }));
}

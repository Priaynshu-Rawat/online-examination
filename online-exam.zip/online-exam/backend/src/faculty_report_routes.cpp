// faculty_report_routes.cpp : after the exam
//   results register (+ CSV), student history, answer review, timeline, ANALYSIS, activity log
#include <algorithm>

#include "http_common.hpp"

namespace {

bool truthy(const json& v) {
    if (v.is_null()) return false;
    if (v.is_boolean()) return v.get<bool>();
    if (v.is_number()) return v.get<double>() != 0;
    return false;
}

// the first result set of a CALL
json first_set(const std::vector<json>& sets) { return sets.empty() ? json::array() : sets[0]; }

json exam_header(App& app, int exam_id) {
    json r = app.db.query(
        "SELECT e.exam_id, e.title, e.start_time, e.end_time, e.subject_id, s.code AS subject_code, "
        "       (SELECT COALESCE(SUM(eq.marks), 0) FROM exam_question eq WHERE eq.exam_id = e.exam_id AND eq.status <> 'DROPPED') AS total_marks "
        "FROM exam e JOIN subject s ON s.subject_id = e.subject_id WHERE e.exam_id = ?",
        {exam_id});
    if (r.empty()) throw HttpError(404, "Exam not found");
    return r[0];
}

// the register rows with the colour level added
json register_rows(App& app, int faculty_id, int exam_id) {
    json rows = first_set(app.db.call("CALL get_exam_register(?, ?)", {faculty_id, exam_id}));
    return rows;
}

// access to an attempt of an exam whose subject this faculty teaches
void need_attempt_access(App& app, int faculty_id, int attempt_id) {
    json r = app.db.query("SELECT exam_id FROM exam_attempt WHERE attempt_id = ?", {attempt_id});
    if (r.empty()) throw HttpError(404, "Attempt not found");
    need_subject_access(app, faculty_id, r[0]["exam_id"].get<int>());
}

}  // namespace

void register_faculty_report_routes(httplib::Server& svr, App& app) {
    // ---------------------------------------------------------------- register sheet
    svr.Get(R"(/api/faculty/exams/(\d+)/register)", secured(app, "faculty", [&app](const httplib::Request& req, httplib::Response& res, const User& u) {
        int id = path_id(req);
        json rows = register_rows(app, u.id, id);  // the procedure checks access and that the exam has ended
        send_json(res, 200, {{"exam", exam_header(app, id)}, {"rows", rows}});
    }));

    svr.Get(R"(/api/faculty/exams/(\d+)/register\.csv)", secured(app, "faculty", [&app](const httplib::Request& req, httplib::Response& res, const User& u) {
        int id = path_id(req);
        json rows = register_rows(app, u.id, id);
        static const std::vector<std::pair<const char*, const char*>> columns = {
            {"Roll No", "roll_no"},        {"Name", "name"},           {"Email", "email"},
            {"Status", "status"},          {"Attempt", "attempt_no"},  {"Marks Obtained", "marks_obtained"},
            {"Total Marks", "total_marks"}, {"Percentage", "percentage"}, {"Correct", "correct_count"},
            {"Wrong", "wrong_count"},      {"Skipped", "skipped_count"}, {"Flags", "flag_count"},
            {"Resumes", "resume_count"},   {"Joined At", "joined_at"}, {"Submitted At", "submit_time"},
            {"Minutes Taken", "minutes_taken"}};
        std::string csv = "\xEF\xBB\xBF";  // lets Excel read it as UTF-8
        for (size_t i = 0; i < columns.size(); i++) csv += (i ? "," : "") + csv_escape(columns[i].first);
        csv += "\r\n";
        for (auto& r : rows) {
            for (size_t i = 0; i < columns.size(); i++)
                csv += (i ? "," : "") + csv_escape(cell_text(r[columns[i].second]));
            csv += "\r\n";
        }
        res.status = 200;
        res.set_header("Content-Disposition", "attachment; filename=\"exam-" + std::to_string(id) + "-register.csv\"");
        res.set_content(csv, "text/csv; charset=utf-8");
    }));

    // ---------------------------------------------------------------- one student's history in a subject
    svr.Get(R"(/api/faculty/students/(\d+)/history)", secured(app, "faculty", [&app](const httplib::Request& req, httplib::Response& res, const User& u) {
        int student_id = path_id(req);
        int subject_id = query_int(req, "subject_id");
        if (subject_id <= 0) throw HttpError(400, "subject_id is needed");
        json rows = first_set(app.db.call("CALL get_student_subject_history(?, ?, ?)", {u.id, student_id, subject_id}));
        json student = app.db.query("SELECT roll_no, name, email FROM student WHERE student_id = ?", {student_id});
        double sum = 0;
        int n = 0;
        for (auto& r : rows)
            if (truthy(r["counts_for_marks"]) && r["percentage"].is_number()) {
                sum += r["percentage"].get<double>();
                n++;
            }
        send_json(res, 200, {{"student", student.empty() ? json::object() : student[0]},
                             {"rows", rows},
                             {"average_percentage", n ? json(sum / n) : json(nullptr)}});
    }));

    // ---------------------------------------------------------------- answer review / timeline
    svr.Get(R"(/api/faculty/attempts/(\d+)/review)", secured(app, "faculty", [&app](const httplib::Request& req, httplib::Response& res, const User& u) {
        int id = path_id(req);
        need_attempt_access(app, u.id, id);
        send_json(res, 200, {{"review", first_set(app.db.call("CALL get_attempt_review(?)", {id}))}});
    }));

    svr.Get(R"(/api/faculty/attempts/(\d+)/timeline)", secured(app, "faculty", [&app](const httplib::Request& req, httplib::Response& res, const User& u) {
        int id = path_id(req);
        need_attempt_access(app, u.id, id);
        send_json(res, 200, {{"events", first_set(app.db.call("CALL get_attempt_timeline(?)", {id}))}});
    }));

    // ---------------------------------------------------------------- ANALYSIS
    svr.Get(R"(/api/faculty/exams/(\d+)/analysis)", secured(app, "faculty", [&app](const httplib::Request& req, httplib::Response& res, const User& u) {
        int id = path_id(req);
        need_subject_access(app, u.id, id);
        json ended = app.db.query("SELECT (end_time <= NOW()) AS ended FROM exam WHERE exam_id = ?", {id});
        if (ended.empty()) throw HttpError(404, "Exam not found");
        if (!truthy(ended[0]["ended"])) throw HttpError(409, "The analysis is available after the exam has ended");

        json sum = app.db.query("SELECT enrolled, attempted, avg_marks, max_marks, min_marks, pass_rate FROM v_exam_summary WHERE exam_id = ?", {id});
        json summary = sum.empty() ? json::object() : sum[0];
        summary["absent"] = summary["enrolled"].get<int>() - summary["attempted"].get<int>();

        json questions = app.db.query(
            "SELECT question_id, display_order, question_text, students, correct_cnt, wrong_cnt, skipped_cnt, "
            "       pct_correct, pct_wrong, pct_skipped "
            "FROM v_question_stats WHERE exam_id = ? ORDER BY display_order",
            {id});
        json options = app.db.query(
            "SELECT question_id, label, option_text, is_correct, chosen_count FROM v_option_stats WHERE exam_id = ? "
            "ORDER BY question_id, label",
            {id});
        for (auto& q : questions) {
            q["options"] = json::array();
            for (auto& o : options)
                if (o["question_id"] == q["question_id"]) {
                    json oo = o;
                    oo.erase("question_id");
                    q["options"].push_back(oo);
                }
        }

        auto top = [&](const char* field) {
            std::vector<json> v(questions.begin(), questions.end());
            std::stable_sort(v.begin(), v.end(), [&](const json& a, const json& b) { return a[field].get<int>() > b[field].get<int>(); });
            json out = json::array();
            for (auto& q : v) {
                if (out.size() >= 5 || q[field].get<int>() == 0) break;
                out.push_back(q);
            }
            return out;
        };

        // score distribution: ten buckets of 10 percent
        json dist = json::array();
        for (int i = 0; i < 10; i++)
            dist.push_back({{"label", std::to_string(i * 10) + "-" + std::to_string(i * 10 + 10) + "%"}, {"count", 0}});
        json buckets = app.db.query(
            "SELECT LEAST(9, GREATEST(0, FLOOR(percentage / 10))) AS b, COUNT(*) AS c FROM v_counted_result "
            "WHERE exam_id = ? GROUP BY b",
            {id});
        for (auto& b : buckets) dist[b["b"].get<int>()]["count"] = b["c"];

        send_json(res, 200, {{"summary", summary},
                             {"questions", questions},
                             {"most_wrong", top("wrong_cnt")},
                             {"most_skipped", top("skipped_cnt")},
                             {"distribution", dist}});
    }));

    // ---------------------------------------------------------------- activity log
    svr.Get("/api/faculty/log", secured(app, "faculty", [&app](const httplib::Request& req, httplib::Response& res, const User&) {
        int limit = std::max(1, std::min(1000, query_int(req, "limit", 200)));
        json rows = app.db.query(
            "SELECT event_time, actor_type, actor_id, action, details FROM activity_log ORDER BY log_id DESC LIMIT ?", {limit});
        send_json(res, 200, {{"rows", rows}});
    }));
}

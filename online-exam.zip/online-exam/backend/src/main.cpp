// main.cpp : starts the Online Examination server
//
//   exam_server                      run the server (reads config.json from the current folder)
//   exam_server --set-demo-passwords give every sample account the password  password123
//   exam_server --create-admin "Name" email password
//
// What happens at start-up:
//   1. read config.json, connect to MySQL (a pool of connections)
//   2. CRASH RECOVERY: end attempts whose time ran out while the server was down and rebuild the
//      in-memory session table from MySQL, so students can simply resume
//   3. start the background monitor thread and the submission scheduler threads
//   4. start the web server with our own thread pool (WorkerQueue)
#include <condition_variable>
#include <csignal>
#include <filesystem>
#include <iostream>
#include <mutex>
#include <queue>
#include <thread>

#include "http_common.hpp"
#include "monitor.hpp"

// ---------------------------------------------------------------------------------------------
// THREAD POOL for web requests.
// A fixed team of worker threads waits on a queue. When a request arrives the web server puts
// it in the queue (producer) and one sleeping worker wakes up and handles it (consumer).
// OS concepts: threads, mutex, condition variable, producer/consumer queue.
// ---------------------------------------------------------------------------------------------
class WorkerQueue : public httplib::TaskQueue {
public:
    WorkerQueue(size_t n, PoolStats& stats) : stats_(stats) {
        stats_.workers = (int)n;
        for (size_t i = 0; i < n; i++) workers_.emplace_back([this] { loop(); });
    }

    bool enqueue(std::function<void()> job) override {
        {
            std::lock_guard<std::mutex> lock(m_);
            if (stop_) return false;
            queue_.push(std::move(job));
            stats_.queued = queue_.size();
        }
        cv_.notify_one();  // wake exactly one sleeping worker
        return true;
    }

    void shutdown() override {
        {
            std::lock_guard<std::mutex> lock(m_);
            stop_ = true;
        }
        cv_.notify_all();
        for (auto& t : workers_)
            if (t.joinable()) t.join();
    }

private:
    void loop() {
        for (;;) {
            std::function<void()> job;
            {
                std::unique_lock<std::mutex> lock(m_);
                cv_.wait(lock, [this] { return stop_ || !queue_.empty(); });  // sleep until there is work
                if (stop_ && queue_.empty()) return;
                job = std::move(queue_.front());
                queue_.pop();
                stats_.queued = queue_.size();
            }
            stats_.busy++;
            job();
            stats_.busy--;
        }
    }

    PoolStats& stats_;
    std::mutex m_;
    std::condition_variable cv_;
    std::queue<std::function<void()>> queue_;
    std::vector<std::thread> workers_;
    bool stop_ = false;
};

static httplib::Server* g_server = nullptr;
static void on_stop_signal(int) {
    if (g_server) g_server->stop();
}

// ---------------------------------------------------------------------------------------------
static int set_demo_passwords(App& app) {
    std::string hash = hash_password("password123");
    long long total = 0;
    for (const char* table : {"admin", "faculty", "student"})
        total += app.db.exec(std::string("UPDATE ") + table + " SET password_hash = ? WHERE password_hash = 'hash_placeholder'", {hash});
    std::cout << "Demo accounts updated: " << total << ". Their password is now  password123\n";
    return 0;
}

static int create_admin(App& app, const std::string& name, const std::string& email, const std::string& password) {
    if (password.size() < 6) {
        std::cerr << "Password must be at least 6 characters\n";
        return 1;
    }
    app.db.exec("INSERT INTO admin (name, email, password_hash) VALUES (?, ?, ?)", {name, to_lower(email), hash_password(password)});
    std::cout << "Admin created: " << email << "\n";
    return 0;
}

// rebuild the session table after a restart
static void recover(App& app) {
    auto sets = app.db.call("CALL recover_sessions()");
    int restored = 0;
    if (!sets.empty()) {
        for (auto& r : sets[0]) {
            Session s;
            s.attempt_id = r["attempt_id"].get<int>();
            s.student_id = r["student_id"].get<int>();
            s.exam_id = r["exam_id"].get<int>();
            long long left = app.db.query("SELECT TIMESTAMPDIFF(SECOND, NOW(), deadline) AS s FROM exam_attempt WHERE attempt_id = ?",
                                          {s.attempt_id})[0]["s"].get<long long>();
            s.deadline_epoch = now_epoch() + left;
            s.last_heartbeat = now_epoch();  // grace period: the crash gap is NOT counted as a flag
            app.sessions.upsert(s);
            restored++;
        }
    }
    app.log.info("crash recovery: " + std::to_string(restored) + " sessions restored");
}

int main(int argc, char** argv) {
    if (sodium_init() < 0) {
        std::cerr << "Could not start libsodium\n";
        return 1;
    }

    std::string config_path = "config.json";
    std::string command;
    std::vector<std::string> extra;
    for (int i = 1; i < argc; i++) {
        std::string a = argv[i];
        if (a.rfind("--", 0) == 0 && command.empty()) command = a;
        else if (command.empty() && a.size() > 5 && a.substr(a.size() - 5) == ".json") config_path = a;
        else extra.push_back(a);
    }

    try {
        std::filesystem::create_directories("../logs");
    } catch (...) {
    }

    Config cfg = Config::load(config_path);
    std::unique_ptr<App> app_ptr;
    try {
        app_ptr = std::make_unique<App>(cfg);
    } catch (const DbError& e) {
        std::cerr << "\nCould not start: " << e.what() << "\n"
                  << "Check config.json (host, user, password, database) and that MySQL is running.\n";
        return 1;
    }
    App& app = *app_ptr;

    try {
        if (command == "--set-demo-passwords") return set_demo_passwords(app);
        if (command == "--create-admin") {
            if (extra.size() != 3) {
                std::cerr << "Usage: exam_server --create-admin \"Name\" email password\n";
                return 1;
            }
            return create_admin(app, extra[0], extra[1], extra[2]);
        }
        recover(app);
    } catch (const std::exception& e) {
        std::cerr << "Start-up error: " << e.what() << "\n";
        return 1;
    }

    Monitor monitor(app);  // background thread: timers and lost connections

    httplib::Server svr;
    g_server = &svr;
    std::signal(SIGINT, on_stop_signal);
    std::signal(SIGTERM, on_stop_signal);

    int workers = cfg.http_workers;
    svr.new_task_queue = [&app, workers] { return new WorkerQueue((size_t)workers, app.pool); };
    svr.set_keep_alive_timeout(1);  // a connection must not keep a worker thread busy for long

    register_auth_routes(svr, app);
    register_student_routes(svr, app);
    register_faculty_question_routes(svr, app);
    register_faculty_exam_routes(svr, app);
    register_faculty_report_routes(svr, app);
    register_admin_routes(svr, app);

    if (!std::filesystem::exists(cfg.web_root))
        app.log.warn("web folder not found: " + cfg.web_root + " (run the server from the backend folder)");
    svr.set_mount_point("/", cfg.web_root);

    svr.set_pre_routing_handler([](const httplib::Request& req, httplib::Response& res) {
        res.set_header("X-Content-Type-Options", "nosniff");
        if (req.path.rfind("/api/", 0) == 0) res.set_header("Cache-Control", "no-store");
        return httplib::Server::HandlerResponse::Unhandled;
    });
    svr.set_error_handler([](const httplib::Request& req, httplib::Response& res) {
        if (req.path.rfind("/api/", 0) == 0 && res.body.empty())
            send_json(res, res.status, {{"error", res.status == 404 ? "Unknown address" : "Request failed"}});
    });
    svr.set_logger([&app](const httplib::Request& req, const httplib::Response& res) {
        if (req.path.rfind("/api/", 0) == 0 && (res.status >= 400 || req.method != "GET") &&
            req.path.find("heartbeat") == std::string::npos && req.path.find("/answer") == std::string::npos)
            app.log.info(req.method + " " + req.path + " -> " + std::to_string(res.status));
    });

    app.log.info("Online Examination server on http://" + cfg.host + ":" + std::to_string(cfg.port) + "  (policy " +
                 policy_name(app.scheduler.policy()) + ", " + std::to_string(workers) + " web threads)");
    if (!svr.listen(cfg.host, cfg.port)) {
        app.log.error("Could not listen on port " + std::to_string(cfg.port) + " (is it already in use?)");
        return 1;
    }
    app.log.info("server stopped");
    return 0;
}

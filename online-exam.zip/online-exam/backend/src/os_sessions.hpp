// os_sessions.hpp : the shared tables kept in the server's memory
//
//  SessionTable  - one entry for every exam attempt that is running right now
//  TokenTable    - who is logged in (token -> user)
//  QuestionCache - a small bounded cache of questions (memory management, LRU)
//
// OS concepts shown here:
//  * Many worker threads read and change these tables at the same time. That is a CRITICAL
//    SECTION, so every function locks a mutex first. Without the lock two threads could change
//    the same entry together (a RACE CONDITION) and the data would get corrupted.
//  * QuestionCache has a fixed size. When it is full the LEAST RECENTLY USED question is thrown
//    away (LRU replacement), exactly like page replacement in an operating system.
#pragma once
#include <list>
#include <mutex>
#include <optional>
#include <string>
#include <unordered_map>
#include <vector>

#include "util.hpp"

// ---------------------------------------------------------------------------------------------
struct Session {
    int attempt_id = 0;
    int student_id = 0;
    int exam_id = 0;
    long long deadline_epoch = 0;  // when the attempt must end (server clock)
    long long last_heartbeat = 0;  // last time the student's page said "I am here"
    long long last_event = 0;      // last time a flag event was accepted (anti-flood)
    bool connected = true;
};

class SessionTable {
public:
    void upsert(const Session& s) {
        std::lock_guard<std::mutex> lock(m_);
        table_[s.attempt_id] = s;
    }

    bool get(int attempt_id, Session& out) {
        std::lock_guard<std::mutex> lock(m_);
        auto it = table_.find(attempt_id);
        if (it == table_.end()) return false;
        out = it->second;
        return true;
    }

    // "I am alive": returns false if there is no such session.
    // was_disconnected tells the caller that the student had been marked as gone.
    bool touch(int attempt_id, bool& was_disconnected) {
        std::lock_guard<std::mutex> lock(m_);
        auto it = table_.find(attempt_id);
        if (it == table_.end()) return false;
        was_disconnected = !it->second.connected;
        it->second.connected = true;
        it->second.last_heartbeat = now_epoch();
        return true;
    }

    void set_connected(int attempt_id, bool value) {
        std::lock_guard<std::mutex> lock(m_);
        auto it = table_.find(attempt_id);
        if (it != table_.end()) it->second.connected = value;
    }

    bool is_connected(int attempt_id) {
        std::lock_guard<std::mutex> lock(m_);
        auto it = table_.find(attempt_id);
        return it != table_.end() && it->second.connected;
    }

    // true if enough time passed since the last accepted flag event (stops event floods)
    bool allow_event(int attempt_id, int min_gap_seconds) {
        std::lock_guard<std::mutex> lock(m_);
        auto it = table_.find(attempt_id);
        if (it == table_.end()) return true;
        long long now = now_epoch();
        if (now - it->second.last_event < min_gap_seconds) return false;
        it->second.last_event = now;
        return true;
    }

    void remove(int attempt_id) {
        std::lock_guard<std::mutex> lock(m_);
        table_.erase(attempt_id);
    }

    std::vector<Session> snapshot() {
        std::lock_guard<std::mutex> lock(m_);
        std::vector<Session> all;
        for (auto& kv : table_) all.push_back(kv.second);
        return all;
    }

    size_t size() {
        std::lock_guard<std::mutex> lock(m_);
        return table_.size();
    }

private:
    std::mutex m_;
    std::unordered_map<int, Session> table_;
};

// ---------------------------------------------------------------------------------------------
struct User {
    std::string role;  // "student", "faculty" or "admin"
    int id = 0;
    std::string name;
};

class TokenTable {
public:
    std::string create(const User& u) {
        std::string token = random_hex(32);
        std::lock_guard<std::mutex> lock(m_);
        table_[token] = {u, now_epoch() + 12 * 3600};  // a login lasts 12 hours
        return token;
    }

    std::optional<User> find(const std::string& token) {
        std::lock_guard<std::mutex> lock(m_);
        auto it = table_.find(token);
        if (it == table_.end()) return std::nullopt;
        if (it->second.second < now_epoch()) {
            table_.erase(it);
            return std::nullopt;
        }
        return it->second.first;
    }

    void remove(const std::string& token) {
        std::lock_guard<std::mutex> lock(m_);
        table_.erase(token);
    }

private:
    std::mutex m_;
    std::unordered_map<std::string, std::pair<User, long long>> table_;
};

// ---------------------------------------------------------------------------------------------
struct CacheStats {
    size_t size = 0, capacity = 0;
    unsigned long long hits = 0, misses = 0;
};

class QuestionCache {
public:
    explicit QuestionCache(size_t capacity) : capacity_(capacity) {}

    std::optional<json> get(int question_id) {
        std::lock_guard<std::mutex> lock(m_);
        auto it = index_.find(question_id);
        if (it == index_.end()) {
            misses_++;
            return std::nullopt;
        }
        hits_++;
        items_.splice(items_.begin(), items_, it->second);  // move to the front = most recently used
        return it->second->second;
    }

    void put(int question_id, const json& value) {
        std::lock_guard<std::mutex> lock(m_);
        auto it = index_.find(question_id);
        if (it != index_.end()) {
            it->second->second = value;
            items_.splice(items_.begin(), items_, it->second);
            return;
        }
        items_.emplace_front(question_id, value);
        index_[question_id] = items_.begin();
        if (items_.size() > capacity_) {  // full: throw away the least recently used one
            index_.erase(items_.back().first);
            items_.pop_back();
        }
    }

    void invalidate(int question_id) {
        std::lock_guard<std::mutex> lock(m_);
        auto it = index_.find(question_id);
        if (it == index_.end()) return;
        items_.erase(it->second);
        index_.erase(it);
    }

    CacheStats stats() {
        std::lock_guard<std::mutex> lock(m_);
        return {items_.size(), capacity_, hits_, misses_};
    }

private:
    std::mutex m_;
    size_t capacity_;
    std::list<std::pair<int, json>> items_;  // front = most recently used
    std::unordered_map<int, std::list<std::pair<int, json>>::iterator> index_;
    unsigned long long hits_ = 0, misses_ = 0;
};

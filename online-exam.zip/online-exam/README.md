# Online Examination System (DBMS + OS project)

Goal: reduce human effort - scheduling, marking, duplicate checking, monitoring and result registers are automatic.

    Browser (HTML/CSS/JS)  --HTTP/JSON-->  C++ server  --SQL-->  MySQL 8

- `web/`      12 plain HTML pages + one CSS + two small JS files (Chart.js for the analysis charts)
- `backend/`  C++17 server (cpp-httplib, nlohmann/json, libsodium, MariaDB Connector/C)
- `sql/`      schema, views, procedures, triggers, sample data, DB user script
- `API.md`    every request the browser sends and every answer
- `SETUP_WINDOWS.md`  step by step installation

## Where the OS concepts are
| Concept | File |
|---|---|
| Thread pool (producer/consumer queue, mutex, condition variable) | `backend/src/main.cpp` (WorkerQueue) |
| Shared tables protected by mutexes, LRU cache | `backend/src/os_sessions.hpp` |
| Scheduling policy FIFO / Round Robin for submissions | `backend/src/os_scheduler.hpp` |
| Database connection pool | `backend/src/db.hpp` |
| Background monitor thread (timers, lost connections) | `backend/src/monitor.hpp` |
| Crash recovery at start-up | `main.cpp` + `recover_sessions` procedure |

## Where the DBMS concepts are
3NF tables, keys and constraints, generated columns (duplicate-question hash), 11 views, 12 stored procedures,
11 triggers, transactions (answer saving), set-based marking (`recalc_exam_results`). See `sql/`.

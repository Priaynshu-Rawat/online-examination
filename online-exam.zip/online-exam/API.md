# Online Exam System: API contract

All endpoints are under `/api`. Requests and responses are JSON (`Content-Type: application/json`),
except the CSV downloads. After login the browser sends `Authorization: Bearer <token>` on every call.

The token may ALSO be passed as a query parameter `?token=<token>` (needed because `navigator.sendBeacon`
cannot set headers). `sendBeacon` bodies are sent as a `Blob` of type `application/json`.

Errors: HTTP status 400/401/403/404/409/500 with body `{ "error": "message for the user" }`.
Times are strings `"YYYY-MM-DD HH:MM:SS"` in the SERVER's clock. Every list/state response that
shows a countdown also includes `server_time` and/or `seconds_left`; the browser must NEVER use
its own clock to decide anything, only to tick the display down between server answers.

Numbers (ids, marks, counts) are JSON numbers. Booleans are `true/false`.

---------------------------------------------------------------------
## 1. Auth (no token needed except logout / me)

| Method | Path | Body | Response |
|---|---|---|---|
| POST | /api/login | `{role:"student"|"faculty"|"admin", email, password}` | `{token, role, id, name}` |
| POST | /api/register | `{roll_no, name, email, password}` (students only) | `{ok:true}` |
| POST | /api/logout | - | `{ok:true}` |
| GET  | /api/me | - | `{role, id, name}` |

401 on a wrong password: `{error:"Wrong email or password"}`.
Any call with a missing/expired token returns 401 `{error:"Please log in"}` and the page must go to `/index.html`.

---------------------------------------------------------------------
## 2. Student  (role = student)

### GET /api/student/exams
`{server_time, exams:[{exam_id, title, subject_code, subject_name, faculty_name, start_time, end_time, duration_minutes, status, my_status, can_join, can_resume, attempt_id}]}`
- `status`: `UPCOMING | OPEN | CLOSED | DEACTIVATED` (exam state from the clock)
- `my_status`: `NOT_ATTEMPTED | IN_PROGRESS | SUBMITTED | AUTO_TIMEOUT | AUTO_FLAGS | ABSENT`
  (`ABSENT` = exam CLOSED and the student never joined)
- `can_join`: status OPEN and no attempt yet (or a retake permission is unused)
- `can_resume`: my_status IN_PROGRESS and the attempt deadline has not passed
- `attempt_id`: latest attempt id or null
- Only exams of subjects the student is enrolled in.

### POST /api/student/exams/{exam_id}/join
Joins, or resumes if an attempt is IN_PROGRESS. Response:
```
{attempt_id, mode:"JOINED"|"RESUMED"|"RETAKE", title, deadline, seconds_left, server_time,
 flag_count, flag_limit, instructions,
 questions:[{question_id, text, type:"SINGLE"|"MULTIPLE", marks,
             options:[{option_id, label, text}]}],      // already in THIS student's shuffled order
 answers:{ "<question_id>":[option_id, ...] } }          // answers already saved
```
`label` is the ORIGINAL letter (A, B, C...). The browser shows its own position numbers (Q1, Q2...) and may show letters A, B, C by position, but keeps ids for everything it sends.
Errors: 403 not enrolled / exam closed / not started / deactivated (message from the database).

### POST /api/student/attempts/{attempt_id}/answer
Body `{question_id, option_ids:[...]}` — REPLACES the answer of that question (empty array = clear). Response `{ok:true, seconds_left}`.
SINGLE questions accept at most one id. 403 `{error:"This attempt is closed"}` when closed.

### POST /api/student/attempts/{attempt_id}/heartbeat
Sent every 5 seconds while the exam page is open. Response:
`{status, seconds_left, flag_count, flag_limit, server_time}` (`status` = attempt status; when it is not IN_PROGRESS the page must go to the result page).

### POST /api/student/attempts/{attempt_id}/event
Body `{type:"TAB_SWITCH"|"LEFT"}`. Adds one flag. Response `{status, flag_count, flag_limit}`.
(`LEFT` is sent with `navigator.sendBeacon` from `pagehide`; the server also detects missed heartbeats.)

### POST /api/student/attempts/{attempt_id}/submit
Response `{status:"SUBMITTED", message}`. If results are published and the exam is closed the page may then fetch the result.

### GET /api/student/results
`{results:[{attempt_id, exam_id, title, subject_code, attempt_no, status, submit_time, published, marks_obtained, total_marks, percentage}]}`
Marks fields are `null` while `published` is false. Only the attempt that counts is returned per exam.

### GET /api/student/results/{attempt_id}
`{attempt_id, title, published, marks_obtained, total_marks, percentage, correct_count, wrong_count, skipped_count, rank, class_average, review_allowed, review:[{display_order, question_text, question_type, selected, correct, outcome, marks_earned}]|null}`
403 `{error:"Result is not published yet"}` when not published. `review` is null unless review_allowed.

---------------------------------------------------------------------
## 3. Faculty  (role = faculty)  — only subjects the faculty teaches

### GET /api/faculty/subjects
`{subjects:[{subject_id, code, name, students}]}`

### Question bank
- GET  `/api/faculty/questions?subject_id=N` → `{questions:[{question_id, text, type, created_by_me, used_in_exams, options:[{option_id,label,text,is_correct}]}]}`
- POST `/api/faculty/questions` body `{subject_id, text, type:"SINGLE"|"MULTIPLE", options:[{text, is_correct}]}` → `{question_id}`
  Rules checked: >=2 options, SINGLE exactly 1 correct, MULTIPLE >=2 correct, no duplicate option text. 400 with the reason otherwise.
- PUT  `/api/faculty/questions/{id}` same body (without subject_id) → `{ok:true}`; 409 if an exam that started uses it.
- DELETE `/api/faculty/questions/{id}` → `{ok:true}`; 409 if used in any exam.
- POST `/api/faculty/questions/upload` body `{subject_id, csv:"<file text>"}` → `{added, skipped:[{row, reason}]}`
  CSV header: `question,type,option_a,option_b,option_c,option_d,correct` ; `correct` like `B` or `A;C`; `type` may be blank (inferred).

### Exams
- GET `/api/faculty/exams` → `{server_time, exams:[{exam_id, title, subject_id, subject_code, start_time, end_time, duration_minutes, status, is_active, question_count, total_marks, results_published}]}`
- POST `/api/faculty/exams` body `{subject_id, title, instructions, start_time, duration_minutes, negative_marks, pass_percentage, flag_limit, shuffle_questions, shuffle_options}` → `{exam_id}`
  `start_time` as `"YYYY-MM-DD HH:MM:SS"` (the page converts from a datetime-local input). Past start -> 400.
- GET `/api/faculty/exams/{id}` → `{exam:{...all columns..., status}, questions:[{question_id, display_order, marks, status, text, type, options:[...]}], total_marks}`
- PUT `/api/faculty/exams/{id}` body any of `{title, instructions, start_time, duration_minutes, negative_marks, pass_percentage, flag_limit, shuffle_questions, shuffle_options, is_active, results_published, allow_answer_review}` → `{ok:true}` (changing start/duration only before the exam starts; is_active:true runs validate_paper first and returns 400 with the problems list if it fails)
- POST `/api/faculty/exams/{id}/questions` body `{question_id, marks, force:false}`
  - 200 `{ok:true}` added
  - 409 `{error:"This question is already in this paper", kind:"SAME_PAPER"}` (hard block)
  - 409 `{kind:"OTHER_FACULTY", conflicts:[{faculty_name, exam_title, start_time, question_text, question_type, options_text}]}` — the page shows the pop-up; the faculty may resend with `force:true`, or cancel. Only the faculty who is adding sees this.
- DELETE `/api/faculty/exams/{id}/questions/{question_id}` → `{ok:true}` (only before start)
- POST `/api/faculty/exams/{id}/random` body `{count, marks}` → `{added, skipped}` (random unused questions of that subject from the bank, skipping repeats)
- POST `/api/faculty/exams/{id}/validate` → `{ok:boolean, problems:[{question_id, problem}]}`
- POST `/api/faculty/exams/{id}/clone` body `{title, start_time}` → `{exam_id}`
- POST `/api/faculty/exams/{id}/fix-question` body `{question_id, mode:"DROP"|"FREE"}` → `{ok:true}`
- POST `/api/faculty/exams/{id}/retake` body `{student_id, hours}` → `{ok:true}`

### Live monitoring
GET `/api/faculty/exams/{id}/live` → `{server_time, attempts:[{attempt_id, roll_no, name, attempt_no, seconds_left, flag_count, flag_level, resume_count, answered, connected}], total_questions}`
`flag_level` = `none|yellow|orange|red`. `connected` false when heartbeats stopped.

### Results and student records (exam must be closed)
- GET `/api/faculty/exams/{id}/register` → `{exam:{title, total_marks...}, rows:[{roll_no, student_id, name, email, status, attempt_no, joined_at, submit_time, minutes_taken, correct_count, wrong_count, skipped_count, marks_obtained, total_marks, percentage, flag_count, flag_level, resume_count}]}`
- GET `/api/faculty/exams/{id}/register.csv` → CSV download
- GET `/api/faculty/students/{student_id}/history?subject_id=N` → `{student:{roll_no,name,email}, rows:[{exam_id,title,start_time,attempt_id,attempt_no,status,flag_count,marks_obtained,total_marks,percentage,counts_for_marks}], average_percentage}`
- GET `/api/faculty/attempts/{attempt_id}/review` → `{review:[{display_order, question_text, question_type, selected, correct, outcome, marks_earned}]}`
- GET `/api/faculty/attempts/{attempt_id}/timeline` → `{events:[{event_type, event_time, note, seconds_away}]}`

### Analysis (exam must be closed)
GET `/api/faculty/exams/{id}/analysis` →
```
{summary:{enrolled, attempted, absent, avg_marks, max_marks, min_marks, pass_rate},
 questions:[{question_id, display_order, question_text, students, correct_cnt, wrong_cnt, skipped_cnt, pct_correct, pct_wrong, pct_skipped, options:[{label,option_text,is_correct,chosen_count}]}],
 most_wrong:[first 5 of questions by wrong_cnt desc], most_skipped:[first 5 by skipped_cnt desc],
 distribution:[{label:"0-10%", count}, ... 10 buckets]}
```

### Activity log
GET `/api/faculty/log?limit=200` → `{rows:[{event_time, actor_type, actor_id, action, details}]}`

---------------------------------------------------------------------
## 4. Admin  (role = admin)

- GET `/api/admin/overview` → `{faculty, students, subjects, exams}` (counts)
- GET/POST `/api/admin/faculty` (POST `{name,email,password}`) → list `{faculty:[{faculty_id,name,email,subjects:"OS101, DB101"}]}`
- GET/POST `/api/admin/students` (POST `{roll_no,name,email,password}`) → list `{students:[{student_id,roll_no,name,email,subjects}]}`
- GET/POST `/api/admin/subjects` (POST `{code,name}`) → list `{subjects:[{subject_id,code,name}]}`
- POST `/api/admin/assign` `{faculty_id, subject_id}` → `{ok:true}`
- POST `/api/admin/enroll` `{student_id, subject_id}` → `{ok:true}`
- POST `/api/admin/students/import` `{csv}` header `roll_no,name,email,password` → `{added, skipped:[{row,reason}]}`
- POST `/api/admin/enroll/import` `{csv}` header `roll_no,subject_code` → `{added, skipped:[{row,reason}]}`
- GET `/api/admin/log?limit=200` → same shape as the faculty log
- (BACKEND ONLY, no web page: use Postman or the browser address bar for these two) GET `/api/admin/system` → `{policy:"FIFO"|"ROUND_ROBIN", workers, busy_workers, queue_length, active_sessions, cache:{size, capacity, hits, misses}, uptime_seconds}`
- POST `/api/admin/system/policy` `{policy}` → `{ok:true}` (switches the scheduling policy of the evaluation queue)

Static pages are served from `/` (the `web` folder).

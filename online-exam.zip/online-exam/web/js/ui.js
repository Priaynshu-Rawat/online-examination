// =====================================================================
// ui.js - small helpers shared by all pages:
// toast messages, pop-up windows, the top bar, theme toggle, formatting.
// =====================================================================

// Short names for document.querySelector / querySelectorAll
window.$ = function (sel, root) { return (root || document).querySelector(sel); };
window.$$ = function (sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); };

// Make text safe before putting it inside HTML (stops <script> tricks)
window.esc = function (s) {
  return String(s === null || s === undefined ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
};

window.UI = (function () {

  // ---------- light / dark theme ----------
  function applyTheme(t) {
    if (t === 'light' || t === 'dark') document.documentElement.setAttribute('data-theme', t);
    else document.documentElement.removeAttribute('data-theme');
  }
  function currentTheme() {
    const set = document.documentElement.getAttribute('data-theme');
    if (set) return set;
    return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  }
  function toggleTheme() {
    const next = currentTheme() === 'dark' ? 'light' : 'dark';
    applyTheme(next);
    try { localStorage.setItem('theme', next); } catch (e) { /* ignore */ }
    $$('.theme-btn').forEach(function (b) { b.textContent = next === 'dark' ? '☀' : '☾'; });
    document.dispatchEvent(new Event('themechange'));   // charts listen to this and redraw
  }
  // runs at once, so there is no flash of the wrong colour
  (function themeInit() {
    let saved = null;
    try { saved = localStorage.getItem('theme'); } catch (e) { /* ignore */ }
    if (saved) applyTheme(saved);
  })();
  function themeButton() {
    return '<button class="icon-btn theme-btn" type="button" title="Switch light/dark" aria-label="Switch light or dark theme" onclick="UI.toggleTheme()">' +
      (currentTheme() === 'dark' ? '☀' : '☾') + '</button>';
  }

  // ---------- toast (small message that disappears) ----------
  function toast(message, kind) {
    let box = $('.toasts');
    if (!box) { box = document.createElement('div'); box.className = 'toasts'; box.setAttribute('role', 'status'); document.body.appendChild(box); }
    const t = document.createElement('div');
    t.className = 'toast ' + (kind || '');
    t.textContent = message;
    box.appendChild(t);
    setTimeout(function () { t.remove(); }, kind === 'error' ? 6000 : 3500);
  }

  // ---------- pop-up window ----------
  // modal({title, html, wide, buttons:[{text, cls, onClick}]}) -> {close, el}
  function modal(opts) {
    const overlay = document.createElement('div');
    overlay.className = 'overlay';
    const box = document.createElement('div');
    box.className = 'modal' + (opts.wide ? ' wide' : '');
    box.setAttribute('role', 'dialog');
    box.setAttribute('aria-modal', 'true');
    box.innerHTML = '<h2>' + esc(opts.title || '') + '</h2><div class="modal-body">' + (opts.html || '') + '</div>' +
      '<div class="modal-actions"></div>';
    overlay.appendChild(box);
    document.body.appendChild(overlay);

    function close() { overlay.remove(); }
    const actions = $('.modal-actions', box);
    (opts.buttons || [{ text: 'Close', cls: 'ghost' }]).forEach(function (b) {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'btn ' + (b.cls || '');
      btn.textContent = b.text;
      btn.onclick = function () {
        if (b.onClick) { const keep = b.onClick(close, box); if (keep === 'keep') return; }
        close();
      };
      actions.appendChild(btn);
    });
    return { close: close, el: box };
  }

  // confirmBox("Are you sure?") -> Promise<true/false>
  function confirmBox(message, okText, danger) {
    return new Promise(function (resolve) {
      modal({
        title: 'Please confirm',
        html: '<p class="pre">' + esc(message) + '</p>',
        buttons: [
          { text: 'Cancel', cls: 'ghost', onClick: function () { resolve(false); } },
          { text: okText || 'Yes', cls: danger ? 'danger' : '', onClick: function () { resolve(true); } }
        ]
      });
    });
  }

  // ---------- top bar ----------
  const LINKS = {
    student: [['/student.html', 'Exams', 'exams'], ['/student.html#results', 'My results', 'results']],
    faculty: [['/faculty-exams.html', 'Faculty', 'faculty']],
    admin: [['/admin.html', 'Admin', 'admin']]
  };
  // buildNav(user, activeKey) puts the bar into <div id="nav">
  function buildNav(user, active) {
    if (!$('#nav')) return;   // the exam page has no top bar
    const links = (LINKS[user.role] || []).map(function (l) {
      return '<a href="' + l[0] + '"' + (l[2] === active ? ' class="active"' : '') + '>' + esc(l[1]) + '</a>';
    }).join('');
    $('#nav').innerHTML =
      '<div class="topbar"><div class="topbar-inner">' +
      '<a class="brand" href="/"><span class="brand-dot">✓</span>Online Exam</a>' +
      '<nav class="navlinks" aria-label="Main">' + links + '</nav>' +
      '<span class="who">' + esc(user.name) + ' · ' + esc(user.role) + '</span>' +
      themeButton() +
      '<button class="btn ghost sm" type="button" onclick="UI.logout()">Log out</button>' +
      '</div></div>';
  }
  // the second bar for faculty pages
  function facultyTabs(active) {
    const items = [['exams', '/faculty-exams.html', 'Exams'], ['questions', '/faculty-questions.html', 'Question bank'], ['log', '/faculty-log.html', 'Activity log']];
    $('#subnav').innerHTML = '<div class="subnav"><div class="subnav-inner">' + items.map(function (i) {
      return '<a href="' + i[1] + '"' + (i[0] === active ? ' class="active"' : '') + '>' + i[2] + '</a>';
    }).join('') + '</div></div>';
  }

  async function logout() {
    try { await api.post('/api/logout', {}, { noRedirect: true }); } catch (e) { /* ignore */ }
    api.clearToken();
    location.href = '/index.html';
  }

  // requireRole('student') -> asks the server who we are; wrong role -> login page
  async function requireRole(role, active) {
    let me;
    try { me = await api.get('/api/me'); } catch (e) { return null; }
    if (me.role !== role) { location.href = '/index.html'; return null; }
    buildNav(me, active);
    return me;
  }

  // ---------- time and number helpers ----------
  // Server times look like "2026-11-05 11:30:00". We read them all the same way
  // (as if they were UTC) so DIFFERENCES between two server times are correct.
  function parseTime(s) {
    if (!s) return NaN;
    return Date.parse(String(s).replace(' ', 'T') + 'Z');
  }
  function fmtDate(s) {
    if (!s) return '-';
    const d = new Date(parseTime(s));
    if (isNaN(d)) return esc(s);
    const m = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const hh = d.getUTCHours(), mm = String(d.getUTCMinutes()).padStart(2, '0');
    const h12 = hh % 12 === 0 ? 12 : hh % 12;
    return d.getUTCDate() + ' ' + m[d.getUTCMonth()] + ' ' + d.getUTCFullYear() + ', ' + h12 + ':' + mm + ' ' + (hh < 12 ? 'AM' : 'PM');
  }
  // seconds -> "mm:ss" or "h:mm:ss"
  function fmtClock(sec) {
    sec = Math.max(0, Math.floor(sec));
    const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = sec % 60;
    const mm = String(m).padStart(2, '0'), ss = String(s).padStart(2, '0');
    return h > 0 ? h + ':' + mm + ':' + ss : mm + ':' + ss;
  }
  // value of <input type=datetime-local> -> "YYYY-MM-DD HH:MM:SS"
  function toServerTime(v) {
    if (!v) return '';
    let s = v.replace('T', ' ');
    if (s.length === 16) s += ':00';
    return s;
  }
  function num(v, digits) {
    if (v === null || v === undefined || v === '') return '-';
    const n = Number(v);
    return isNaN(n) ? esc(v) : String(Math.round(n * Math.pow(10, digits === undefined ? 2 : digits)) / Math.pow(10, digits === undefined ? 2 : digits));
  }
  function badge(text, kind) {
    const k = String(kind || text || '').toLowerCase().replace(/[^a-z_]/g, '_');
    return '<span class="badge ' + k + '">' + esc(String(text).replace(/_/g, ' ')) + '</span>';
  }
  function flagBadge(count, level) {
    return '<span class="badge ' + esc(level || 'none') + '">' + esc(count === null || count === undefined ? 0 : count) + ' ' + (Number(count) === 1 ? 'flag' : 'flags') + '</span>';
  }
  function statusLabel(s) {
    const map = {
      NOT_ATTEMPTED: 'Not attempted', IN_PROGRESS: 'In progress', SUBMITTED: 'Submitted',
      AUTO_TIMEOUT: 'Auto-submitted (time)', AUTO_FLAGS: 'Auto-submitted (flags)', ABSENT: 'Absent',
      'AUTO-SUBMITTED (time)': 'Auto-submitted (time)', 'AUTO-SUBMITTED (flags)': 'Auto-submitted (flags)',
      ATTEMPTED: 'Attempted', 'IN PROGRESS': 'In progress'
    };
    return map[s] || s;
  }
  function statusBadge(s) {
    const kind = { 'AUTO-SUBMITTED (time)': 'auto_timeout', 'AUTO-SUBMITTED (flags)': 'auto_flags', ATTEMPTED: 'submitted', 'IN PROGRESS': 'in_progress' }[s] || s;
    return badge(statusLabel(s), kind);
  }
  // exam status badge; "DEACTIVATED" is shown as "Not active"
  function examStatusBadge(status) {
    if (status === 'DEACTIVATED') return badge('Not active', 'deactivated');
    return badge(status, status);
  }
  // colour level of a flag count (same rule as the server and the exam page)
  function flagLevel(count, limit) {
    count = Number(count) || 0;
    limit = Number(limit) || 5;
    return count === 0 ? 'none' : count < 3 ? 'yellow' : count < limit ? 'orange' : 'red';
  }
  // html for an import report {added, skipped:[{row, reason}]}
  function reportHtml(r) {
    let h = '<div class="form-ok">' + esc(r.added) + ' added.' + (r.skipped && r.skipped.length ? ' ' + esc(r.skipped.length) + ' skipped.' : '') + '</div>';
    if (r.skipped && r.skipped.length) {
      h += '<div class="table-wrap"><table><thead><tr><th>Row</th><th>Why it was skipped</th></tr></thead><tbody>' +
        r.skipped.map(function (s) { return '<tr><td>' + esc(s.row) + '</td><td>' + esc(s.reason) + '</td></tr>'; }).join('') +
        '</tbody></table></div>';
    }
    return h;
  }
  // read the text of a file chosen in <input type=file>
  function readFileText(input) {
    return new Promise(function (resolve, reject) {
      const f = input.files && input.files[0];
      if (!f) { reject(new Error('Choose a CSV file first.')); return; }
      const rd = new FileReader();
      rd.onload = function () { resolve(String(rd.result)); };
      rd.onerror = function () { reject(new Error('Could not read the file.')); };
      rd.readAsText(f);
    });
  }
  // read ?id=5 from the address bar
  function param(name) { return new URLSearchParams(location.search).get(name); }

  // save a Blob as a file download
  function download(blob, filename) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = filename;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
  }

  // Make a table sortable: sortable(tableEl, rows, renderRows)
  // columns come from <th data-key="..."> ; click again to reverse
  function makeSortable(table, getRows, render, defaultKey) {
    let key = defaultKey || null, dir = 1;
    function sorted() {
      const rows = getRows().slice();
      if (!key) return rows;
      rows.sort(function (a, b) {
        let x = a[key], y = b[key];
        const nx = Number(x), ny = Number(y);
        if (x !== null && y !== null && x !== '' && y !== '' && !isNaN(nx) && !isNaN(ny)) { x = nx; y = ny; }
        else { x = String(x === null || x === undefined ? '' : x).toLowerCase(); y = String(y === null || y === undefined ? '' : y).toLowerCase(); }
        return x < y ? -dir : x > y ? dir : 0;
      });
      return rows;
    }
    function refresh() {
      render(sorted());
      $$('th.sortable', table).forEach(function (th) {
        th.setAttribute('aria-sort', th.dataset.key === key ? (dir === 1 ? 'ascending' : 'descending') : 'none');
        const arrow = th.dataset.key === key ? (dir === 1 ? ' ▲' : ' ▼') : '';
        th.textContent = th.dataset.label + arrow;
      });
    }
    $$('th.sortable', table).forEach(function (th) {
      th.dataset.label = th.textContent;
      th.tabIndex = 0;
      const go = function () {
        if (key === th.dataset.key) dir = -dir; else { key = th.dataset.key; dir = 1; }
        refresh();
      };
      th.addEventListener('click', go);
      th.addEventListener('keydown', function (e) { if (e.key === 'Enter') go(); });
    });
    refresh();
    return refresh;
  }

  return {
    toast: toast, modal: modal, confirmBox: confirmBox, buildNav: buildNav, facultyTabs: facultyTabs,
    logout: logout, requireRole: requireRole, parseTime: parseTime, fmtDate: fmtDate, fmtClock: fmtClock,
    toServerTime: toServerTime, num: num, badge: badge, flagBadge: flagBadge, statusBadge: statusBadge,
    statusLabel: statusLabel, param: param, download: download, makeSortable: makeSortable,
    toggleTheme: toggleTheme, examStatusBadge: examStatusBadge, flagLevel: flagLevel,
    reportHtml: reportHtml, readFileText: readFileText, currentTheme: currentTheme
  };
})();

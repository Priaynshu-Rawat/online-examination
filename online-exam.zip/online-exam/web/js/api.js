// =====================================================================
// api.js - the ONLY place that talks to the server.
// Every page calls  api.get(...)  api.post(...)  etc.
// It adds the login token, sends/receives JSON and turns errors into
// normal JavaScript errors with a message the user can read.
// =====================================================================
const api = (function () {
  let memoryToken = null; // used only if the browser blocks localStorage

  function getToken() {
    try { return localStorage.getItem('token') || memoryToken; } catch (e) { return memoryToken; }
  }
  function setToken(t) {
    memoryToken = t;
    try { localStorage.setItem('token', t); } catch (e) { /* ignore */ }
  }
  function clearToken() {
    memoryToken = null;
    try { localStorage.removeItem('token'); } catch (e) { /* ignore */ }
  }

  // One request. body is a normal JS object (or undefined).
  async function call(method, path, body, opts) {
    opts = opts || {};
    const headers = {};
    const token = getToken();
    if (token) headers['Authorization'] = 'Bearer ' + token;
    if (body !== undefined) headers['Content-Type'] = 'application/json';

    let res;
    try {
      res = await fetch(path, {
        method: method,
        headers: headers,
        body: body !== undefined ? JSON.stringify(body) : undefined
      });
    } catch (e) {
      throw new Error('Cannot reach the server. Check that it is running.');
    }

    // Read the JSON (or CSV text) answer
    const type = res.headers.get('Content-Type') || '';
    let data = null;
    if (opts.blob && res.ok) {
      data = await res.blob();
    } else if (type.indexOf('json') >= 0) {
      data = await res.json().catch(function () { return null; });
    }

    // Not logged in (or token expired) -> back to the login page
    if (res.status === 401 && !opts.noRedirect) {
      clearToken();
      location.href = '/index.html';
      throw new Error('Please log in');
    }
    if (!res.ok) {
      const err = new Error((data && data.error) || ('Request failed (' + res.status + ')'));
      err.status = res.status; // so pages can react to 409 etc.
      err.data = data;         // the whole JSON answer (for the duplicate pop-up)
      throw err;
    }
    return data;
  }

  return {
    get: function (p, o) { return call('GET', p, undefined, o); },
    post: function (p, b, o) { return call('POST', p, b === undefined ? {} : b, o); },
    put: function (p, b, o) { return call('PUT', p, b === undefined ? {} : b, o); },
    del: function (p, o) { return call('DELETE', p, undefined, o); },
    blob: function (p) { return call('GET', p, undefined, { blob: true }); },
    token: getToken,
    setToken: setToken,
    clearToken: clearToken
  };
})();
